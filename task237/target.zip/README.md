# BCS-12 wave 6 language versions: pilot files for the release decisions

Compiled by the pilot fieldwork manager on Friday 26 February 2027 from the two vendors' final pilot files, for the
translation quality lead's release decisions before the wave 6 fieldwork (launching Monday 22 March 2027).

- `translation_adaptation_standard_TAS-4.pdf`: the translation and adaptation standard (TAS-4).
- `bcs12_technical_manual_english.pdf`: the BCS-12 technical manual, English edition.
- `bcs12_translation_register_wave6.xlsx`: the translation register.
- `ncp_bcs12_pilot_export_wave6.csv`: Nesscroft Panels' online pilot export.
- `ncp_incentive_ledger_bcs12_pilot.csv`: Nesscroft Panels' incentive ledger, sent with its invoice for the pilots.
- `ncp_paradata_bcs12_pilot.csv`: Nesscroft Panels' paradata.
- `flr_bcs12_pilot_interviews_long.csv`: Fernlow Research's interviewer-administered pilot file.
- `flr_backcheck_log_bcs12_pilot.csv`: Fernlow Research's back-check log.
- `bcs12_pilot_codebook.xlsx`: the vendors' codebook.
- `ccs_wave5_bcs12_results_by_region.csv`: wave 5 results by region, for reference.
- `DATA_DICTIONARY.md`: the files and their fields.
