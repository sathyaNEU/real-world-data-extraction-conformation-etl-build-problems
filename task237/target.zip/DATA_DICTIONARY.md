# Data dictionary

Dates are Eastern dates (Toronto time) unless a field says UTC.

## ncp_bcs12_pilot_export_wave6.csv

Nesscroft Panels' export of the online pilots, one row per entry to the survey (every status). Answers as given, on the
codes in bcs12_pilot_codebook.xlsx.

## ncp_incentive_ledger_bcs12_pilot.csv

Nesscroft Panels' incentive ledger for the pilots, sent with its invoice (the centre pays the panel's incentives at cost):
one row per survey entry with the panel member who made it and the points credited.

| field | meaning |
|---|---|
| panel_member_id | the panel member's account; the panel merges a second account it finds a member holding into that member's account |
| respondent_id | the survey entry (as in the export); blank on a merged row |
| survey_code | the survey link; blank on a merged row |
| activity_utc | when the entry ended, or when the account was merged, UTC |
| outcome | complete, partial, screened out, or merged (the account's points moved to the account it was merged into) |
| points | points credited (negative on a merged row) |
| merged_into | on a merged row, the account it was merged into |
| payment_batch | the month the points are paid in |

## ncp_paradata_bcs12_pilot.csv

Nesscroft Panels' paradata for the pilots: platform (mobile, desktop or tablet), time on the survey and on the BCS-12
module, back-button uses.

## flr_bcs12_pilot_interviews_long.csv

Fernlow Research's interviewer-administered pilot and pretest interviews, one row per interview and questionnaire
variable reached (RESULT, AGE, the twelve BCS-12 items and the background questions), on the codes in bcs12_pilot_codebook.xlsx.

## flr_backcheck_log_bcs12_pilot.csv

Fernlow Research's back-check log: one row per interview selected for back-check, with the case, the interviewer
whose interview was checked, the date and method of the check, and its outcome (confirmed, not confirmed, not reached).

## bcs12_translation_register_wave6.xlsx

Sheet Register: one row per version, with its translation steps and pilot fieldwork dates. Sheet About.

## bcs12_pilot_codebook.xlsx

Each vendor's variables and answer codes (one sheet per vendor) and the pilot questionnaire's order (sheet
Questionnaire).

## ccs_wave5_bcs12_results_by_region.csv

Wave 5 BCS-12 results by region and version (English, French): respondents, mean score and its standard error.
