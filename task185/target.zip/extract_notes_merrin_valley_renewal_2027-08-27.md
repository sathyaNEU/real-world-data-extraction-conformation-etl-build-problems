# Extract for the Merrin Valley heat-day renewal

Pulled 27 Aug 2027 for Rachel Ballard (weather desk). Station data from the National Climate Service's data
portal; policy, claims and ledger extracts from our own systems. Questions on the station files to Richard Strickland at
the Service, on the co-operative's register to Bonnie Barr.

Files:
- ncs_daily_041391_19951101_20270827.csv: the automatic station, daily TMAX, TMIN (C) and PRCP (mm), 1 Nov 1995 on.
- ncs_climatological_register_041207_1964_1995.xlsx: the climatological register for 041207, one sheet a year, 1964 to 1995, as the Service digitised it.
- ncs_parallel_observations_maxtemp.csv: the Service's parallel observations archive, daily maxima, seven sites.
- ncs_district_stations_monthly_mean_max.csv: monthly mean maxima for the district's other stations, as asked.
- ncs_station_list_merrin_district.json: the Service's station list for the district.
- ncs_station_history_merrin_flat.pdf: station history for Merrin Flat.
- southward_weather_index_pricing_manual_rev3.pdf, heat_cover_term_sheet_2027_28_quote.pdf, heat_cover_term_sheet_2026_27.pdf: ours.
- policy_schedule_HC104_merrin_valley_2027-08-26.csv: policy system extract, every block on the co-operative's policy since inception.
- merrin_valley_block_register_2027-08.xlsx: the co-operative's block register, sent by Bonnie on 3 Aug. Its sub-districts are the ones the
  co-operative reports by and splits the premium by.
- claims_register_heat_cover_2020_2027.csv: claims register report, heat-day cover, one row per claim and insured block.
- gl6120_weather_claims_payments_FY2020_FY2028.csv: GL 6120 weather claims payments, posting date and financial year (1 July to 30 June).

Things to know:
- quality on the daily file: A approved, P provisional. Approved runs to 30 Jun 2027.
- A day's maximum is the highest reading in the 24 hours from 9 am, filed against the day the 24 hours began. Same
  in the register and the automatic station.
- The register's blank cells are days with no reading, or days that do not exist.
- grower_ref on our extracts is the co-operative's member number with our MV- prefix.
