SBA LENDING - DATA FOR THE 30 SEPTEMBER 2026 ALLOWANCE
Fenmore Savings Bank. Prepared by J. Nicholson (SBA servicing) and T. Williams (loan operations), 5 October 2026.

FILES
servicing_history_2017-10_2026-09.parquet
    Current servicing system, month-end loan history, October 2017 to September 2026.
legacy_loan_history_200910_201710.parquet
    Legacy core, month-end loan history, October 2009 to October 2017.
servicing_status_codes.csv
    Servicing status codes, both systems.
sba_loan_master.csv
    SBA Lending portfolio register: every 7(a) loan approved from October 2009 and disbursed by 30 September 2026.
guarantee_register.xlsx
    Loan documentation system, guarantee register, as at 30 September 2026.
allowance_policy_sba_7a.pdf
    Credit policy CP-SBA-07, allowance for credit losses on SBA 7(a) unguaranteed portions (version 4).
sba_loan_authorization_standard_terms.pdf
    SBA loan authorization, Part B standard terms (form SBL-AUTH-B, March 2018).
fta_1112_detail_cares.csv
    SBA fiscal transfer agent, Section 1112 remittance detail, CARES Act payments.
fta_1112_detail_eaa.xlsx
    SBA fiscal transfer agent, Section 1112 remittance detail, Economic Aid Act payments.
sba_settlement_account_credits.csv
    Treasury management, credits to the SBA settlement account, October 2019 to September 2026.
special_assets_ledger_fy2020_fy2026.csv
    Special Assets, charge-off and recovery entries, fiscal 2020 to fiscal 2026.
payments_to_sba.csv
    Accounts payable and treasury management, payments to SBA, October 2019 to September 2026.
form1502_2026-09.csv
    Form 1502 report to SBA's fiscal transfer agent for September 2026.
secondary_market_settlements.csv
    Secondary market settlements of guaranteed portions sold.
export_manifest.csv
    Export manifest.
README.txt
    This file.

FIELD NOTES
servicing_history_2017-10_2026-09.parquet
    One row per loan per month-end from October 2017, the month the current servicing system went live, to
    September 2026. A loan's rows run from the month-end of its first disbursement to the month it closes
    (charged off, paid in full or matured).
    note_no: the loan's note number on the current system. status: see servicing_status_codes.csv. dpd: days
    past due at the month-end, blank on liquidation and closing rows. principal_bal: principal outstanding
    at the month-end, dollars; 0.00 on the closing row. note_rate: the interest rate in effect at the
    month-end, per cent a year.
legacy_loan_history_200910_201710.parquet
    One row per loan per month-end from October 2009 to October 2017 from the legacy core. October 2017 was
    run on both systems and is in both extracts.
    LOAN_NO: the legacy loan number. PERIOD: year and month of the month-end (YYYYMM). STAT_CD: see
    servicing_status_codes.csv. DAYS_DLQ: days past due at the month-end (0 on liquidation and closing
    rows). PRIN_BAL_CENTS: principal outstanding, cents. INT_RT: interest rate as a decimal fraction.
sba_loan_master.csv
    One row per SBA 7(a) loan approved from October 2009 to September 2026 and disbursed by 30 September
    2026. A loan carries its legacy number if it was booked before the conversion and its note number if it
    was on the current system. approval_date: SBA's approval date. guaranty_pct: SBA's guaranteed share, per
    cent. rate_type: V variable (prime plus spread, adjusted quarterly), F fixed. initial_rate: per cent a
    year.
guarantee_register.xlsx
    One row per guaranty: each guarantor of each loan, as named on the guaranty. Party No: the documentation
    system's customer number for the guarantor. TIN (last 4): the last four digits of the guarantor's
    taxpayer identification number (SSN or EIN). Released: the date the guaranty was released on payment of
    the loan.
fta_1112_detail_cares.csv and fta_1112_detail_eaa.xlsx
    SBA's fiscal transfer agent's remittance detail for Section 1112 payments, as received: the CARES Act
    layout and the Economic Aid Act layout. Every vintage of the 7(a) book. Loans are keyed by SBA loan
    number.
sba_settlement_account_credits.csv
    ACH and wire credits to the SBA settlement account (DDA ending 4471) from SBA's fiscal transfer agent
    and SBA's Denver Finance Center, October 2019 to September 2026, with the originator's addenda.
special_assets_ledger_fy2020_fy2026.csv
    Special Assets' charge-off and recovery entries on SBA 7(a) loans posted from 1 October 2019 to 30
    September 2026. amount: dollars; charge-offs positive, receipts and reversals negative.
payments_to_sba.csv
    Payments from the bank to SBA, October 2019 to September 2026, by wire or ACH.

Fiscal years run from 1 October to 30 September (FY2026: 1 October 2025 to 30 September 2026); SBA's fiscal year is the same.
