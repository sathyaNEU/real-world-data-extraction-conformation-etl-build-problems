# Extract notes, 23 April 2027

Prepared by Alana Marnan (Capacity Planning Analyst) for the Head of Screening Operations' summer 2027 posting of the mobile screening unit. The extracts cover the eight airports the throughput detector flagged this spring.

Airport codes are the operations codes used across Screening Operations: ARD Ardcarrig, BRN Brennagh, CUL Cullinvale, DRM Dromkeel, ESK Eskerford, FAR Faranloe, GLK Glenkessan, HAL Halloran Bay. Times are local.

## Files

- `checkpoint_lane_counts_20260615_20260831.csv`: the lane sensor feed for 15 June to 31 August 2026. A row is one lane in one 15-minute interval in which it screened; `pax_screened` is the count through the lane's divest point. The mobile unit's lanes (M1 to M3) appear at the airport hosting it.
- `queue_time_sensor_20260615_20260831.csv`: queue time from the queue cameras, the median minutes from joining the queue to the divest point for people reaching it in the interval. Intervals with no reading (camera resets) are missing.
- `roster_plan_summer2026.csv`: the summer 2026 roster pattern, the lanes each checkpoint planned for its own officers by 15 minutes, one pattern for every day of the roster period.
- `roster_pattern_summer2027.xlsx`: the summer 2027 roster pattern, issued by the airports' duty managers in April 2027 from the new rostering tool (one column per checkpoint; valid 30 May to 11 September 2027).
- `summer2027_planning_sheet.xlsx`: Capacity Planning's summer 2027 planning sheet (design days; see its Notes sheet).
- `mobile_unit_postings_2026.csv`: the unit's 2026 postings, Monday to Sunday, with officers, officer-nights and the hotel purchase order.
- `checkpoint_lane_register.csv`: the lanes and mobile unit positions at each central checkpoint.
- `operator_traffic_returns_2026.csv`: the operators' monthly traffic returns for 2026.
- `hotel_invoices_CC4109_summer2026.xlsx`: payables lines for cost centre CC-4109, hotel invoices and credit notes for summer 2026. Amounts are as paid, including VAT, which the agency does not recover.
- `expense_claims_CC4109_2026.csv`: the expense claims export for cost centre CC-4109, claims approved June to October 2026.
- `lane_fault_log_2026.csv`: lane faults logged by the duty managers in 2026.
- `passenger_feedback_summer2026.csv`: passenger feedback about security at the eight airports, summer 2026.
- `throughput_detector_flags_spring2027.json`: the throughput detector's spring 2027 run.
- `checkpoint_planning_standard_2026.pdf`, `checkpoint_planning_standard_2023.pdf`, `mobile_screening_unit_deployment_policy_2027.pdf`.

## Not in this extract

- Officers' duty rosters (Human Resources).
- Lane sensor and queue-time data before 15 June 2026.
