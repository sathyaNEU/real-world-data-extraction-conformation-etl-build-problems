# Harbourgate offence extract: notes

Extract run 22 January 2027 by the Performance and Analysis unit for the community safety partnership.

## Scope

The extract covers offences recorded against an address in Harbourgate Street, Quayside, Lamphouse Lane, Fishmarket Square or Netherbow Wynd, for the 2025 and 2026 seasons (1 April to 30 September). It was pulled on the street name, so it also holds offences on the Cranstoun length of Harbourgate Street; the location register gives the numbers the quarter runs to. Addresses are as the recording officer entered them, against the corporate street gazetteer.

## The two systems

The force replaced its crime information system (CIS) with the records management system (RMS) class by class through 2025. The extract therefore comes in two files. `kcp_rms_offence_extract_2027-01-22.csv` holds everything the RMS has for both seasons; `kcp_cis_offence_extract_2025.csv` holds the classes CIS was still taking in the 2025 season, up to and including 27 July 2025.

Migration dates, by class, being the date the RMS became the system of record:

| Home Office class | RMS from |
|---|---|
| Theft from a motor vehicle | 13 January 2025 |
| Theft of a pedal cycle | 13 January 2025 |
| Criminal damage | 10 February 2025 |
| Burglary business | 10 February 2025 |
| Burglary residential | 10 February 2025 |
| Theft from the person | 28 July 2025 |
| Assault without injury | 28 July 2025 |
| Public order | 28 July 2025 |
| Shoplifting | 28 July 2025 |

For the fortnight 14 July 2025 to 27 July 2025, recording staff entered assault without injury, public order and shoplifting in both systems while the RMS classification screens were being settled. Those offences are in both files, each under that system's own reference; the references do not correspond. Theft from the person was not part of that arrangement.

## Class names

CIS held its own offence names. The mapping is one to one:

| CIS offence_type | Home Office class |
|---|---|
| THEFT - FROM PERSON | Theft from the person |
| ASSAULT - NO INJURY | Assault without injury |
| PUBLIC ORDER OFFENCE | Public order |
| THEFT - SHOP PREMISES | Shoplifting |

## Known differences

- CIS recorded the occurrence as four fields (date and time from, date and time to) and left the second pair empty where the time of occurrence was known. The RMS holds two timestamps and repeats the known time in both.

- Shoplifting was recorded once per incident in CIS and is recorded once per victim in the RMS, so the 2026 season's shoplifting count is not comparable with the 2025 season's.

- A location code is held for every offence of a class under a tasking agreement. For the other classes it is present only where it was entered, and the address is the only location held for the rest.

- Times are local. The footfall feed published by the business improvement district is stamped in UTC and is an hour behind local time through both seasons.

