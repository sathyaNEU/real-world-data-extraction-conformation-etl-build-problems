# Tern SDK changelog

Fogbell Games' in-house analytics SDK. Maintained by the SDK team (Padraic Cormick). Newest first.

## 5.0.1 (28 October 2026)

- iOS: `purchase_completed` is sent as soon as StoreKit reports the transaction, instead of with the next batch.
- Android: uploads now run through WorkManager, at most every 15 minutes while the game is in the foreground and when it
  starts. A batch that has not gone out when the game leaves the foreground is kept with the queue.
- Fixed: `level_complete` was logged twice when a level was replayed from the map on some Android 9 devices.
- Fixed: `screen_view` kept the previous screen's name when the shop was opened from a push notification.

## 5.0.0 (14 October 2026)

- New upload pipeline: batches are compressed, and the warehouse acknowledges each batch by its first and last event id.
- Batches of more than 500 events are split before upload.
- `ad_impression` gains `ad_network` and `placement`.
- Removed: `logRevenue()`, deprecated since 4.4.0.

## 4.6.3 (4 August 2026)

- Each event now carries an id generated on the device (UUID v4). A batch whose acknowledgement does not arrive is sent
  again with the same ids.
- `client_ts` is the device clock in milliseconds since the Unix epoch; the warehouse stamps `received_at` itself.
- Fixed: a crash at start on iOS 15 when the phone's storage was full.

## 4.6.2 (9 June 2026)

- Fixed: `app_version` was empty on the first event after an update on some Android devices.

## 4.6.0 (12 May 2026)

- Events are written to a queue on the device and uploaded in batches when the game starts and every 30 seconds while
  it is in the foreground. The queue is kept when the game is closed or the phone restarts.
- The queue holds up to 5,000 events; past that the oldest are dropped. Uninstalling the game deletes the queue.
- Events carry the account signed in on the phone: the guest account while the game is played as a guest, and the
  player's account from the moment they sign in on it.
- Unity plugin built against Unity 2022.3 LTS.
- Event names over 40 characters are rejected with a console warning.
