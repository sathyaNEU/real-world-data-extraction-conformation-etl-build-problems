# Kittiwake Cove purchase tracking pack, run of Monday 9 November 2026

Exported at 07:00 on 9 November 2026 for the weekly tracking-quality check (metrics catalogue KC-DQ-04).

- `metrics_catalogue_purchase_tracking.pdf`: catalogue entry KC-DQ-04, purchase tracking quality.
- `purchase_service_validations_2026-10-05_to_2026-11-09.csv`: the purchase service's validations.
- `warehouse_purchase_completed_2026-10-05_to_2026-11-09.csv`: the warehouse's purchase_completed events.
- `session_service_starts_2026-10-05_to_2026-11-09.csv`: the session service's session starts.
- `account_service_links_2026-10-05_to_2026-11-09.csv`: the account service's links.
- `build_register.xlsx`: production builds and the 7.42.0 rollout.
- `tern_sdk_release_notes.md`: the Tern SDK's release notes.
- `ecb_euro_reference_rates_2026-09-28_to_2026-11-06.csv`: ECB euro reference rates.
- `crash_free_sessions_by_build.csv`, `store_ratings_by_version.csv`, `push_campaigns_2026-10.csv`: context from the
  crash reporter, the stores and the push service.
- `DATA_DICTIONARY.md`: fields of every file.
