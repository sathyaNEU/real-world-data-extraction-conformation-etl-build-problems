# Data sources for the ownership desk

Maintained by Brian Guerra (data engineering). Pull for the December 2022 quarter files.

| Path | What it is | Coverage | How it is produced |
|---|---|---|---|
| `form13f_2022q3/` | SEC Form 13F data set, tables SUBMISSION, COVERPAGE, INFOTABLE | filings submitted 1 Jul to 30 Sep 2022 | downloaded from sec.gov as published, unaltered |
| `form13f_2022q4/` | SEC Form 13F data set, same tables | filings submitted 1 Oct to 31 Dec 2022 | downloaded from sec.gov as published, unaltered |
| `edgar13f_daily_20230103_20230203/` | nightly build from EDGAR 13F information-table XML, in the data-set layout | filings accepted 3 Jan to 3 Feb 2023 | parsed by our loader; INFOTABLE_SK is our own surrogate key |
| `fsds_cover_extract/` | cover-page share counts in the financial statement data sets layout (sub, num) | cover pages of covered issuers' quarterly and annual reports accepted 1 May 2022 to 3 Feb 2023 | the security master's pull; num carries the dei cover tags only |
| `manager_register.csv` | the desk's register of 13F filing managers | every manager we have covered since 2009 | maintained by hand; `family` groups affiliates for research notes, not for ownership |
| `client_watchlist_crowding_2022Q4.xlsx` | the client's watchlist | 12 securities | from client services |
| `client_flag_file_layout.md` | the client flag file layout | | client services |
| `ownership_methodology_OM-4.pdf` | ownership methodology | | methodology |
| `FORM13F_readme.htm` | SEC readme for the Form 13F data sets | | sec.gov |
| `short_interest_20221230.csv` | exchange short interest for the watchlist | settlement 30 Dec 2022 | vendor feed |
| `13flist2022q4.txt` | SEC Official List of Section 13(f) Securities, fourth quarter 2022, rows for covered issuers | | sec.gov, trimmed to covered CUSIPs |

The SEC data sets are organised by the quarter a filing was submitted in, not the period it
reports. Data-set and daily-build files are kept as delivered; nothing in them has been corrected.
