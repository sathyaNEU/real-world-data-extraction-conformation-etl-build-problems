# Client flag file layout, v4

Owner: client services. In use from the 2022Q4 files; replaces v3, in use from the 2021Q2 files.

One CSV per report period and watchlist, UTF-8, comma-separated, header row, one row per watchlist
security in watchlist sequence.

| Column | Content |
|---|---|
| `report_period` | Report period end, YYYY-MM-DD |
| `cusip` | Nine-character CUSIP from the watchlist |
| `ticker` | Ticker from the watchlist |
| `inst_own_pct` | Institutional ownership for the report period, per cent |
| `crowded` | `Y` or `N` |
| `prior_inst_own_pct` | Institutional ownership for the previous report period, per cent |

Changes from v3: the share-count and holder columns are dropped; the client takes share counts and
holder detail from its own vendor feeds. Rows for securities with no institutional holders carry `0.0`
and `N`.
