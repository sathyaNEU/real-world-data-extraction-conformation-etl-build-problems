# Client flag file layout, v3

Owner: client services. In use since the 2021Q2 files.

One CSV per report period and watchlist, UTF-8, comma-separated, header row, one row per watchlist
security in watchlist sequence.

| Column | Content |
|---|---|
| `report_period` | Report period end, YYYY-MM-DD |
| `cusip` | Nine-character CUSIP from the watchlist |
| `ticker` | Ticker from the watchlist |
| `shares_outstanding` | The share count institutional ownership is measured against (OM-4 section 5), whole shares |
| `inst_own_pct` | Institutional ownership for the report period, per cent |
| `crowded` | `Y` or `N` |
| `prior_shares_outstanding` | As `shares_outstanding`, for the previous report period |
| `prior_inst_own_pct` | As `inst_own_pct`, for the previous report period |
| `top_holder_cik` | CIK of the largest holder by market value at the report period end |
| `top_holder_name` | That manager's name as on its 13F cover page |
| `top_holder_value_usd` | That holder's market value, whole US dollars |

Rows for securities with no institutional holders carry `0.0` and `N` and leave the holder columns
blank.
