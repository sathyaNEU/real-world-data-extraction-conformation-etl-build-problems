# Audience warehouse: field reference

Maintained by Audience data (Natalie Benjamin). Revised 2 October 2026.

This reference covers the warehouse tables the audience team extracts for planning work. Each extract
in the planning folder carries the fields described here, in the same names.

## Articles

| Field | Meaning |
|---|---|
| `article_id` | Bightline article number. One per published article or live blog. Web articles share one sequence across both editions; app items are numbered in their own block. |
| `desk_code` | The owning desk, recorded at publication. An article has one owning desk. Codes are listed in the desk register. |
| `published_date` | Date the article was first published, Australian Eastern Standard Time. |
| `canonical_headline` | The headline stored with the article at publication. It is the headline carried in the article's RSS and partner feeds, its search and social metadata, Discover-style cards, newsletters and alerts. Not included in the pageview extracts. |

## Pageviews by source and age

One row per article, source surface and age band with at least one pageview in the period.

| Field | Meaning |
|---|---|
| `article_id`, `desk_code`, `published_date` | As above. |
| `source_code` | The surface the reader clicked to reach the article (codes below). Every article pageview carries one source code. A typed or bookmarked visit lands on a home page, which is not an article pageview. |
| `age_band` | The article's age when the pageview happened: `0-2h`, `2-6h`, `6-24h`, `1-3d`, `3-7d`, `7d+`. |
| `pageviews` | Article pageviews. A click on a link to an article counts when the article page loads; in planning papers clicks and pageviews are the same measure. |

| Source code | Surface |
|---|---|
| `home_web` | Bightline web home page (national edition or Brisbane edition) |
| `section_web` | Web section fronts |
| `feed_app` | Bightline app home feed |
| `section_app` | App section tabs |
| `related_links` | Related-story links inside an article, web and app, each showing the linked article's current headline |
| `search` | Organic search results |
| `discover` | Discover-style recommendation cards in mobile browsers |
| `partner_apps` | Partner news apps carrying the Bightline feed |
| `social` | Link cards on social platforms |
| `newsletter` | Bightline email newsletters |
| `alerts` | Push and browser alerts |

## Headline tests

One row per package of each concluded test. A package is one headline shown in the test: the control or a
variant.

| Field | Meaning |
|---|---|
| `test_id` | Test reference. |
| `engine` | `app`: the app testing engine, in use since 2019. `web`: the web CMS testing engine, whose history begins at the CMS migration on 1 October 2025. |
| `desk_code`, `article_id` | The article the test ran on and its owning desk. |
| `owner_staff_id` | Staff id of the person who created the test. |
| `started_at`, `concluded_at` | UTC. |
| `package_id`, `variant` | `control` is the headline the article was published with; `B` to `E` are the alternatives. |
| `impressions` | Times the package's headline was shown in a test slot. |
| `clicks` | Clicks on the package's headline in the test. |
| `shipped` | `Y` on the one package whose headline stayed live after the test; that is the control when no variant was shipped. |

Winning lift, as reported on the experimentation dashboard, is the shipped package's click-through rate over the
control's, minus one, and zero when the control is kept. The archive holds concluded tests only, one for every
headline put under test, whether or not a variant was shipped in the end.

## Desk register

| Field | Meaning |
|---|---|
| `desk_code`, `desk_name` | Desk code and name. |
| `vertical` | The dashboard vertical the desk reports under. |
| `edition` | `national`, `Brisbane` or `app`. |
| `distribution` | `web and app`, or `app only`. App-only items have no web URL, feed entry, search listing, alert or newsletter. |
