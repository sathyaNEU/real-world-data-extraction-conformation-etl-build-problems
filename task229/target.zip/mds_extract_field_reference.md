# MDS extract field reference

Metering Data Services, analytics team. Covers the extracts MDS pulls for the weekly read-health gate.
Last revised 14/09/2026 (T. Phillips).

## MDM interval receipts

`mdm_interval_receipts_<from>_<to>.csv`, one row per data stream, read date and delivery.

| Field | Meaning |
|---|---|
| NMI | National Metering Identifier, 10 characters (the MDM does not store the checksum character) |
| NMI_SUFFIX | data stream: E1 general supply, E2 controlled load, B1 export, Q1 reactive |
| READ_DATE | the market day the intervals belong to, CCYYMMDD, market time (AEST) |
| INTERVAL_LENGTH | minutes per interval for the data stream |
| UOM | unit of the interval values |
| DELIVERY_ID | MDM load batch that carried the row |
| RECEIVED_UTC | time the MDM received the delivery, UTC |
| QTY_A | intervals in the delivery carrying an actual read |
| QTY_S | intervals carrying a substituted value |
| QTY_F | intervals carrying a final substituted value |
| QTY_E | intervals carrying an estimated value from the MDM estimation run |
| DAY_TOTAL | sum of the day's interval values in UOM, every quality |

A delivery carries the whole data stream for the read date; a later delivery for the same NMI, suffix and
read date replaces the earlier one.

## HES firmware history

`hes_meter_firmware_history.json`, one object per meter registered to the head-end.

| Field | Meaning |
|---|---|
| meter_id | `MTR-` followed by the 8-digit meter serial |
| module, model | communications module family and meter model |
| status | IN_SERVICE, REMOVED, or BENCH (laboratory meters, never at an installation) |
| comms_parent | the node that collects the meter's reads: a collector (`EMC-`) on the EM3 mesh, an access point (`PXA-`) on the PX5 mesh; empty for bench meters |
| comms_parent_since | when the meter joined that node, UTC |
| events[].type | COMMISSIONED, FW_IMAGE_STAGED (image downloaded, not running), FW_ACTIVATED, FW_ACTIVATION_FAILED, FW_ROLLBACK_OK, DECOMMISSIONED |
| events[].image | HES image id; the release catalogue gives the release name |
| events[].job | rollout job reference |
| events[].event_id | identifier of the event at the meter |
| events[].ts_utc | time of the event at the meter, UTC |
| events[].ingested_utc | time the HES stored the event, UTC |
| events[].seq | HES storage sequence |

## MP installation register

`mp_installation_register_<date>.xlsx`: sheets Installations, Meters and Data streams. NMIs carry the
11th (checksum) character. Meter serials are 8 digits. Installed and Removed are local time at the
installation. Network is the distributor the installation is connected to.

## Wave schedules

Built by the rollout desk from the HES inventory on the day the wave is cut. Meter No is the meter serial;
NMI is filled in where the depot had it.
