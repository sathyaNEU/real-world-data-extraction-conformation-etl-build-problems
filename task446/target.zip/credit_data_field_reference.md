# Credit data: field reference

Maintained by Reference Data. Covers the quarter-end extracts used by Credit Risk Monitoring.

## ews_entity_signals_2022-09_to_2026-09.csv

Month-end publications of the early-warning engine, one row per covered entity per month-end.

| field | meaning |
|---|---|
| publication_date | the month-end the publication is for |
| entity_key | the entity's LEI, or `CRN:` and the Companies House number for an entity without an LEI |
| entity_name | the name as the engine's data vendor holds it |
| country | country of registration |
| signal | GREEN, AMBER or RED |
| score | 0 to 99; GREEN below 40, AMBER 40 to 69, RED 70 and over |
| trigger_codes | triggers active at the publication, semicolon separated (see ews_trigger_codes.csv) |
| feed | the vendor feed the leading trigger came from; COMPOSITE where no trigger is active |
| engine_release | engine release that produced the publication |

## credit_obligor_master_20260930.csv

Every customer on the credit system, open or closed.

| field | meaning |
|---|---|
| customer_id | credit system customer number |
| customer_name | the customer's registered name |
| lei | the customer's LEI where held |
| companies_house_no | Companies House number for UK-registered customers |
| country | country of registration |
| group_id | the obligor group the credit system books the customer to; blank until the monthly grouping review books a new customer |
| customer_since | the date the customer was opened on the credit system |
| customer_status | ACTIVE or CLOSED at the extract date |
| primary_booking_entity | HB-PLC (Halstow Bank plc) or HB-DAC (Halstow Bank Ireland DAC) |

## credit_group_register_20260930.xlsx

One row per obligor group, including groups whose relationship has ended.

| field | meaning |
|---|---|
| ultimate_parent_lei | LEI of the group's ultimate accounting-consolidation parent; blank where the parent has none |
| relationship_start | date the group's first facility started |
| relationship_end | date the relationship ended (last facility repaid, refinanced elsewhere or transferred to Recoveries); blank while active |
| sector_code, sector | the group's sector |

## watch_list_history_2020-01_to_2026-09.csv

Every watch-list case opened since 1 January 2020.

| field | meaning |
|---|---|
| placed_on | date the group was placed on the watch list |
| watch_level | 1, 2 or 3 (case intensity); every level is on the watch list |
| removed_on | date the case closed; blank while open |
| removal_reason | CURED, REFINANCED_AWAY or TO_RECOVERY |

## facility_obligor_extract_20260930.csv

Facilities on the Halstow Bank plc and Halstow Bank Ireland DAC loan ledgers when the quarter-end extract ran, with
their obligors.

| field | meaning |
|---|---|
| booking_entity | HB-PLC or HB-DAC, the ledger the facility is booked on |
| facility_id | the facility number on that ledger |
| customer_id | the obligor the row is for |
| product | facility product |
| currency | facility currency |
| committed_limit | the facility's committed limit when the extract ran, in the facility currency |
| drawn_balance | the obligor's drawings when the extract ran, in the facility currency |
| start_date | date the facility became available |
| final_maturity_date | date the facility falls due for repayment and the commitment ends |
| facility_status | ACTIVE, CANCELLED or CLOSED when the extract ran |

## facility_limit_history_20261008.csv

Every committed limit each facility has carried, one row per version.

| field | meaning |
|---|---|
| booking_entity, facility_id | as in facility_obligor_extract_20260930.csv |
| committed_limit | the committed limit of the version, in the facility currency |
| effective_from | when the version took effect, UTC, as the loan platform records it |
| source | SOD_BATCH for the start-of-day batch, otherwise the user who keyed it |

## treasury_closing_rates_20260930.csv

| field | meaning |
|---|---|
| units_per_gbp | units of the currency for one pound sterling at the Group Treasury 16:00 London close |

## GLEIF files (gleif_lei_cdf_20260930.csv, gleif_rr_cdf_20260930.csv, gleif_repex_20260930.csv)

Records from GLEIF's concatenated files published on 30 September 2026 (LEI-CDF 3.1, RR-CDF 2.1 and reporting
exceptions), filtered by Reference Data to the LEIs in the obligor master and the engine's coverage list.
Field names are GLEIF's.
