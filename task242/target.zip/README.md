# Serosurvey flag review, January 2028

Files gathered by the City Epidemiology Cell, Neithalpuram City Municipal Corporation, for the quality flag review of the 2027 serosurvey values
before the public health standing committee.

- flag_review_request.eml: the City Health Officer's request
- epi_cell_indicator_register.xlsx: the Cell's register of published indicators
- sop_epi_07_quality_flags.pdf: SOP-EPI-07, quality flags on published surveillance indicators
- dengue_bulletin_dec2027.pdf: City Dengue Bulletin No. 52 of 2027
- igm_lot_verification_cover_note.eml: the laboratory's note on the kit lot's verification run
- ngmc_igm_lot_verification_panel.csv: the verification run's results
- serosurvey_2027_protocol.docx: the household serosurvey protocol
- serosurvey_2027_igm_results.csv: the survey's IgM results
- serosurvey_2027_household_sample.csv: the sampled households
- serosurvey_2027_visits_kobo_export.csv: the field app export of household calls
- ngmc_serology_specimen_register_survey.csv: the laboratory's register of survey specimens
- ncmc_dengue_line_list_2026_27.csv: the city's dengue line list
- vector_surveillance_sop_extract.pdf: the Vector Control Unit's entomological surveillance SOP (extract)
- dbc_house_inspections_nov2027.csv: the November 2027 house inspection forms
- ncmc_ward_master_2027.csv: the ward master
- ncmc_rain_gauges_daily.csv: daily rainfall at the Corporation's rain gauges
- ncmc_fogging_log_2027.csv: the fogging and source reduction log
- DATA_DICTIONARY.md: the columns of every table
