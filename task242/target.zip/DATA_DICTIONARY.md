# Data dictionary

Dates are ISO (YYYY-MM-DD) unless a column says otherwise. Times in the field app export carry their offset; the
laboratory's register is in Indian Standard Time.

## ncmc_dengue_line_list_2026_27.csv
The city's dengue line list as kept by the City Epidemiology Cell: every dengue case notified to the Corporation from 1
October 2026, extracted on 8 January 2028. One row per notification.

| Column | Meaning |
|---|---|
| case_no | Notification number (NCMC/DEN/year of notification/serial) |
| notified_on | Date the case was notified (DD-MM-YYYY) |
| onset_date | Date of onset of fever, as reported (DD-MM-YYYY) |
| age_yrs, sex | Age in completed years; M or F |
| zone | Zone of residence as the reporting unit wrote it; non-residents as Non-resident with their district |
| reporting_unit | The hospital, primary health centre or laboratory that notified the case |
| test_done | The test that supported the notification |
| classification | CONFIRMED (ELISA or RT-PCR) or PROBABLE (rapid test) |
| hospitalised | Y or N |
| outcome | RECOVERED, DIED, LAMA (left against medical advice), UNDER TREATMENT |

## serosurvey_2027_igm_results.csv
The household serosurvey's IgM results: one row per resident whose specimen the laboratory tested.

| Column | Meaning |
|---|---|
| specimen_id | Specimen barcode (TS-ZZ-HHH-L, with R for a specimen collected again) |
| household_id | ZZ-HHH: zone number and household serial in the zone |
| zone | Zone |
| member_line | The resident's line on the household roster |
| age_yrs, sex | Age in completed years; F or M |
| collected_on | Date the specimen was collected |
| plate | ELISA plate |
| igm_index | Final IgM index (sample to cut-off ratio) |
| igm_result | REACTIVE or NON-REACTIVE |

## ngmc_igm_lot_verification_panel.csv
The laboratory's verification run for the IgM capture ELISA lot used for the survey (July 2027). One row per serum.

| Column | Meaning |
|---|---|
| panel_no | Serial in the run |
| arm | CONFIRMED CASE or NEGATIVE CONTROL |
| patient_ref | Follow-up clinic number (FUC), blood bank number (BB) or febrile illness register number (OFI) |
| confirmed_by | How the case was confirmed, or what the control is |
| onset_date | Date of onset of illness (DD-MM-YYYY); blank for blood donors |
| collected_on | Date the serum was collected (DD-MM-YYYY) |
| index_first, reading_first | First IgM index and reading |
| index_repeat | Index on repeat testing, for a first reading in the grey zone |
| result_final | REACTIVE or NON-REACTIVE |

## serosurvey_2027_household_sample.csv
The households sampled for the survey, one row each.

| Column | Meaning |
|---|---|
| household_id | ZZ-HHH |
| zone | Zone |
| listing_sl_no | Serial in the zone's sample |
| listing_address | Address as listed |

## serosurvey_2027_visits_kobo_export.csv
The field app export (KoboToolbox): one row per submission of the household call form.

| Column | Meaning |
|---|---|
| _id, _uuid | Submission identifiers given by the server |
| start, end | When the form was opened and closed on the tablet (with offset) |
| today | Date on the tablet |
| deviceid | Tablet |
| zone, household_id | The household called on |
| visit_number | Call number entered by the interviewer |
| visit_outcome | 1 interview completed, 2 refused, 3 nobody at home, 4 vacant, 5 not a dwelling, 6 other |
| members_usual, members_eligible | Usual residents; residents aged one year and over (completed interviews) |
| interviewer | Interviewer code |
| __version__ | Form version |
| _submission_time | When the server received the submission (UTC) |

## ngmc_serology_specimen_register_survey.csv
The laboratory's register of the survey specimens it received, one row per specimen.

| Column | Meaning |
|---|---|
| lab_no | Laboratory accession number |
| barcode | Specimen barcode from the field |
| zone | Zone, from the barcode |
| received_on | Date and time received |
| condition | ACCEPTED, HAEMOLYSED, INSUFFICIENT |
| action | TESTED, REJECTED, REJECTED - RECOLLECTION REQUESTED |
| plate | ELISA plate, for a tested specimen |
| released_on | Date the result was released |

## dbc_house_inspections_nov2027.csv
The Domestic Breeding Checkers' house inspection forms for November 2027, one row per form.

| Column | Meaning |
|---|---|
| record_id | Form number |
| inspected_on | Date of the visit |
| ward_no | Ward number written on the form |
| premise_id | Property assessment number (ZZ/WWW/NNNNN) |
| premise_type | Residential |
| wet_containers | Containers holding water |
| positive_containers | Containers with Aedes larvae or pupae |
| source_reduction | Y if positive containers were emptied, covered or treated |
| remarks | The checker's remark |
| inspector | DBC code |

## ncmc_ward_master_2027.csv
The Corporation's ward master, one row per ward.

| Column | Meaning |
|---|---|
| ward_no | Ward number |
| ward_name | Ward name |
| zone | Zone |
| former_ward_nos | The ward numbers the ward's area carried under the earlier ward map |

## ncmc_rain_gauges_daily.csv
Daily rainfall at the Corporation's rain gauges, 1 October 2026 to 31 December 2027.

| Column | Meaning |
|---|---|
| station_id, station_name | Gauge |
| date | Day |
| rainfall_mm | Rainfall in the 24 hours to 08:30 IST |

## ncmc_fogging_log_2027.csv
The Vector Control Unit's log of fogging and source reduction operations in 2027.

| Column | Meaning |
|---|---|
| date | Day |
| zone, locality | Where |
| activity | Operation |
| houses_covered | Houses covered (not recorded for thermal fogging) |
| insecticide_litres | Insecticide used |
| trigger | Why the operation was run |
