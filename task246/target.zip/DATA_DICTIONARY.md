# Data dictionary

## lr2027_cluster_sample.csv
The round's cluster sample: one row per cluster. sub_county, zone, cluster (the cluster number), ea_code (the census
enumeration area), households_listed (the team's listing), partner and team (the team that worked it) and
date_visited (dd/mm/yyyy).

## ncha_lr2027_anthropometry.csv
NCHA's tablet export, one row per form sent. _uuid and _submission_time (the server's receipt, UTC); today (the day of
measurement, yyyy-mm-dd); team (NCHA team number); cluster; hh_no (the household's number in the cluster's selection);
child_no (the child's line on the household roster); sex (m, f); dob (date of birth, dd/mm/yyyy); oedema (y, n);
weight_kg; height_cm; muac_mm (millimetres); measles (1 card, 2 recall, 3 not vaccinated, 8 does not know; blank for
children under 9 months).

## prk_lr2027_anthropometry.xlsx
PRK's export, sheet Children, one row per child: Date (dd/mm/yyyy); Team (PRK team number); Cluster; HH; Child line;
Sex (1 male, 2 female); Age (months) in completed months; Oedema (1 yes, 0 no); Weight (kg); Height (cm); MUAC (cm);
Measles (Yes, card / Yes, recall / No / Don't know; blank for children under 9 months).

## ncha_lr2027_muac_standardisation.csv
NCHA's standardisation sheet, one row per reading: session (1 training, 2 refresher); date; test_child; measured_by (the
NCHA anthropometrist's code, or SUPERVISOR); reading (1 or 2); muac_mm.

## prk_lr2027_muac_standardisation.xlsx
PRK's standardisation sheets, one per session, one row per test child: the supervisor's two readings, then each PRK
anthropometrist's two readings, in cm.

## lr2027_survey_teams.xlsx
Sheet Teams: each team's partner, number, team leader, anthropometrist and the anthropometrist's code, the zones and
clusters it worked, and its first and last fieldwork days. Sheet Changes during the round: dated changes to the teams.

## lr2027_household_visits.csv
The county server's household visits (both partners' teams enter the household interview on the county's household
form): one row per visit. partner; team; cluster; hh_no (the household's number in the cluster's selection); visit (1
first, 2 return); date (dd/mm/yyyy); time; outcome (as version 4 of the household form codes it: 1 interviewed, 2
refused, 3 dwelling empty, 4 absent); members_present (interviewed households).

## lr2027_household_members.csv
The county server's member rosters: one row per member listed on an interviewed household's roster. cluster; hh_no;
form_id; interview_date (yyyy-mm-dd); line_no; sex (M, F); age and age_unit (completed months for children under five,
completed years otherwise); status (P present at the interview, L left the household during the recall period, D died
during the recall period); joined and born (Yes, No: whether the member joined the household, or was born into it,
during the recall period); left_reason (members who left, as version 4 of the household form codes it: 1 looking for
work, 2 marriage, 3 moved with the mother or caregiver, 4 died away from home, 5 school, 6 moved with the livestock, 7
joined another household); date_of_death (dd/mm/yyyy, members who died at home).

## lr2027_household_births.csv
The county server's births module: each child born to the household during the recall period. cluster; hh_no;
form_id; date_of_birth (dd/mm/yyyy); sex; outcome (alive, died); date_of_death.

## laga_ewb_bulletin_june_2027.pdf
The County Drought Early Warning Unit's June 2027 bulletin.

## laga_market_prices_2025_2027.csv
Monthly market prices: month (yyyy-mm), market, commodity (with its unit), price (KES).

## laga_rainfall_dekadal_2027.csv
Dekadal rainfall at the county's five gauges, January to July 2027: station, dekad (yyyy-mm-D1 to D3), rainfall_mm,
long_term_mean_mm.
