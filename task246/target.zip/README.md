# Laga County long-rains assessment round, 2027

Files gathered by the County Nutrition Unit after the 2027 long-rains assessment round, for the July early warning
bulletin.

- lr2027_figures_request.eml: the bulletin desk's request.
- laga_nutrition_surveillance_protocol_v2_1.pdf: the round's protocol (version 2.1).
- lr2027_cluster_sample.csv: the cluster sample.
- lr2027_survey_teams.xlsx: the survey teams and changes during the round.
- ncha_lr2027_anthropometry.csv: NCHA's anthropometry export.
- prk_lr2027_anthropometry.xlsx: PRK's anthropometry export.
- ncha_lr2027_muac_standardisation.csv: NCHA's MUAC standardisation sheet.
- prk_lr2027_muac_standardisation.xlsx: PRK's MUAC standardisation sheets.
- lr2027_household_visits.csv: the household visits, from the county's household form.
- lr2027_household_members.csv: the household member rosters, from the county's household form.
- lr2027_household_births.csv: the births module, from the county's household form.
- laga_ewb_bulletin_june_2027.pdf: the June 2027 early warning bulletin.
- laga_market_prices_2025_2027.csv: market prices, January 2025 to June 2027.
- laga_rainfall_dekadal_2027.csv: dekadal rainfall, 2027.
- DATA_DICTIONARY.md: the fields of each file.
