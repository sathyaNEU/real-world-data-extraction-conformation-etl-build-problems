# Pool request working files

Duane Zamora, head of moderation operations, 9 October 2026. Pulled for the council's 2027 request; every export was pulled on 8 October 2026 unless it says otherwise.

| File | What it is | Rows |
|---|---|---|
| review_inbox_daily_2024-01-01_2026-09-30.csv | review platform daily inbox export, January 2024 to September 2026 | 36,144 |
| review_inbox_daily_2026-09_pulled_2026-10-02.csv | the same export for September 2026 as first pulled on 2 October | 1,080 |
| review_queues_monthly_2021-2023.xlsx | old review system monthly queue workbook, 2021 to 2023 (one sheet a year) |  |
| reviewer_roster_2026-10-08.csv | review platform reviewer roster | 20,080 |
| modtool_flag_summary_daily_2024-01-01_2026-09-30.csv | moderator tool daily flag summary, January 2024 to September 2026 | 9,036 |
| modtool_flags_2026-07-01_to_2026-08-15.csv | moderator tool flag export, flags raised 1 July to 15 August 2026 | 24,591 |
| modtool_flags_2026-08-15_to_2026-09-30.csv | moderator tool flag export, flags raised 15 August to 30 September 2026 | 29,578 |
| flag_decision_reviews_2026-07_to_2026-09.csv | decision reviews of the moderator flag decisions taken July to September 2026 | 2,103 |
| posts_questions_by_site_month_2024-01_2026-09.csv | posts warehouse, questions by site and month | 297 |
| question_plan_2027.xlsx | Planning & Analytics 2027 question plan (issued 18 September) |  |
| wfm_shift_lines_2026-01-01_2026-09-30.csv | WFM system shift lines, January to September 2026 | 4,635 |
| moderator_site_assignments.csv | HR assignment history for the paid moderation team | 35 |
| question_moves_2021-2023.csv | moderators' log of questions moved between sites, 2021 to 2023 | 49,530 |
| pageviews_by_site_month_2021-01_2026-09.csv | web analytics, page views by site and month | 621 |
| site_register.csv | site register | 10 |
| moderation_council_charter_2025.pdf | Moderation Council charter |  |
| handle_time_standards_2027.pdf | the council's 2027 handle-time standards |  |
| finance_envelope_2027_paid_moderation.pdf | finance's 2027 envelope |  |
| flag_service_standard.pdf | the flag service standard |  |
| member_survey_2026_ai_assistants.pdf | 2026 member survey on AI assistants |  |
| moderation_ops_notes.md | moderation operations notes |  |
| posts_warehouse_notes.md | posts warehouse notes |  |
| review_platform_data_dictionary.md | export field notes |  |

The 2 October pull of September was taken for the October ops review; the 8 October pull is the complete one.
