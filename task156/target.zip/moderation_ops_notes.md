# Moderation operations notes

Duane Zamora, head of moderation operations. Kept for the council's pool work; last updated 6 October 2026.

## The paid team

- The paid team works three shift patterns on Toronto time: days from 08:00, lates from 15:30 and nights from 23:00,
  each 8 paid hours with a 30-minute unpaid break. Part-time moderators work three shifts a week.
- Each moderator works one site's queues. Flags and routed review items reach the team through the moderation queue
  of the site they belong to.
- Statutory holidays observed in 2026 so far: 1 January, 16 February, 3 April, 18 May, 1 July, 3 August, 7 September.

## Hours

- The WFM system holds the shift lines. A line is approved by the moderator's lead the Monday after the shift, or on
  the day a correction is approved.
- When a week is corrected the WFM system re-sends the whole week: the original lines stay in the export marked
  `superseded` and the corrected lines come in `approved`. Only approved lines are hours worked.
- A shift's hours belong to the site the moderator worked for on that shift, and to the quarter in which the shift
  started, on Toronto time.
- The WFM system still labels Infrastructure & DevOps by its old name, Ops & Cloud.

## Queues

- The review platform replaced the old review system on 1 January 2024. The old system's monthly statistics job was
  kept for 2021 to 2023 in the monthly queue workbook.
- The platform's daily inbox export counts, for each site, entry day and item type, the items that entered the inbox
  and what became of them: reviewed by a volunteer, routed to the moderation queue, or still open when the export ran.

## Paid review hours

- The council follows the paid team's review work as paid review hours: each moderator flag a paid moderator handled
  and each community item routed to the team, at the handle-time standard in force for its year (close votes at 5.0
  minutes to the end of 2026, 2.0 from 2027), in the month the flag was raised or the item entered the inbox, on UTC.
  They are not the hours worked on the WFM lines.
- Months still to come are counted on the planning team's question plan, and October to December 2026 on its outlook.
