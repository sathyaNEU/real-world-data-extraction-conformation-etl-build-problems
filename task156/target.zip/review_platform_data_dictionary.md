# Review platform and moderator tool: export fields

## review_inbox_daily (one row per site, entry day and item type)

| Field | Meaning |
|---|---|
| site | site code (see the site register) |
| entry_date_utc | the day the items entered the site's review inbox, UTC |
| item_type | close_vote, first_post, low_quality or suggested_edit |
| entered | items that entered the inbox that day |
| reviewed_by_volunteer | of those, items a volunteer reviewer reviewed |
| routed_to_moderation | of those, items routed to the site's moderation queue |
| open_at_pull | of those, items neither reviewed nor routed when the export ran |
| pulled_at_utc | when the export ran |

entered is the sum of reviewed_by_volunteer, routed_to_moderation and open_at_pull on every row.

## reviewer_roster (one row per reviewer and site, every reviewer whose review access had not lapsed before 1 January 2024)

| Field | Meaning |
|---|---|
| account_id | network account id |
| site | the site the reviewer reviews on |
| access_granted | the day review access was granted (may be before the platform) |
| first_review_on_platform | the reviewer's first review on the platform (blank for a reviewer who made none) |
| last_review | the reviewer's last review before the export |
| access_status | active, or lapsed |
| lapsed_on | the day access lapsed |

A reviewer is active in a month in which they made at least one review. Review access lapses after a calendar month in
which the reviewer made no reviews, on the first day of the month after it: a reviewer whose last review fell in March
lapses on 1 May. A reviewer whose access lapsed and who asks for it again gets a new row.

## modtool_flag_summary_daily (one row per site and day)

| Field | Meaning |
|---|---|
| flags_raised | moderator flags raised that day, UTC |
| closed_post_deleted | of those, flags the platform closed because the post was deleted before a moderator acted |
| handled_by_moderator | of those, flags a paid moderator handled |

## modtool_flags (one row per flag)

| Field | Meaning |
|---|---|
| raised_at_utc | when the flag was raised |
| handled_at_utc | when the flag was marked handled |
| handled_by | the paid moderator's employee number, or system |
| outcome | helpful, declined or closed_post_deleted |
