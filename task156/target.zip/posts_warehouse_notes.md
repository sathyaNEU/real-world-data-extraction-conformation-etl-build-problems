# Posts warehouse: questions

Data platform team. The warehouse replaced the old reporting jobs on 1 January 2024.

- Questions are counted once each, in the month the question was first asked (UTC), on the site the question is on
  today.
- Months before January 2024 are not in the warehouse; the old review system's monthly queue workbook carries the
  question counts its statistics job reported for 2021 to 2023.
- The old statistics job counted a question on every site it was posted to. A question moved to another site is posted
  there anew under a new question id, so the job counted it on its first site in the month it was asked and on its new
  site in the month it moved.
- Comparisons with 2021 to 2023 are made on the warehouse's basis.
- The planning team's question plan counts questions the way the warehouse does.
- Deleted questions are counted in the month they were asked.
