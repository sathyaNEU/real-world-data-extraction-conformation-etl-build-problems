# HLS analysis files: data dictionary

Survey Data Office, Merrowland Statistics. Applies to the extract of 20 October 2026.

## hls_person_quarter_2023q1_2026q3.parquet

One row per person aged 15 and over in a responding household, per quarter.

| column | content |
|---|---|
| quarter | survey quarter, YYYYQn |
| serial | address serial (see the extract notes for the July to September 2026 format) |
| person_no | person's line number in the household roster at the interview |
| wave | 1 to 5, the address's quarter in the survey |
| mode | CAPI (face to face) or CATI (telephone) |
| region | region code: VEL Velmouth, CAR Carrowdene, PEL Pellard, HAS Haskvale, TIR Tirrin, DUN Dunmarrow |
| sex | 1 male, 2 female |
| date_of_birth | as reported |
| age | age at the middle of the quarter |
| ilo_status | 1 employed, 2 unemployed, 3 not in the labour force (methods note, section 3) |
| actual_hours | hours actually worked in the reference week, all jobs; blank if not employed |
| weight | final person weight for the quarter |

## hls_call_records_2024q1_2026q3.csv

One row per call record uploaded from the call-record application, for addresses issued for a first interview in the intakes of January to March 2024 to July to September 2026.

| column | content |
|---|---|
| record_id | call record id, assigned on upload |
| serial | address serial |
| intake | quarter the address was issued |
| area_code | interviewer area; region and district from the address register |
| interviewer | interviewer id |
| visit_no | the visit's number at the address |
| visit_start | local date and time the visit started |
| outcome | 110 interview, 210 refusal, 310 no reply, 410 not eligible (vacant, demolished or not residential) |
| uploaded | local date and time the record reached the server |

## hls_address_register_2024q1_2026q3.csv

One row per address issued for a first interview, January to March 2024 to July to September 2026: serial, intake, area_code, region, urban_rural, dwelling_type.
