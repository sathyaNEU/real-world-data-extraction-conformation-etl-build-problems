# HLS extract notes, 20 October 2026

Prepared by Dylan Fletcher (Survey Data Office) for the Labour Market Statistics team. The July to September 2026 processing run locked on 20 October 2026; the files below are the extract taken that day.

## Files

- `hls_person_quarter_2023q1_2026q3.parquet`: person-quarter analysis file, January to March 2023 to July to September 2026.
- `hls_call_records_2025q1_2026q3.csv`: call records for first-interview addresses, intakes January to March 2025 to July to September 2026.
- `hls_address_register_2025q1_2026q3.csv`: the addresses issued in the same intakes.
- `population_controls_2023q1_2027q4.xlsx`: population controls (Population Estimates and Projections).
- `hls_release_tables_2026q2.xlsx`: the release tables for April to June 2026.
- `jobseeker_support_claimants_2023-01_2026-09.csv`: Jobseeker Support claimants by region and month (Ministry of Social Development extract).
- `field_staffing_2026-10.json`: field interviewers by region, October 2026.
- `hls_methods_note_2025.pdf`, `field_instruction_FI-2026-04_first_interview_visits.pdf`, `field_instruction_FI-2024-03_call_pattern.pdf`, `hls_data_dictionary.md`.

## Changes in this run

- From the July to September 2026 processing run, address serials carry a check digit as a tenth character. Records from earlier runs keep the nine-character serial; the address register is unchanged.
- July to September 2026 is the second quarter whose wave-1 intake was issued under FI-2026/04.

## Not in this extract

- Interviewer workload and pay records.
- Visit histories for intakes before January to March 2025. The call-record application replaced the field's paper call sheets at the January to March 2025 intake and the paper sheets were never keyed.
- The October to December 2026 intake (issued 1 October; first call records arrive with the next run).
