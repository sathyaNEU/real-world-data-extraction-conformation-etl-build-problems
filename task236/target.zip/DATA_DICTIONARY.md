# Data dictionary

Dates are local (Australian Eastern Standard Time, UTC+10, no daylight saving from April to September) unless a field
says UTC. Report weeks are ISO weeks, Monday to Sunday.

## gateway_influenza_results_2027-04-05_to_2027-09-12.csv

One row per result the notification gateway received from 5 April 2027 to the extract at 06:30 on Tuesday 14 September
2027, for specimens collected from 5 April to 12 September 2027.

| field | meaning |
|---|---|
| result_id | the gateway's id for the result message |
| specimen_id | the reporting service's accession number for the specimen |
| service_code | the reporting service (see reporting_services.csv) |
| service_type | laboratory or point of care |
| method | PCR, multiplex respiratory panel or rapid antigen |
| analyte | what the result reports on: Influenza A and B, or, for a multiplex panel, Influenza A or Influenza B on its own row |
| result | the result as the service worded it |
| result_status | P for a preliminary report, F for a final report |
| patient_key | the gateway's key for the person, the same for every service |
| sex | F, M or X |
| age_years | age at collection |
| residential_postcode | the postcode of the person's residential address as given on the request; blank, or 0000 at some services, when the request had none |
| requester_postcode | the postcode of the requesting practice, hospital or clinic |
| requester_setting | general practice, emergency department, hospital inpatient or drive-through clinic |
| collection_date | the specimen's collection date |
| received_utc | when the result reached the gateway, UTC |

## sentinel_gp_weekly_returns_2027_wk14-36.csv

One row per sentinel practice and report week, weeks 14 to 36 of 2027.

| field | meaning |
|---|---|
| practice_code | the network's code for the practice |
| region_code | the health region the practice is in |
| iso_week | the report week |
| week_ending | the Sunday the week ends |
| list_size | the practice's registered patients, as at the start of the quarter |
| consultations | consultations by the practice's participating general practitioners in the week; blank when the return was not received |
| ili_consultations | consultations for influenza-like illness in the week; blank when the return was not received |
| return_status | received or not received |

## sentinel_gp_protocol_swabs_2027_wk14-36.csv

One row per protocol swab collected by a sentinel practice, weeks 14 to 36 of 2027.

| field | meaning |
|---|---|
| swab_id | the network's id for the swab |
| practice_code | the practice that took it |
| collection_date | the collection date |
| influenza_a, influenza_b, rsv, sars_cov_2 | detected or not detected by the Public Health Laboratory's multiplex PCR; blank when the swab was not tested |
| lab_comment | the laboratory's comment when the swab was not tested |

## postcode_health_region_concordance.csv

The postcodes of the state and their health regions, with the dates each assignment is in force (effective_to blank:
in force now).

## postcode_erp_30_june_2026.csv

Estimated resident population at 30 June 2026 by postcode (the state statistician's postcode series, released March
2027).

## reporting_services.csv

The services that report influenza results to the gateway.

## testing_change_register_2027.xlsx

Sheet Register: the testing change register, one row per change. Sheet Notes: about the register.

## influenza_vaccine_doses_by_region_2027_wk14-36.csv

Influenza vaccine doses recorded in the immunisation register by region and week, general practice and pharmacy.

## laboratory_turnaround_by_week_2027.csv

Each laboratory's weekly turnaround, specimen collection to the final report reaching the gateway, by week of collection
(collection taken as 10:00 on the collection date), weeks 14 to 35.
