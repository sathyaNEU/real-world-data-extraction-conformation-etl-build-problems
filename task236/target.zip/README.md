# Weekly influenza report, week 36 of 2027: extract for the testing-change break flags

Extracted at 06:30 on Tuesday 14 September 2027 for the week 36 report (the week of Monday 6 to Sunday 12 September) and
the sign-off of its testing-change break flags.

- `influenza_report_data_quality_protocol_CDB-FLU-03.pdf`: the report's data quality protocol (CDB-FLU-03 version 4).
- `sentinel_gp_network_protocol_SGP-2027.pdf`: the sentinel general practice network's protocol for 2027.
- `gateway_influenza_results_2027-04-05_to_2027-09-12.csv`: the notification gateway's influenza results.
- `sentinel_gp_weekly_returns_2027_wk14-36.csv`: the sentinel practices' weekly returns.
- `sentinel_gp_protocol_swabs_2027_wk14-36.csv`: the sentinel practices' protocol swabs and their results.
- `testing_change_register_2027.xlsx`: the testing change register.
- `postcode_health_region_concordance.csv`: the postcode concordance.
- `postcode_erp_30_june_2026.csv`: estimated resident population by postcode.
- `reporting_services.csv`: the reporting services.
- `influenza_vaccine_doses_by_region_2027_wk14-36.csv`: influenza vaccine doses by region and week, from the immunisation register.
- `laboratory_turnaround_by_week_2027.csv`: laboratory turnaround by week, from the gateway.
- `DATA_DICTIONARY.md`: the fields of every file.
