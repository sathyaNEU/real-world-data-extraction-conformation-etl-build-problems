# Brännvik Plus 2027 reach extracts: data dictionary

Prepared by the CRM team (Victor Malmström, CRM manager), 12 January 2028. One section per file in this folder; row counts and
extract times are in `export_manifest.csv`. Member-level files carry `member_id` and `household_id` only. Names, postal
addresses, email addresses and phone numbers stay in the source systems (contact policy, section 7).

## Conventions

- `member_id` is `BP` followed by eight digits, the last of them a check digit (Luhn). It is the member key in every
  member-level file; the SMS gateway calls it `customer_ref` and the direct mail file `addressee_member_id`.
- `household_id` groups the accounts registered at the same address.
- Each system writes time its own way, stated per file: the consent platform and the email platform in UTC, the
  SMS gateway and the POS in Swedish local time without an offset, the app messaging platform in ISO 8601 with the
  Swedish offset, Meta as dates in the ad account's time zone (Europe/Stockholm). Sweden moved to summer time on
  28 March 2027 and back on 31 October 2027.
- Amounts are SEK. Till amounts include VAT; Meta spend excludes VAT.
- Campaign codes (`BV27-01` to `BV27-14`) and drop and offer codes are those of `campaign_calendar_2027.xlsx`.

## crm_members_extract_2028-01-08.csv

CRM extract taken on 8 January 2028. One row per Brännvik Plus account that was open at any time on or after
1 January 2026; accounts closed before that date are not in the extract.

| Column | Meaning |
|---|---|
| member_id | the account |
| card_number | the member's current card, 16 digits |
| household_id | the household the account is registered to |
| joined_date | the date the account was opened |
| signup_channel | where the account was opened: store_kiosk, web_signup or app_signup |
| home_store | the member's home store (`store_code`), chosen at signup and editable on My pages |
| postcode_area | the first three digits of the member's postcode |
| municipality | the municipality of the member's address |
| birth_year | year of birth (membership is from age 16) |
| email_on_file, mobile_on_file | Y when the CRM holds an email address or a mobile number |
| app_registered_date | the date the member first signed in to the app; blank if never |
| tier_2027 | the tier for 2027, set on 1 January 2027 from purchases paid in 2026; blank for accounts closed in 2026 |
| tier_2028 | the tier for 2028, set on 1 January 2028 from purchases paid in 2027; blank for closed accounts |
| account_status | open or closed on the extract date |
| closed_date | the date the account was closed |

Tiers: Silver from 18,000 SEK and Guld from 40,000 SEK of purchases paid with the member's card in the
calendar year, Bas below that.

## consent_snapshot_2026-01-01.csv

The consent state migrated into the consent platform when it went live on 1 January 2026 at 00:00 Swedish time, one
row per member who had joined by then. `email`, `sms`, `push` and `post` are Y (granted) or N. `post` is addressed
mail, where N means the member has objected.

## consent_events_2026-2027.csv

The consent platform's log: one row per change in a member's state on one channel, from 1 January 2026 to
31 December 2027.

| Column | Meaning |
|---|---|
| event_id | the log's running number |
| member_id | the account |
| channel | email, sms, push or post |
| action | granted or withdrawn |
| event_time_utc | when the platform recorded the change (UTC) |
| source | store_kiosk, web_signup or app_signup (given on joining); my_pages; customer_service; app_settings; esp_unsubscribe and esp_complaint (from the email platform); sms_stop (STOPP replies, from the SMS gateway); account_closed |

A member's state at a moment is the snapshot state (N for members who joined later) updated by the log's rows up to
that moment. Changes made at the email platform or the SMS gateway reach the log with the next collection, up to 15
minutes after the member acted; both systems stop sending to the member at once.

## campaign_calendar_2027.xlsx

The campaign manager's calendar (Mia Nygren). `Kampanjer 2027` has one row per campaign (code, name,
purpose, channels, dates, audience, planned budget in thousand SEK, owner). `Utskick` has one row per planned drop:
email mailings, SMS and push sends with their planned Swedish time, and addressed mail drops with their posting and
selection dates; the welcome automation is listed at the end. `Erbjudanden` has one row per personal offer loaded
to members' cards, with its validity and the members it was loaded to.

## esp_mailings_2027.csv

Email platform: one row per mailing. `mailing_id` is BV27-01-N01 to N26 for the newsletter issues, BV27-xx-E1 and
E2 for campaign mailings and BV27-02-W1 to W3 for the welcome automation. `type` is newsletter, campaign or
automation; `scheduled_utc` is blank for the automation; `sends` is the mailing's rows in `esp_sends_2027.parquet`.

## esp_sends_2027.parquet

Email platform: one row per message sent to a member in 2027.

| Column | Meaning |
|---|---|
| send_id | the message |
| mailing_id | the mailing |
| member_id | the subscriber key |
| sent_at | when the message left the platform (UTC) |
| status | delivered; soft_bounce (temporary failure, not retried); hard_bounce (the address does not exist; the platform suppresses it from then on) |

## esp_events_2027.parquet

Email platform: one row per tracked response to a message. A message can have several opens.

| Column | Meaning |
|---|---|
| event_id, send_id, mailing_id, member_id | the response and the message it belongs to |
| event_type | open, click, unsubscribe or spam_complaint |
| event_at | when the platform recorded it (UTC) |
| client | on opens, the mail client that loaded the tracking image. Apple Mail Privacy Protection marks images loaded through Apple's proxy, which Apple Mail does for most delivered messages whether or not they are read |
| link | on clicks: offer, recipes, store_finder, app_download or other |

## sms_gateway_log_2027.csv

SMS gateway: one row per message submitted.

| Column | Meaning |
|---|---|
| message_id | the gateway's id |
| sender | the alphanumeric sender shown on the phone |
| campaign_ref | the drop (`Utskick`) |
| customer_ref | the member_id |
| operator | the recipient's network |
| submitted, status_time | Swedish local time, no offset |
| status | the operator's delivery receipt: DELIVRD delivered to the handset; UNDELIV undeliverable; EXPIRED not delivered within the 48-hour validity period; REJECTD refused by the network and not charged |
| segments | message parts of up to 160 characters |
| price_sek | the gateway's charge |
| reply_text, reply_time | STOPP replies, which the gateway passes on as withdrawals |

## app_push_log_2027.jsonl

App messaging platform: one JSON object per line, one per notification sent to a member's device. Keys:
`notification_id` (the drop), `member_id`, `platform` (ios or android), `sent_at` (ISO 8601 with the Swedish
offset), `status` (delivered or failed), `failure_reason` (on failed rows: unregistered when the app is no longer
installed, expired_token when the device token had lapsed) and `opened_at` (only when the member opened the app
from the notification).

## direct_mail_drops_2027.csv

The print house's address file with PostNord's returns: one row per piece. `addressee_member_id` is the household's
main card holder on the selection date; `version` is Standard or Guld; `returned_date` is the date PostNord
returned the piece as undeliverable.

## meta_ads_daily_2027.csv and meta_ads_lifetime_2027.csv

Meta Ads Manager exports, downloaded by Gustav Engström. The daily file has one row per ad set and day with
delivery; the lifetime file one row per ad set over its flight. Reach counts accounts that saw an ad at least once in
the row's reporting period, so daily reach does not add up to lifetime reach. Frequency is Impressions over Reach.

## member_store_month_2027.parquet

BI warehouse: one row per member, store and month with at least one purchase with the member's card in 2027.

| Column | Meaning |
|---|---|
| member_id, store_code | the member and the store |
| month | YYYY-MM |
| visits | receipts with the member's card |
| spend_sek | amount paid, after offer discounts |
| offer_discount_sek | discounts from personal offers on those receipts |
| offers_redeemed | personal offers redeemed on those receipts |

## pos_offer_redemptions_2027.csv

POS loyalty engine: one row per personal offer redeemed at a till, semicolon-separated with decimal commas as the
POS exports it. `receipt_id` is the store and the receipt number, `redeemed_at` is Swedish local time,
`receipt_total_sek` is the amount paid after the discount. A receipt redeems one offer. These receipts are part of
`member_store_month_2027.parquet`.

## stores.csv and postcode_areas.csv

`stores.csv`: one row per store (code, name, municipality, county, postcode area, format Stor, Mellan or Nära,
sales area in square metres, year opened). `postcode_areas.csv`: one row per three-digit postcode area in the two
counties, with its municipality and municipality code, county, population on 31 December 2026 and households.
