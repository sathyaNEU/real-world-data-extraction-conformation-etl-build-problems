# Data dictionary

Household Relief Grant, round folder for the 2027/28 referral ceiling schedule.
Prepared by the Grants and Assurance Office. Extract date 2027-04-30. Issue 3.

A row of a claim return is one partner, one household-size band and one claim month. A row of the
portal export is one award. An award is counted in the month in which the partner paid the
household, and `claim_return_month` on a portal row is that month.

## hrg_claim_returns_fy2026-27.xlsx, hrg_claim_returns_fy2025-26.xlsx, hrg_claim_returns_fy2024-25.xlsx

The monthly claim returns the claims system holds. The 2026/27 workbook carries the layout the
Office introduced on 1 July 2026: a four-row header block above the table, the band column labelled
`household_size_band` with the HH1 to HH6 codes, `awards` and `total_claimed_php` in place of
`award_count` and `claim_total_php`, and a `return_status` column. The two earlier workbooks carry
the former layout and the B1 to B6 band codes.

| field | meaning |
|---|---|
| `return_month`, `claim_month` | the claim month, as `YYYY-MM` in the earlier layout and as `Mon-YYYY` in the 2026/27 layout |
| `partner_code` | the partner's code in the grants ledger |
| `hh_band`, `household_size_band` | the household-size band of the awards on the row |
| `award_count`, `awards` | the number of awards the partner resolved with a payment in the month, in that band |
| `claim_total_php`, `total_claimed_php` | the total amount of those awards, in pesos |
| `return_status` | `FINAL` a return for a month that was not reopened; `PRELIM` a return for a reopened month; `REVISED` a return filed after `PRELIM` for the same partner and month |

A negative `awards` and amount is a recovery of an award paid in an earlier month, claimed as its own
line in the month of recovery.

## portal_awards_2025-01_2027-03.csv

The partner claim portal's export, one row per award, for awards resolved from January 2025 by
partners in the portal provinces.

| field | meaning |
|---|---|
| `portal_award_ref` | the portal's reference for the award |
| `portal_partner_id` | the partner's identifier in the portal |
| `partner_ref_portal` | the partner reference as the portal stores it, loaded from a flat file when the partner was enrolled; `partner_identifier_crosswalk.csv` maps it to `partner_code` in the grants ledger |
| `province_code` | the province of the partner |
| `claim_return_month` | the claim month on whose return the award was claimed |
| `application_date`, `decision_date`, `payment_date` | the dates the household applied, the partner resolved the application and the partner paid the household |
| `household_size` | the number of persons in the household |
| `size_band` | the household-size band, B1 to B6 |
| `component_code` | the eligible component of the award, as Schedule D of the policy lists them |
| `award_amount_php` | the amount reimbursed to the partner for the award, in pesos |

## hrg_partner_accreditation_register.csv

One row per partner the Foundation has accredited. `accreditation_status` is `ACTIVE`, `WITHDRAWN`
where the partner has given up its accreditation, or `LAPSED` where a term ended and was not
renewed; `status_date` carries the date of a withdrawal or a lapse.

## partner_identifier_crosswalk.csv

The mapping between portal accounts and the grants ledger. `account_status` is `LIVE` for an account
that records awards, or `OPENED_NOT_LIVE` for an account opened for a partner that did not join the
portal.

## household_size_bands.csv, province_reference.csv

Reference tables. `legacy_band_code` carries the HH1 to HH6 codes and `band_code` the B1 to B6 codes
for the same bands. `household_size_to` is blank for the open band. `portal_pilot_from` is the date
the portal opened in a province and is blank where it has not.

## treasury_disbursement_runs_2026_2027.csv

The Treasury's fortnightly payment runs. `gross_php` is what was paid out to the partner in the run,
`recoveries_php` what was recovered from it, and `net_php` the amount transferred. A run covers the
awards a partner paid in one half of a claim month and is dated in the following month.

## hrg_claim_check_register_2024_2025.csv

The Office's pre-payment claim check register. Until 31 December 2025 a return was checked before
the claim was passed for payment and an amount the check could not pass was held back; from 1
January 2026 a return is paid in full and reviewed after payment.

| field | meaning |
|---|---|
| `check_ref` | the register's reference for the check |
| `claim_month` | the claim month of the return that was checked |
| `claims_partner_ref` | the partner's reference in the claims system |
| `received_date` | the date the Office received the return |
| `checked_date` | the date of the check |
| `checker_ref` | the officer who checked the return |
| `awards_passed` | the number of awards the check passed for payment |
| `amount_passed_php` | the amount passed for payment, in pesos |
| `amount_held_php` | the amount held back, in pesos |
| `hold_reason` | the reason recorded against a hold |

## treasury_disbursement_runs_2024_2025.csv

The Treasury's archived payment runs, retrieved for the reconciliation of the closed claim months.
The columns are those of treasury_disbursement_runs_2026_2027.csv.

## hrg_household_followup_survey_2026.csv

The 2026 household follow-up survey, a sample of households whose awards were paid in 2026.
`days_to_payment` is the days from the partner's decision to its payment, and `adequacy_rating` the
household's answer on a five-point scale.

## export_manifest.csv

What each file in the folder is, what it covers and what it omits.
