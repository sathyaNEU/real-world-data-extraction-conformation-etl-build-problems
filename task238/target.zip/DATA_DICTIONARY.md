# Data dictionary

Dates are Halvreth dates. Halvreth time is UTC+12, and UTC+13 under daylight time.

## mwt_cst27_issued_addresses.csv

The sample management system's extract for CST-27, taken 11 October 2027: one row per issued address.

| field | meaning |
|---|---|
| address_id | the address, as on the Halvreth Address Register |
| login_code | the household's login code for the online questionnaire, printed on its letters |
| quarter | the tracker quarter the address was issued in |
| release | the fortnightly batch (1 to 6) |
| region_code | region, as in mso_regions_2027.csv |
| dwelling_type | house, flat or rural, from the register |
| letter | the letter the address was allocated: A (web-first) or B (telephone-first) |
| letter_mailed | the date the first letter was mailed |
| final_outcome | the system's final outcome code for the address (below) |
| outcome_date | the date the final outcome was recorded |

Outcome codes: 1.1 complete; 1.2 partial; 2.1 refusal; 2.2 non-contact; 2.3 other non-response; 3.1 eligibility not
settled; 4.1 vacant; 4.2 not a private dwelling; 4.3 address not found.

## mwt_cst27_web_returns.csv

The web platform's export for CST-27 logins, taken 11 October 2027: one row per session that saved an answer.

| field | meaning |
|---|---|
| response_id | the platform's id for the session |
| login_code | the login code the session was opened with |
| opened_by | respondent (opened with the login code from the letter) or staff (opened by office staff) |
| device_type | the device type the platform recorded |
| started_utc | when the session opened (UTC) |
| submitted_utc | when the return was submitted at the end of the questionnaire (UTC); blank if it was not |
| last_saved_utc | when the session last saved an answer (UTC) |
| last_section | the last questionnaire section reached (6 is the end) |
| Q01 to Q17 | answers, on the codes in mwt_questionnaire_codebook_v9.xlsx |
| age, sex, qual, emp, tenure, hhsize | section 5 answers, on the codes in mwt_questionnaire_codebook_v9.xlsx |

## mwt_cst27_cati_interviews.csv

The CATI system's interview export for CST-27, taken 11 October 2027: one row per interview started.

| field | meaning |
|---|---|
| CASE_ID | the CATI case |
| ADDRESS_ID | the address |
| INTERVIEWER | the interviewer |
| START_TIME, END_TIME | the interview's start, and the time the interviewer coded its result, the CATI system's clock (Halvreth time) |
| RESULT | C complete; P partial (broken off) |
| Q01 to Q17 | answers, on the codes in mwt_questionnaire_codebook_v9.xlsx |
| AGE, SEX, QUAL, EMP, TENURE, HHSIZE | section 5 answers, on the codes in mwt_questionnaire_codebook_v9.xlsx |

## mwt_cst27_cati_call_records.csv

The CATI system's call records for CST-27: one row per call attempt (CASE_ID, ATTEMPT, CALL_TIME in Halvreth time,
RESULT: NA no answer, BZ busy, AM message left, AP appointment, CB call back, RF refusal, WN wrong number, IC interview
complete, IP interview partial).

## mwt_published_indexes_2019q1_2027q2.csv

The tracker's published headline estimates from the first quarter of 2019 to the second quarter of 2027, telephone-first
throughout: quarter, index, estimate, its 95 per cent margin of error, completes, the percentage of completes made
online, and the release date.

## mso_regions_2027.csv

Regions, with the register's 2027 counts of households and adults.

## mwt_questionnaire_codebook_v9.xlsx

Sheet Questions: each question's wording, answers and export codes in each system. Sheet Indexes: how each headline
index is scored. Sheet Sections: the questionnaire's sections.
