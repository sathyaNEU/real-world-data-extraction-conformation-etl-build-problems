# CST-27 files

The methods team's copy of the 2027 contact strategy test's files, with the standard and plan they were run under,
compiled by Leonard McMurray (Data Processing Lead) on Monday 18 October 2027.

- `mso_ms14_tracker_continuity_standard.pdf`: Methods Standard MS-14, continuity of the Halvreth Wellbeing Tracker through the move to web-first collection.
- `mwt_cst27_plan.pdf`: the CST-27 test plan.
- `mwt_cst27_close_out.docx`: the fieldwork manager's close-out.
- `mwt_cst27_issued_addresses.csv`: the sample management system's issued addresses and outcomes.
- `mwt_cst27_web_returns.csv`: the web platform's export.
- `mwt_cst27_cati_interviews.csv`: the CATI system's interview export.
- `mwt_cst27_cati_call_records.csv`: the CATI system's call records.
- `mwt_questionnaire_codebook_v9.xlsx`: the questionnaire codebook, version 9.
- `mwt_published_indexes_2019q1_2027q2.csv`: the tracker's published headline estimates, 2019 to the second quarter of 2027.
- `mso_regions_2027.csv`: regions.
- `DATA_DICTIONARY.md`: the files and their fields.
