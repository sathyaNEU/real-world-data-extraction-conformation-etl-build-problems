# LSL data extract, January 2027: field notes

Prepared by GIS and Asset Records for the LSLR programme office, 8 January 2027. One section per file. The extract
log (extract_log_2027-01-08.csv) gives each file's source system, date and row count.

## hfrwd_service_line_inventory_20270108.csv

One row per service line (main to meter setting) in the district's lead service line inventory, all fourteen zones,
as of 8 January 2027.

- `sl_id`: GIS service line id.
- `service_address`, `municipality`: the premise address.
- `zone`: the line's replacement zone under plan revision 2, RZ-01 to RZ-14.
- `main_segment`: GIS id of the water main segment the service taps.
- `year_built`: the premise's year built, from the county assessor; 0 where the assessor carries none (most
  non-residential parcels).
- `tap_card_material`: the material on the district's tap card (LEAD, GALV, COPPER, PLASTIC); blank where no usable
  card survives.
- `sl_class`: LEAD, GRR, NON-LEAD or LEAD STATUS UNKNOWN.
- `class_basis`: RECORDS (tap card), FIELD VERIFIED, CONSTRUCTION DATE (built in or after 1989) or REPLACED (found
  lead or GRR and replaced in full, NON-LEAD since); blank for Lead Status Unknown. A galvanized tap card line is GRR
  until it is verified.
- `field_verified_on`: date of the line's latest field verification.
- `replaced_on`: date the line was replaced in full.

## sl_field_verifications_2021_2026.csv

One row per field verification of a service line's material, 4 January 2021 to 18 December 2026. A line verified
more than once has a row for each visit.

Lines come to be verified in one of two ways. When a water main is replaced under the distribution system renewal
programme (from 2023), every service on the replaced main is exposed and its material recorded before it is
reconnected. Every other row is a visit to a single line, raised by a customer reporting lead or galvanized pipe or
asking for a check, a leak on the service, a lead and copper sampling site (2021 and 2022) or the 2024 consultant
ranking of services likely to be lead (2024 and 2025).

- `source`: CIS for the customer system's service orders (to 12 March 2023), WMS for the work management system
  (from 13 March 2023).
- `wo_no`: service order (CIS) or work order (WMS) number.
- `verified_date`: MM/DD/YYYY on CIS rows, YYYY-MM-DD on WMS rows.
- `premise_no`: customer system premise number, CIS rows.
- `sl_id`: GIS service line id, WMS rows.
- `method`: EXCAVATION, POTHOLE (vacuum excavation at the curb stop), CURB BOX CAMERA, METER PIT VISUAL.
- `crew`: district crews SLV1 to SLV5; contractor crews BRN-1 and BRN-2 (Brannigan Excavating), TCU-1 and TCU-2
  (Tri-County Underground), KPU-1 (Kestrel Pipe and Utility).
- `result_code`: the material found, in the codes of the form it was recorded on (sl_material_result_codes.csv).

## cis_gis_crosswalk_2023.csv

Customer system premise numbers to GIS service line ids, built for the 13 March 2023 cut-over. `legacy_premise_no`
is zero-padded to eight digits; the customer system printed premise numbers without the leading zeros.
`match_method` is how the pair was matched (ADDRESS, METER, FIELD).

## sl_material_result_codes.csv

Every result code used on the three recording routes, with the material and the class it posts to the inventory.

## lsl_completions_2026.csv

Full replacement completions under the 2026 replacement contracts, from the contract management module of the work
management system. One row per closing of a work order.

- `site_id`: GIS service line id.
- `completed_utc`: completion time stamped by the field tablet, in UTC.
- `closed_on`: date the work order was closed.
- `row_status`: CLOSED, or RECLOSED when a closed work order was reopened for a correction and closed again; the
  export keeps both closings, and the reclosing's paid amounts replace the first closing's.
- `paid_base`, `paid_extra_ft`, `paid_restoration`: paid on the pay application for the site: the bid price, the
  service length past 50 feet at the contract rate, and restoration.
- `co_no`, `co_amount`: the approved change order that covers the site, and the change order's amount.

## contracts_2026.csv

The three 2026 replacement contracts, with the vendor records they were paid under, award dates, zones and bid
prices.

## change_orders_2026.xlsx

The engineer's log of approved change orders on the 2026 contracts.

## access_agreements_2022_2026.csv

Right-of-entry agreements for work on the private side of the line, from the agreement system, one row per form.
Agreements on lines since replaced or verified non-lead are archived and are not in this file.

- `signed_on`: date the form was signed.
- `channel`: PAPER (mailed form) or PORTAL (online, from 3 June 2024).
- `premise_no`: customer system premise number, on forms signed before 13 March 2023.
- `sl_id`: GIS service line id, on forms signed from 13 March 2023.
- `zone_on_form`: the replacement zone printed on the form.
- `status`, `status_date`: SIGNED or WITHDRAWN, and the date of that status.

## Documents

- HFRWD_LSLR_plan_rev2_2026-10.pdf: the replacement plan, revision 2.
- HFRWD_capital_improvement_plan_2027-2037_board_draft.docx: the capital improvement plan, board draft.
- unit_cost_schedule_2027.xlsx: the 2027 unit cost schedule.
- LSLR_progress_report_2026.pdf: the programme office's 2026 progress report.

## Other extracts in the folder

- lcr_tap_samples_2025_2026.csv: lead and copper compliance samples at the tier 1 sites, 2025 and 2026, from the laboratory system.
- ami_meter_exchanges_2023_2025.csv: meter exchanges under the automated metering rollout, April 2023 to December 2025, from the meter shop.
