# Yard notes, August 2026

Gabriel Wyatt, Fleet Services. For the fuel review; the unit list is the maintenance system's as of today.

Every yard runs Monday to Friday and is closed on weekends and company holidays (Labor Day, September 7; Thanksgiving, November 26 and 27).

Each yard has one above-ground diesel tank (sizes on the tank register) and a self-serve island on the fuel management system. The islands have been on standby since the fleet moved to fuel cards in 2023, apart from the Jackson and Knoxville programmes in 2025. The fobs issued for those programmes still work at every island, and new units get a fob at delivery.

## West (Delta's direct-bill account)

- Memphis, branch 21, 4410 Getwell Road: 18 Sprinter vans and 11 straight trucks on metro routes.
- Jackson, branch 24, 117 Industrial Park Drive: 10 straight trucks on metro routes, 9 day cabs on the regional day runs and 2 sleepers on the Mississippi, Arkansas and Kentucky routes.

## Central (Keeble's Crossroads account)

- Nashville, branch 31, 2650 Couchville Pike: 13 straight trucks on metro routes and 15 sleepers on the Kentucky, Alabama and Georgia routes. Two spare M2s are kept at the yard for breakdowns.
- Cookeville, branch 35, 1290 Interstate Drive: 8 straight trucks at the yard; 32 Sprinter vans based at the Sparta and Crossville lots (leased spaces since 2024), stocked by shuttle from the yard.

## East (Holston's SMPM account)

- Knoxville, branch 41, 5320 Middlebrook Pike: 14 Sprinter vans on metro routes and 10 sleepers on the Kentucky, Carolina and Virginia routes.
- Blountville, branch 46, 1915 Highway 75: 4 straight trucks on metro routes and 11 sleepers on the Virginia, West Virginia and Kentucky routes.

## Fuel

Each account's vehicles carry that account's cards and buy wherever the route takes them.
