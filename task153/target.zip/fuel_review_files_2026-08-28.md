# Fuel review: the files pulled on August 28

Pulled by Gabriel Wyatt (Fleet Services) on Friday, August 28, 2026. The telematics files and the Riverbend and Crossroads downloads run through Thursday, August 27; the last SMPM batch received covers the week to Sunday, August 23.

## Fleet and telematics

- `vehicle_days_2024-09-01_2026-08-27.csv`: the telematics service's vehicle-day export, one row for each day a vehicle's engine ran, September 1, 2024 to August 27, 2026.
- `geofence_events_2026-03-01_2026-08-27.csv`: the telematics service's geofence entries and exits, March 1 to August 27, 2026 (the service keeps 180 days of geofence history).
- `telematics_device_assignments.csv`: which telematics device was fitted to which vehicle, and when.
- `fleet_units_2026-08.xlsx`: the maintenance system's unit list and model specifications.
- `yard_notes_2026-08.md`: the fleet manager's yard notes.

## Yard tanks and islands

- `yard_tank_register.xlsx`: the six yard tanks.
- `fms_island_transactions_2025.csv`: the fuel management system's island transactions for 2025, the Jackson and Knoxville programmes.

## Card accounts

- `riverbend_direct_bill_2024-09_2026-08.csv`: Delta's direct-bill transactions, downloaded from the Riverbend fleet portal.
- `crossroads_transactions_2024-09_2026-08.xlsx`: Keeble's Crossroads Fleet Card transactions, exported from the Crossroads portal.
- `smpm_card_activity_2024-09_2026-08.txt`: Holston's SMPM member transaction files, as received, one weekly batch after another; layout in `smpm_member_transaction_file_layout_v3.pdf`.
- `card_programmes_pricing_schedules.pdf`: the pricing schedules of the three card programmes.
- `ifta_returns_2025Q3-2026Q2.xlsx`: the IFTA returns filed for the three licences, third quarter 2025 to second quarter 2026.

## Overton

- `overton_offer_2026-08-26.pdf`: Overton's offer of August 26.
- `overton_jackson_tank_programme_2025-03-03.pdf` and `overton_knoxville_tank_programme_2025-06-02.pdf`: Overton's letters for the 2025 Jackson and Knoxville programmes.
- `overton_deliveries_2025.csv`, `overton_invoices_2025.csv` and `overton_credit_memos_2025.csv`: Overton's 2025 delivery tickets, invoices and credit memos for the two programmes, from Overton's customer portal.
- `overton_rack_postings_2024-09_2026-08.csv`: Overton's daily posted rack and the TriState contract average for ULSD No. 2 at Memphis, Nashville and Knoxville, by effective date.
- `overton_tank_wagon_prices_2026-08-24.pdf`: Overton's tank wagon prices for the week of August 24.
