# Diccionario de datos, Registro de Acciones Colectivas

Edicion 9, 5 de noviembre de 2026. Describe los archivos del extracto de esa fecha.

## rac_acciones_2024.csv, rac_acciones_2025.csv, rac_acciones_2026.csv

Una fila es una entrada del registro. Hasta la plantilla de 2025 cada dia de una accion prolongada
ocupa su propia fila; desde 2026 la fila describe la accion y el campo `dias` indica cuantos dias
corrio. La exportacion de 2025 renombro las columnas y escribe las fechas en formato dia primero.

| Campo | Significado |
|---|---|
| action_id, id_accion | identificador de la entrada, unico dentro del anio y del departamento |
| fecha_accion, fecha_de_accion | fecha de ocurrencia de la accion |
| fecha_registro, fecha_de_registro | fecha en que el equipo abrio la entrada |
| municipio | municipio de ocurrencia |
| divipola, cod_divipola | codigo del municipio vigente a la fecha de la accion |
| tipo_accion, tipo | tipo de accion segun el manual |
| sector_actor, sector | sector de la organizacion convocante, lista vigente |
| participantes_est, participantes | estimacion central de participantes; cero cuando la fuente no reporta cifra, vacio cuando la fuente reporta un rango que queda transcrito en la nota |
| nota_registro, nota | transcripcion del codificador, incluye el rango cuando la fuente reporta uno |
| dias | dias que corrio la accion (solo plantilla 2026) |
| extracto | preliminar o definitivo (solo plantilla 2026) |

## envios_resena_andina.csv

Una fila es un dia en que un medio remitio material fechado en un municipio. `items_entregados`
cuenta cuanto remitio el servicio desde ese municipio.
`items_retenidos` cuenta los items que el filtro del registro conservo para revision, es decir los
que pueden describir una accion. `periodo_publicacion` es el mes en que se publicaron los items de
la fila, que no siempre es el mes de la remision. Los codigos de fuente llevan el prefijo RSA desde
2026, cuando el servicio renumero sus mesas.

## citas_rac.csv

Una fila es una cita: un item que el registro vinculo a una entrada. Una entrada puede tener varias
citas y un item puede citar mas de una entrada.

## resumen_mensual_rac_2025.csv

Resumen mensual publicado, armado con los retornos de las mesas del servicio. Una mesa atiende mas
de un municipio y reporta bajo su sede, de modo que la columna `municipio_sede` es la sede de la
mesa y no necesariamente el municipio de ocurrencia.

## tabla_municipios.csv

Codigos DIVIPOLA con sus fechas de vigencia. Tres municipios recibieron codigo nuevo en julio de
2025 cuando la lista nacional reasigno sus codigos.

## panel_fuentes.xlsx, proyecciones_poblacion.xlsx

Panel de medios vigente al cierre, una hoja por tipo. Proyecciones municipales de poblacion en
unidades y en miles, mas la serie anterior al censo.

## Otros archivos del extracto

`indice_menciones_redes.csv`, indice departamental de menciones en redes, contratado en 2026.
`incidencias_viales.csv`, incidentes de la autoridad de transporte.
