# Data dictionary

## wastewater_sites_register.csv
The service's register of the plants it samples, one row per plant: plant_code; plant_name; serves (the towns the plant
serves); population_served (people served, the register's figure).

## phl_wastewater_results_2026-01_2028-04.csv
The Southern Plains Public Health Laboratory's wastewater results, one row per sample, target and analysis run: sample_id; plant_code; composite_end
(the composite's end, local date and time); target (N1 or PMMoV); plate; analysed (the date the run was analysed);
result_gc_per_l (gene copies per litre of wastewater); status (accepted, rejected or check); composite_flow_m3 (the flow
on the chain-of-custody form, cubic metres); comment.

## rangeview_report_WL-2801.xlsx
Rangeview Analytical's report of the composites it analysed during the laboratory's January closure, one row per sample and
analyte under a header that describes the method: lab ref; client site; sampled (the date the composite ended);
received; analyte; result; flow on the chain-of-custody form (cubic metres).

## spw_inlet_historian_hourly_2026-01-05_2028-04-09.csv
Southern Plains Water's inlet historian, one row per plant and hour: plant_code; timestamp_local (yyyy-mm-dd hh:mm, the start of
the hour); inlet_flow_m3h (cubic metres an hour); inlet_temperature_c (degrees Celsius).

## paired_upstream_study_2026_results.csv
The paired upstream sampling study, one row per plant, visit, sampling point and replicate: plant_code; visit_date;
point (upstream, at the head of the trunk sewer, or plant); composite_start and composite_end (local time);
replicate (1 to 3); n1_copies_per_ml and pmmov_copies_per_ml (gene copies per millilitre); water_temperature_c (degrees
Celsius), ph and conductivity_us_cm (microsiemens per centimetre), read at the composite's collection.

## dashboard_export_winter_2027.xlsx
The dashboard's export for winter 2027 on the levels it published: a sheet of each plant's weekly value, baseline,
level and band for the weeks of the winter, and a sheet of the alert episodes the desk checked.

## rain_gauges_daily_2026-01_2028-04.csv
Daily rainfall at six gauges: gauge; date_9am (the date at the end of the 24 hours to 9 am); rainfall_mm.

## phl_eqa_returns_2026_2027.xlsx
The laboratory's returns in the national external quality assessment scheme: round, dispatch date, sample, analyte,
assigned value, the laboratory's result and its z-score.
