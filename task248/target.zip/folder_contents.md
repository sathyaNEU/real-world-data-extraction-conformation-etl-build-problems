# Folder contents

Files gathered by the Southern Plains Public Health Service surveillance team for the verification desk's winter 2028 rota.

- desk_rota_winter_2028_request.eml: the wastewater surveillance coordinator's request.
- wastewater_dashboard_methods_v4.pdf: the Wastewater Dashboard's methods note (version 4).
- wastewater_sites_register.csv: the site register.
- phl_wastewater_results_2026-01_2028-04.csv: the Southern Plains Public Health Laboratory's results export, composites of 8 January 2026 to 6 April 2028.
- phl_results_export_notes.pdf: notes on the results export.
- rangeview_report_WL-2801.xlsx: the contract laboratory's report for the January 2028 closure.
- spw_inlet_historian_hourly_2026-01-05_2028-04-09.csv: Southern Plains Water's inlet historian export, 5 January 2026 to 9 April 2028.
- spw_historian_export_note.pdf: Southern Plains Water's note on the export.
- spw_travel_times_memo_2025-11.pdf: the network modeller's memo on travel times.
- paired_upstream_study_2026_results.csv: the paired upstream sampling study's results, February 2026 to January 2027.
- paired_upstream_study_2026_field_report.pdf: the paired upstream sampling study's field report.
- dashboard_export_winter_2027.xlsx: the dashboard's export of its published levels and alert episodes, winter 2027.
- rain_gauges_daily_2026-01_2028-04.csv: daily rainfall at six gauges.
- phl_eqa_returns_2026_2027.xlsx: the laboratory's external quality assessment returns, 2026 and 2027.
- DATA_DICTIONARY.md: the fields of each data file.
