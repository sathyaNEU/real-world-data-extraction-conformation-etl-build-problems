# Province of Kalinawan: death registration review, CRIP 2024

Files gathered by the Provincial Planning and Development Office for the Provincial Civil Registration Committee's
meeting of 21 November 2023.

- crip2024_review_request.eml: the provincial administrator's request.
- crvs_review_terms_of_reference_2023.pdf: the committee's terms of reference for the review (indicators D1, B1, C1).
- crs_death_records_extract_20230331.csv: Civil Registry System extract, deaths and fetal deaths, as of 31 March 2023.
- crs_birth_records_extract_20230331.csv: Civil Registry System extract, live births registered from January 2022, as of 31 March 2023.
- popcen2015_household_population_age_sex_kalinawan.xlsx: 2015 POPCEN household population by age group and sex.
- cph2020_household_population_age_sex_kalinawan.xlsx: 2020 CPH household population by age group and sex.
- cph2020_special_tabulation_pdpfp_kalinawan.csv and cph2020_special_tabulation_cover_note.pdf: 2020 CPH special tabulation of residence five years ago, with the PSA cover note.
- kalinawan_cities_municipalities_directory.csv: cities and municipalities and their LCROs.
- pho_health_office_clinical_staff_2019_2023.xlsx: Provincial Health Office roster of the health offices' clinical staff.
- fhsis_m2_mortality_reports_2015_2022.csv: FHSIS monthly mortality reports.
- lcro_capacity_survey_jul2023.xlsx: LCRO capacity survey, July 2023.
- DATA_DICTIONARY.md: the fields of each file.
