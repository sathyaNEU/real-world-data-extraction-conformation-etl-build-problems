# Data dictionary

Province of Kalinawan, death registration review for CRIP 2024. Dates are written YYYY-MM-DD.

## crs_death_records_extract_20230331.csv

Civil Registry System (CRS) extract run by the PSA provincial office on 31 March 2023: one row per certificate held
for the deaths and fetal deaths of the province's residents, wherever in the country they were registered, and for
every death and fetal death registered at an office in the province. Certificates registered on or after 1 January 2015.

| Field | Meaning |
|---|---|
| REGISTRY_NO | The registering office's registry number (year of registration and sequence). |
| LCRO_CODE, LCRO_NAME | The registering local civil registry office (PSGC code and name). |
| DATE_REGISTERED | Date the office registered the certificate. |
| CERT_TYPE | DEATH (Certificate of Death, Municipal Form No. 103) or FETAL DEATH (Certificate of Fetal Death, Municipal Form No. 103A). |
| LAST_NAME, FIRST_NAME, MIDDLE_NAME | The deceased's name as registered. |
| SEX | MALE or FEMALE. |
| DATE_OF_DEATH | Date of death, or of delivery for a fetal death. |
| DATE_OF_BIRTH | As written on the certificate; blank where the informant did not know it. |
| AGE, AGE_UNIT | Age at death as written on the certificate, in YEARS (completed years), MONTHS, DAYS or HOURS; blank where not stated. |
| CIVIL_STATUS | As registered. |
| RES_BARANGAY, RES_CITY_MUN, RES_PROVINCE | The deceased's usual residence as written on the certificate. |
| PLACE_OF_DEATH | HOSPITAL, HOME or OTHERS. |
| PLACE_OF_DEATH_CITY_MUN | City or municipality where the death occurred. |
| ATTENDANT | 1 private physician, 2 public health officer, 3 hospital authority, 4 none, 5 others. |
| CERTIFIED_BY, CERTIFIER_TITLE | The name and the title written under the signature in the certification of death. |
| LATE_REGISTRATION | Y where the certificate was registered more than 30 days after the death. |

## crs_birth_records_extract_20230331.csv

CRS extract of 31 March 2023: one row per certificate of live birth registered from 1 January 2022 to 31 March 2023 for
a birth to a mother usually resident in the province, wherever registered, or at an office in the province.

| Field | Meaning |
|---|---|
| REGISTRY_NO, LCRO_CODE, LCRO_NAME, DATE_REGISTERED | As in the death extract. |
| CHILD_FIRST_NAME, CHILD_MIDDLE_NAME, CHILD_LAST_NAME, SEX, DATE_OF_BIRTH | The child, as registered. |
| TYPE_OF_BIRTH, BIRTH_ORDER | SINGLE or TWIN; for a twin, FIRST or SECOND. |
| PLACE_OF_BIRTH, PLACE_OF_BIRTH_CITY_MUN | HOSPITAL, LYING-IN / BIRTHING HOME or HOME, and where. |
| MOTHER_FIRST_NAME, MOTHER_MAIDEN_LAST_NAME, MOTHER_AGE | The mother, age at the birth. |
| MOTHER_RES_BARANGAY, MOTHER_RES_CITY_MUN, MOTHER_RES_PROVINCE | The mother's usual residence as written. |
| FATHER_FIRST_NAME, FATHER_LAST_NAME | The father, where acknowledged. |
| ATTENDANT | PHYSICIAN, NURSE, MIDWIFE, HILOT or OTHERS. |
| LATE_REGISTRATION | Y where registered more than 30 days after the birth. |

## popcen2015_household_population_age_sex_kalinawan.xlsx, cph2020_household_population_age_sex_kalinawan.xlsx

PSA tables of the household population by five-year age group and sex for each city and municipality: the 2015 Census
of Population (reference date 1 August 2015) and the 2020 Census of Population and Housing (reference date 1 May
2020). Each city or municipality has an All Ages row above its age groups. Santa Cruz became a component city on 16 March
2019 and is listed under its name of the day.

## cph2020_special_tabulation_pdpfp_kalinawan.csv

2020 CPH special tabulation of residence five years ago (see the cover note, cph2020_special_tabulation_cover_note.pdf): persons five years old and
over by residence on 1 May 2020 and on 1 May 2015, five-year age group on 1 May 2020 and sex.

| Field | Meaning |
|---|---|
| CITY_MUN_2020 | Residence on 1 May 2020: a city or municipality of the province, or ELSEWHERE IN THE PHILIPPINES. |
| RESIDENCE_1MAY2015 | SAME CITY/MUNICIPALITY, another city or municipality of the province, OTHER PROVINCE, FOREIGN COUNTRY or NOT STATED. |
| AGE_GROUP, SEX, PERSONS | Age group on 1 May 2020, sex, number of persons. |

## kalinawan_cities_municipalities_directory.csv

The province's cities and municipalities: PSGC code, class, income class, number of barangays, the LCRO, and the date a
city's charter took effect.

## pho_health_office_clinical_staff_2019_2023.xlsx

Provincial Health Office roster of the clinical staff of each city and municipal health office from 2019 to July 2023: the
person, the position and the term (FROM, TO; TO blank for a person in post).

## fhsis_m2_mortality_reports_2015_2022.csv

Field Health Services Information System (FHSIS) monthly reports, form M2: deaths reported to each city or municipal
health office by health facilities and barangay health workers, all ages and under one year, 2015 to 2022.

## lcro_capacity_survey_jul2023.xlsx

The committee secretariat's July 2023 survey of the LCROs: staff, equipment, connectivity, documents awaiting encoding
and barangay registration points.
