Wrayburn Coast Fish Producers' Organisation: discard shares review pack
Assembled 6 November 2026 by the science and compliance team.

selectivity_programme_terms_2027.pdf
    The board's terms for the 2027 Selectivity Programme (adopted 14 October 2026).
vessel_register.csv
    The PO's vessel register: one row a member vessel in 2025, with its fleet segment.
elogbook_trips_2025.csv
    Electronic logbooks: one row a fishing trip begun in 2025 (extract of 3 February 2026).
elogbook_landings_2025.csv
    Electronic logbooks: the landing declarations of those trips, by species, presentation and size status.
observer_deployments_2025.csv
    At-sea observer scheme: the deployment log, one row a trip drawn for observation in 2025.
observer_hauls_2025.csv
    At-sea observer scheme: the observers' haul records, by species and fraction.
observer_scheme_manual_2025.pdf
    At-sea observer scheme: the 2025 scheme manual.
sales_notes_2025.csv
    Sales notes of the registered buyers for members' landings, sale dates 1 January 2025 to 31 January 2026 (extract of 6 February 2026).
vms_positions_2025.csv
    VMS position reports from members' vessels in 2025, from the PO's VMS service provider.
vms_transponders.csv
    The PO's record of the VMS terminal fitted to each member vessel.
port_limits.csv
    Port limits of the ports the members land at.
fishing_grounds.csv
    The PO's fishing grounds.
species_list.csv
    The PO's species list, with minimum sizes and conversion factors.
quota_uptake_2025.xlsx
    The PO's quota uptake report for 2025.
gear_specifications_2025.csv
    Members' gear declarations for 2025.
wcfpo_data_dictionary_2025.pdf
    The PO's data dictionary for these files.
