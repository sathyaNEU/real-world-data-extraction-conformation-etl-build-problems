# Leaver Destinations Survey: files for the 2026 release

| File | What it is |
|---|---|
| leaver_destinations_frame_2026.csv | the 2026 frame after the allocation run: forms returned, activity codes, allocations |
| leaver_destinations_final_2025.csv | the 2025 final file: processed destinations and 2025 allocations |
| nonresponse_followup_2025_outcomes.csv | the 2025 follow-up's outcomes by case and route |
| followup_case_crosswalk_2025.csv | follow-up case numbers to 2025 leaver references |
| nonresponse_followup_2025_report.pdf | the follow-up's field report: design, completion, outcome codes |
| QS-4_quality_flags_standard.pdf | the quality standard for the district flags |
| leaver_destinations_methodology_2026.pdf | the survey methodology for 2026 |
| activity_codes.csv | activity code list for the current form editions |
| school_register.xlsx | schools and their districts on the 2025 and 2026 maps |
| state_exam_points_2026.csv | state examination points of the 2026 leavers |
| destinations_release_2025_tables.xlsx | the 2025 release's district table |
| lfs_youth_neet_by_region_2025.csv | Labour Force Survey youth NEET rates by region, 2025 |
| careers_service_contacts_2026.csv | careers service contacts with leavers, autumn 2026 |
| DATA_DICTIONARY.md | column definitions |
