# Data dictionary

Social Survey Unit, Leaver Destinations Survey. Files supplied for the Department of Education's 2026 release.
Times are UTC. Allocation shares are fractions of one leaver; rates are percentages.

## leaver_destinations_frame_2026.csv
One row per leaver on the 2026 frame, extracted on 10 November 2026 after the allocation run of 9 November.

| Column | Meaning |
|---|---|
| leaver_ref | leaver reference on the 2026 frame |
| school_code | school the leaver left (school_register.xlsx) |
| sex | F or M, from the school's leaver return |
| attainment_band | AB1 to AB4, as supplied with the school's September leaver return |
| return_form | LDS-1 (paper) or LDS-2 (online) for a returned form; blank when no form was returned by the close |
| form_build | build of the online form the return was made on (online returns only) |
| returned_at | time the return was written to the frame |
| activity_code | activity recorded on the form, as captured (activity_codes.csv) |
| alloc_he, alloc_fe, alloc_app, alloc_emp, alloc_neet | the leaver's allocation to each destination (nonrespondents only; methodology section 4) |

## leaver_destinations_final_2025.csv
One row per leaver on the 2025 frame, final file of 31 March 2026. Columns as the 2026 frame, plus:

| Column | Meaning |
|---|---|
| destination | destination of a returned form after processing (HE, FE, APP, EMP, NEET) |
| alloc_* | the 2025 allocation of a leaver who never returned a form |

## nonresponse_followup_2025_outcomes.csv
One row per route by which a follow-up case was resolved (field report section 3); unresolved cases have one row
with outcome F99.

| Column | Meaning |
|---|---|
| case_no | field system case number |
| route | adviser visit, telephone, benefits record, college enrolment record or employer record |
| resolved_on | date the route resolved the case |
| outcome_code | F01 to F07, F99 (field report section 5) |

## followup_case_crosswalk_2025.csv

| Column | Meaning |
|---|---|
| case_no | field system case number |
| leaver_ref | the leaver's 2025 frame reference as the field system holds it |
| district_code | district the case was drawn in |
| drawn_on | date of the sample draw |

## activity_codes.csv
The processing reference list for the current editions of the forms (LDS-1 paper; LDS-2 online, 2026 edition): each
activity code and the destination it maps to.

## school_register.xlsx
Sheet Schools: each school's code, name and district on the 2025 and the 2026 map. Sheet Districts: district codes
and names.

## state_exam_points_2026.csv
One row per 2026 leaver: state examination points and the date the results were last issued (initial results
25 August 2026, revised results after appeals 20 October 2026).

## lfs_youth_neet_by_region_2025.csv
Labour Force Survey: NEET rate of people aged 16 to 24 by region and quarter of 2025, with the sample size.

## destinations_release_2025_tables.xlsx
The 2025 release's district table as published on 11 December 2025, on the 2025 district map.

## careers_service_contacts_2026.csv
The careers service's weekly contacts with school leavers by district, autumn 2026.
