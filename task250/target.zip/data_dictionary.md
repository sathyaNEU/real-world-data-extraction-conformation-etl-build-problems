# Network folder: data dictionary

Red Agroclimática del Ebro Medio, Consorcio Agroclimático del Ebro Medio. Prepared for the January 2028 configuration.

## estaciones_diario_2025-2027.csv

The loggers' daily export, 2025 to 2027, as the data platform delivers it (semicolon-separated, decimal commas):
one row per station and local civil day the logger delivered.

| Column | Meaning |
|---|---|
| estacion | station code (register) |
| fecha | local civil day, dd/mm/yyyy |
| tmed, tmax, tmin | daily mean, maximum and minimum air temperature, degrees C |
| n_registros | records the logger delivered for the day |

## control_calidad_2025-2027.parquet

The quality control's daily export, one row per station and read day (QC-02 sections 3 to 8): estacion, fecha,
anomalia, estimacion, residuo (degrees C), vecinos (the three stations the estimate used), estadistico_14d (the
drift statistic as the quality control recorded it), limite (the limit in force), alerta (S on a day it raised an
alert).

## ordenes_trabajo_2025-2027.xlsx

The maintenance contractors' work orders. Sheet Monegrillo: the contractor to 30 June 2027, as
exported for the handover. Sheet Alcanadre: the contractor from 1 July 2027. Each order carries
the day it was opened (Aviso, opened). Visita is the day the technician visited, blank on a cancelled order (Anulada)
and on one closed without a visit; visit_date is the date the order was closed on the contractor's app, blank on a
cancelled order.

## comprobaciones_patron_2025-2027.csv

The consortium's calibration database: every paired reading of a temperature sensor against the transfer standard,
with the station and the work order the entry form recorded (fecha_hora local time, degrees C).

## Other files

- registro_estaciones.xlsx: the station register (sheet Estaciones; comarca is the district) and each station's
  temperature-sensor history (sheet Historial sensor T: every adjustment with its as-found error in degrees C,
  every sensor replaced, every shield cleaned, with the kind of visit it was done at).
- QC-02_control_calidad_temperatura_v4.pdf: the quality-control procedure.
- plan_campo_2028.pdf: the field team's plan for 2028.
- resumen_alertas_2027.pdf: the quality control's summary of the alerts raised in 2027.
- configuracion_alertas_2028.eml: the request.
- entregas_plataforma_2027.csv: the data platform's delivery log for 2027 (when each station's day reached the server).
- boletin_et0_2027.csv: the weekly reference evapotranspiration the consortium published to irrigators in 2027, by district.
