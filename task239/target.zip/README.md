# Staff Voice 2027: survey files

Workforce Insight's files for the 2027 Staff Voice survey of Lowfirth Parcels, gathered by George Haynes (Survey Methods Analyst) on
Friday 19 November 2027 for the Team Climate Index structure check.

- `lfp_wi_sv03_measurement_standard_2027.pdf`: the survey's measurement standard, WI-SV-03, 2027 edition.
- `lfp_staff_voice_2027_dashboard_methodology.docx`: how the 2027 dashboard figures are made.
- `lfp_staff_voice_2027_fieldwork_closeout.docx`: the fieldwork close-out.
- `lfp_staff_voice_2027_codebook.xlsx`: the 2027 questionnaire codebook.
- `lfp_sv27_platform_sessions.csv`, `lfp_sv27_platform_responses.csv`: the survey platform's session and response exports.
- `lfp_sv27_paper_scans.csv`: the scanned paper forms.
- `lfp_sv27_paper_packs.csv`: the paper packs posted.
- `lfp_hr_team_register_2027-11-15.csv`: HR's team register, 15 November 2027.
- `lfp_hr_reorganisation_map_2027-09-01.csv`: HR's reorganisation map, 1 September 2027.
- `lfp_sv27_site_tablet_log.csv`: the site tablets' log.
- `lfp_hr_staff_in_post_2027-09-01.csv`: HR's staff in post by team on 1 September 2027.
- `lfp_sv26_dashboard_items.csv`: the 2026 dashboard's item results.
- `DATA_DICTIONARY.md`: the files and their fields.
