# Data dictionary

Staff Voice 2027 files held by Workforce Insight, Lowfirth Parcels. Times in columns ending `_utc` are UTC; other times are UK time.

## lfp_sv27_platform_sessions.csv
One row per session the survey platform opened, for personal links and site tablets alike.
- `session_id`: the platform's number for the session, given as the session reached the platform.
- `link_type`: `personal` (the member's own emailed link) or `site` (a site tablet).
- `inv_code`: the invitation code of the personal link.
- `tablet_ref`: the tablet's own reference for the session: the tablet and the tablet's running number.
- `entered_code`: on a tablet, the invitation code the respondent typed if they chose to give it, kept as typed (the
  platform keeps the respondent's own capitals and spacing).
- `team_code`: for a personal link, the member's team code as it stood in HR's records when the links were issued on
  6 September; for a tablet, the team chosen from the tablet's list.
- `started_utc`, `submitted_utc`: when the session was started, and when the platform received the submission.
- `status`: `submitted`; `abandoned` (no activity for seven days); `open at close` (still open at 23:59 on 4 October).
- `last_page`: the last page reached; 5 is the end.

## lfp_sv27_platform_responses.csv
One row per question shown in a session, in the order shown: `session_id`, `question` (the online code in the
codebook) and `response` (the online code, blank where the question was not answered).

## lfp_sv27_paper_scans.csv
One row per form scanned. `batch` (the scanning batch), `form_serial` (the serial in the form's barcode),
`scanned_at` (when the form was scanned, on the day it arrived), then one column per question as the paper columns in
the codebook, with the paper codes.

## lfp_sv27_paper_packs.csv
One row per paper pack posted. `form_serial`; `inv_code` (the member's invitation code, printed on the pack's cover
letter); `team_code` (the team code printed on the form, from HR's team list on the day the packs were printed);
`printed`; `posted`.

## lfp_hr_team_register_2027-11-15.csv
HR's team register as it stood on 15 November 2027: one row per team of the structure in force from 1 September 2027.
`team_code`, `team_name`, `division` (the team's division now), `previous_division` and `division_since` (where a team
has moved between divisions, the division it left and the date it joined its division now), `site`.

## lfp_hr_reorganisation_map_2027-09-01.csv
HR's reorganisation map for the change of 1 September 2027: one row for each link between a team code of the July
structure and a team code of the September structure (`renamed`, `merged`, `split`), and one row for each team created
on 1 September (`new team`, no July code). Codes that did not change are not listed.

## lfp_sv27_site_tablet_log.csv
The site tablets' own log: `tablet`, `site`, `event` (`team list loaded` is the tablet taking HR's team list as it
stood that day), `at_local`.

## lfp_hr_staff_in_post_2027-09-01.csv
HR's staff in post on 1 September 2027 by team: `team_code`, `staff_in_post`, `invited` (staff in post less those on
long-term leave on 20 August, when the contact list was taken).

## lfp_sv26_dashboard_items.csv
The 2026 dashboard's company-wide results for the Team Climate Index items: `item`, `wording`,
`percent_favourable_2026`, `answers_2026`.

## lfp_staff_voice_2027_codebook.xlsx
Questions, the online and paper codes, and the online pages.
