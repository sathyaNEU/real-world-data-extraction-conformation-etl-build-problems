Kettle Ridge University, Campus Utilities
Water SCADA historian export

Requested by:  Campus Utilities, for the 2026 sanitary survey response
Exported:      6 October 2026, from the water SCADA historian
File:          scada_historian_export_2025-10-01_2026-10-01.csv
Tag list:      scada_tag_list.csv

COVERAGE

  Every tag in the tag list, one sample per hour, from 2025-10-01T04:00:00Z to
  2026-10-02T03:00:00Z (8,784 samples a tag, 237,168 rows).

COLUMNS

  tag             tag name, as in the tag list
  timestamp_utc   sample time, UTC (ISO 8601)
  value           the sample's value, in the tag's units
  quality         G good
                  U uncertain: communications lost, last good value held
                  B bad: instrument fault

VALUES

  Timestamps are UTC.
  Levels and flows are instantaneous samples at the timestamp; so are the pressures
  and the chlorine residual. Totalizers are cumulative gallons, the meter register
  read at the timestamp. Run status is 1 when the pump is running at the timestamp.

  Rows are in time order, the tags of each hour in tag-list order.
