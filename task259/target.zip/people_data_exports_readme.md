# People data exports, 14 October 2026

Prepared by Wanda Kane, People Data and Systems, for the total rewards team's band refresh. Three exports, all pulled on
14 October 2026, plus the pay zone table.

## hris_job_history_2026-10-14.csv

The job history of every worker who has held a data engineering, machine learning engineering or analytics
engineering job at Tarnwick Systems since 2019: one row per job record. A job record is written for a hire, a promotion, a
transfer, the start or end of a leave of absence and a termination, and each row shows the whole job as it stands
from its effective date. Changes already agreed are entered ahead, with their future effective date.

| Column | What it holds |
|---|---|
| `employee_id` | the worker's id (an `E` id for employees, a `C` id for contingent workers) |
| `effective_date` | the date the job record takes effect |
| `action` | `hire`, `promotion`, `transfer`, `leave_start`, `leave_end` or `termination` |
| `job_code`, `job_title` | the job, as coded in the engineering job architecture |
| `work_location` | the city the worker works in |
| `pay_zone` | the pay zone recorded on the job record when it was written |
| `status` | `active`, `leave` or `terminated` |
| `worker_type` | `employee`, or `contingent` for contractors engaged through an agency |

## pay_zones_2026.csv

Tarnwick Systems's pay zones: the zone each work location is in, with the dates it applies.

## ats_requisitions_2026-10-14.csv

Every engineering requisition opened since June 2025, with its postings.

| Column | What it holds |
|---|---|
| `requisition_id`, `posting_id` | the requisition, and the posting of it in one city |
| `job_code`, `job_title` | the job the requisition hires for |
| `posting_city` | the city of the posting |
| `opened_on` | the date the requisition opened |
| `closed_on` | the date the requisition closed with a hire |
| `status` | the requisition's status on the export date: `open`, `filled` or `cancelled` |
| `status_date` | the date that status took effect |
