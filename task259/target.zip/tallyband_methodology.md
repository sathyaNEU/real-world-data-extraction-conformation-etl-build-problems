# Tallyband data extract: methodology

Prepared by Tallyband Data Services for licensed subscribers. Applies to extracts taken from July 2025.

## What a report is

A report is one person's pay at one employer, filed by that person on Tallyband: their employer, the employer's
level code for their job, their title, their base salary, their years of experience, where they work and how they
are employed, as at the date they filed it. Tallyband asks respondents to report the pay they are on when they
file.

## Who is in an extract

An extract holds every respondent who filed a report in the 36 months to the extract date, once, with the latest
report they filed. When a respondent files a new report at the same employer, Tallyband keeps their earlier report's
date, level code and base salary beside the new one, in the `previous_` columns; those columns are blank for
everyone else. The profile table, delivered with the extract, holds each respondent's profile as it stood on the
extract date.

This extract (`tallyband_extract_2026-10-01.csv`, with `tallyband_profiles_2026-10-01.csv`) was taken on
1 October 2026 for Tarnwick Systems under its subscriber licence.

## Fields

| Field | What it holds |
|---|---|
| `respondent_id` | Tallyband's id for the respondent, the same in the extract and the profile table |
| `filed_on` | the date the respondent filed the report |
| `employer` | the employer's name as the respondent typed it; Tallyband does not tidy names |
| `employer_level` | the employer's own level code for the job, as the respondent gave it |
| `tallyband_level` | Tallyband's normalised level (L1 to L7), assigned from the employer's level code |
| `job_family` | Tallyband's job family, assigned from the respondent's title |
| `title` | the respondent's job title |
| `years_experience` | years of professional experience the respondent reported |
| `country` | ISO 3166 code of the country the respondent works in |
| `state` | USPS state code, for respondents working in the United States |
| `employment_type` | `full_time`, `part_time` or `contract` |
| `base_salary_usd` | annual base salary in US dollars, before bonus and equity |
| `previous_filed_on`, `previous_employer_level`, `previous_base_salary_usd` | the respondent's earlier report at the same employer, where there is one |

Profile table: `respondent_id`, `primary_focus` (the area of work the respondent chose from their family's list),
`works_remotely` and `highest_degree`.

## Levels

Employers' ladders do not line up one to one. `tallyband_level` places every employer code on one scale for the
site's own charts, so one normalised level can hold codes that employers treat as different levels. Subscribers
who keep their own mapping from employer codes to their levels should use it.

## Pay

Base salary is the respondent's annual base pay as reported, in US dollars. Respondents outside the United States
report in their own currency; Tallyband converts at the exchange rate on the filing date. Part-time respondents
report the pay they actually receive.

## Privacy

Tallyband removes reports that could identify a person and never releases names or contact details. Subscribers may
not try to identify a respondent.
