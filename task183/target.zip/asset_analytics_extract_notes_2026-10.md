# Asset analytics extract, October 2026: file notes

Pulled 6 October 2026 at the request of Samantha Werner (Distribution Asset Management) for the 2027 underground cable
program review (Tamsin Valley district: Harrow Road, Mill
Lane, Quarry Hill and Sutter Park substations, feeders HR12, HR14, ML03, ML07, QH21, QH22, SP05, SP09). Every
extract runs through 30 September 2026. Questions on the extracts to Charles Weber (GIS and work management) or Jeffrey Roth
(outage records and reliability).

## Where each file came from

| File | Source system | Run | Covers |
|---|---|---|---|
| ug_cable_fault_work_orders_2012_2026.csv | Work management (SAP PM), cable fault work orders, order type ZUGF | 2026-10-06 | January 2012 (conversion of the archive) to 30 September 2026; 1,055 orders |
| gis_ug_primary_sections_20260930.xlsx | GIS (ArcGIS Utility Network), UG primary sections layer, nightly export | 2026-10-01 | every section on the eight feeders, in service or retired, as of 30 September 2026; 3,177 rows |
| wo_cause_repair_codes.csv | Work management code tables | 2026-10-06 | cause, repair and GIS status codes |
| oms_outage_export_2020-10_2026-09.csv | Legacy OMS to 17 March 2026, ADMS from 17 March 2026 (one export view over both) | 2026-10-06 | outages starting 1 October 2020 to 30 September 2026; 1,432 rows |
| oms_restoration_steps_2020-10_2026-09.csv | Same as above, restoration step table | 2026-10-06 | the steps of the same outages; 1,607 rows |
| connectivity_meter_points.parquet | Network model (connectivity), meter to transformer to protective device, dated rows | 2026-10-02 | model go-live 9 November 2014 to 30 September 2026; 37,008 rows |
| feeder_device_list.json | Network model, protective device hierarchy | 2026-10-02 | substations, banks, breakers, automated switches and fuses, in service or retired |
| cis_service_accounts_20260930.csv | Customer information system, active service accounts | 2026-10-01 | accounts active on 30 September 2026; 28,221 rows |
| major_event_days_RY2021-RY2025.csv | Reliability Engineering, published major event days | 2026-01-15 | RY2021 to RY2025 |
| TVE-RS-04_reliability_reporting_standard_rev6.pdf | Standards library | | TVE-RS-04 revision 6 |
| 2025_annual_reliability_report_sec6_ug_cable.pdf | 2025 annual reliability report, section 6 | | calendar years 2021 to 2025 |
| vault_manhole_inspections_2022-2026.csv | Inspections database, manhole and vault inspections | 2026-10-06 | January 2022 to September 2026; 1,803 rows |
| feeder_peak_loading_2021-2026.xlsx | SCADA historian, monthly feeder peaks | 2026-10-05 | January 2021 to September 2026 |

## Fields

**ug_cable_fault_work_orders_2012_2026.csv**: one row per work order.
- `wo_number`: work order number.
- `feeder_id`: feeder recorded on the order when it was raised.
- `section_id`: GIS id of the cable section the crew worked on.
- `fault_date`: date of the fault (the order is raised when the fault is reported).
- `completed_date`: date the order was technically completed. For a REPL order it is the day the new cable was energised.
- `cause_code`, `repair_code`: see wo_cause_repair_codes.csv.
- `crew_note`: the crew's free text, as typed.

**gis_ug_primary_sections_20260930.xlsx**: one row per cable section; the first rows of the sheet state the export's as-of date.
- `section_id`: GIS facility id. A replaced section is retired (status RET, `retired_date` filled) and its new cable is added as a new section whose `predecessor_section_id` is the retired id.
- `feeder_id`: the feeder the section is connected to (for a retired section, the feeder it was on when it was retired).
- `from_structure`, `to_structure`: the manhole, vault or pad-mount structures at the section's ends.
- `length_ft`: route length in feet. `conductor`, `insulation` (PILC, XLPE, TR-XLPE, EPR), `voltage_class_kv`.
- `install_date`: in-service date of the cable (for cable older than the GIS, the date carried over from the plat records).
- `install_method`: DIRECT BURIED or CONDUIT. `status`: IS or RET. `last_edit`: last GIS edit to the feature.

**oms_outage_export_2020-10_2026-09.csv**: one row per outage per feeder affected.
- `outage_id`: OMS-yymmdd-nnn in the legacy system, INC numbers in ADMS.
- `device_id`, `device_type`: the protective device that operated (a fuse, a feeder breaker, or a substation transformer bank).
- `start_ts`: when the device operated. `restore_ts`: when the last customer of the outage was restored.
- `customers_out`: customers interrupted by the outage. `cust_minutes`: customer minutes of the outage.
- `cause_code`: dispatcher's cause category. `source_system`: OMS (legacy) or ADMS.
- Times are as each system records them: legacy OMS in Eastern local prevailing time, ADMS in UTC.

**oms_restoration_steps_2020-10_2026-09.csv**: one row per restoration step of an outage.
- `step_no`: order of the step. `device_id`: the outage's operating device.
- `restoring_device_id`: the device closed (or re-fused) at the step.
- `step_restore_ts`: time of the step, in the same clock as the outage's `source_system`.
- `customers_restored`: customers whose supply came back at the step.

**connectivity_meter_points.parquet**: one row per meter per period of connection.
- `meter_id`: the metered service point. `meter_serial`: the meter installed at it.
- `transformer_id`, `device_id`: the distribution transformer and the nearest protective device above it.
- `feeder_id`: the feeder the point is on.
- `eff_from`, `eff_to`: dates the row applies from and to; `eff_to` is the first day it no longer applies, blank while current. A row is closed and a new one opened when the point's device, feeder or meter changes.

**feeder_device_list.json**: substations, transformer banks and feeders, then every protective device with its type, feeder, parent device and in-service dates (blank when in service since the model's go-live).

**cis_service_accounts_20260930.csv**: one row per active account.
- `meter_id`: the metered service point on the account. `feeder_label`: the feeder recorded on the account when it was set up. `account_setup_date`, `rate_class`, `premise_type`, `service_address`.

**major_event_days_RY2021-RY2025.csv**: one row per published major event day: reliability year, date, the year's threshold (daily SAIDI, minutes) and the event.

**vault_manhole_inspections_2022-2026.csv**: one row per structure inspection: water level found, condition rating (1 poor to 5 good), findings and whether a follow-up order was raised.

**feeder_peak_loading_2021-2026.xlsx**: monthly peak amps per feeder breaker against the getaway cable's emergency rating.
