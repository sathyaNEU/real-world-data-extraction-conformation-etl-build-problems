# Extract for the 2027 UG cable program review

Pulled 6 Oct 2026 for Samantha Werner (Distribution Asset Management). Tamsin Valley district only, the eight feeders out of
Harrow Road, Mill Lane, Quarry Hill and Sutter Park. Everything runs through 30 Sep 2026 unless it says otherwise.
GIS and work order questions to Charles Weber, outage and reliability questions to Jeffrey Roth.

Files:
- ug_cable_fault_work_orders_2012_2026.csv: SAP PM cable fault orders (order type ZUGF). Orders before 2012 were not converted.
- gis_ug_primary_sections_20260930.xlsx: GIS UG primary sections layer, nightly export of 30 Sep, in service and retired.
- wo_cause_repair_codes.csv: cause, repair and GIS status codes.
- oms_outage_export_2020-10_2026-09.csv, oms_restoration_steps_2020-10_2026-09.csv: one export view over legacy OMS (to 17 Mar 2026) and ADMS (from 17 Mar 2026), outages from 1 Oct 2020.
- connectivity_meter_points.parquet, feeder_device_list.json: network model, meter to transformer to protective device, and the device hierarchy.
- cis_service_accounts_20260930.csv: CIS active accounts at 30 Sep.
- major_event_days_RY2021-RY2025.csv: Reliability Engineering's published MED list, RY2021 to RY2025.
- TVE-RS-04_reliability_reporting_standard_rev6.pdf, 2025_annual_reliability_report_sec6_ug_cable.pdf: from the standards library and the 2025 filing.
- vault_manhole_inspections_2022-2026.csv, feeder_peak_loading_2021-2026.xlsx: inspections database and SCADA monthly peaks, as asked.

Things to know:
- When a section is replaced the old one is retired in GIS (status RET, retired_date filled) and the new cable goes in as
  a new section with predecessor_section_id pointing at the old one. A retired section keeps the feeder it was on when
  it was retired.
- feeder_id on a work order is the feeder when the order was raised. On a REPL order completed_date is the day the new
  cable was energised.
- OMS export is one row per outage per feeder affected; restore_ts is when the last customer came back. Legacy OMS
  times are Eastern local, ADMS times are UTC, and the step table uses the same clock as its outage.
- Connectivity rows: eff_to is the first day the row no longer applies, blank while current. A new row is opened when
  the point's device, feeder or meter changes.
- Device list in-service dates are blank for devices in service since the model went live (Nov 2014).
- SP05: the second feed to the Kessler Avenue loop was energised on 15 Sep 2026; the loop now runs closed, fed from
  both ends off SP05, and is back inside its rating. No meter moved, so connectivity has no rows for it.
