# Domains runbook: web properties and image hosts

Owner: Doris Rhodes, site reliability. Last reviewed 24 November 2026.

## Page origins

Each property is served from its www origin:

- Tideline: `tideline.brolga.au`
- Matchday: `matchday.brolga.au`
- Hearth: `hearth.brolga.au`
- Ledger: `ledger.brolga.au`
- Trailhead: `trailhead.brolga.au`
- Pantry: `pantry.brolga.au`

The group's small sites (Clutch, Tenancy, Fairway, Undercurrent, Brolga Kids, Tidewater, Paddock) run on the same platform; cdn_host_list.csv lists them.

## Image hosts

Each property serves its images from its own image host, `images.<property>.brolga.au`, under `/i/<width>x<height>/<yyyy>/<mm>/<file>`, one directory per slot size.

## Legacy aliases

`media.hearth.brolga.au` and `media.trailhead.brolga.au` are the old media server's names for Hearth's and Trailhead's images. They were retired for new links on 14 August 2026 (WEBPLAT-2297). Pages published before each property's image host went live (Hearth's on 1 July 2023, Trailhead's on 1 December 2022) still link to them, and the old media server still answers those requests from the same image store.

## Group image CDN

`img.brolgacdn.au`, run for us by Tallowood Edge Pty Ltd under the image CDN services agreement. Each site has a path prefix, `/<site>/` (cdn_host_list.csv), followed by the same `/i/<width>x<height>/` layout as the image hosts. The small sites' paths date from the squad's first engagement in February 2024; the six properties' from 16 June 2025, when pages in Tideline's opinion section, Matchday's racing section and Pantry's baking section moved their images onto it.

## Third-party hosts

Not ours, and never moved: `images.pressframe-syndication.net` and `cdn.wirelens.media` (agency photos), `creative.adwattle.net` (ad creatives), `poster.clipferry.net` (video posters).

## Changes

- 14 August 2026: legacy aliases retired for new links (WEBPLAT-2297)
- 16 June 2025: image CDN paths for the six properties (WEBPLAT-1630)
- 10 March 2025: three sections moved with their pages and images: Hearth's real-estate to Ledger (`/property/`), Tideline's travel to Trailhead (`/getaways/`), Matchday's game-day food to Pantry (`/game-day/`); the old URLs answer with a 301 (WEBPLAT-1544)
- 5 February 2024: image CDN paths for the small sites, with the squad's first engagement
