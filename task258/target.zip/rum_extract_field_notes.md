# RUM extracts: field notes

For the December 2026 planning. Doris Rhodes, site reliability, 3 December 2026.

## rum_lcp_beacons_2026-11.csv

- One row per beacon the collector received from the six www origins on the whole UTC days 31 October to 30 November 2026.
- Each origin samples page loads at the rate in force when the page load started (rum_sampling_config.csv, effective from the UTC instant given). A sampled page load sends one beacon when the page is hidden, so a beacon stands for 1 / that rate page loads.
- `beacon_id`: the page load's beacon.
- `origin`, `page_path`: where the page load went.
- `form_factor`: mobile, desktop or tablet, from the user agent.
- `navigation_type`: `navigate`; `reload`; `prerender` (the page was prerendered and then shown, and its timings run from the moment it was shown); `back_forward` (restored from the back-forward cache, which reports no LCP, so its timing columns are blank).
- `fired_at_utc`: when the page load started, UTC.
- `fcp_ms`: First Contentful Paint.
- `lcp_ms`: Largest Contentful Paint.
- `lcp_element`: the tag of the LCP element (`IMG`, `H1`, `P`, `DIV`, `VIDEO`).
- `lcp_url`: the URL of the LCP element's image or poster; blank for text.
- `ttfb_ms`, `load_delay_ms`, `load_time_ms`, `render_delay_ms`: the four parts of LCP from the web-vitals attribution build: time to first byte; resource load delay, from the first byte to the start of the LCP image's request; resource load duration; element render delay, from the end of the image's load to the paint. They add up to `lcp_ms`; for a text element the two resource parts are 0.

## squad_engagement_beacons_2024-2026.csv

- The squad's review extract: about 3,000 beacons drawn at random from each review window of each engagement in the change log, from the engaged pages' loads whose LCP element was the hero image.
- The same columns as the November extract, and `engagement`, the change log's Ref. Sampling rates do not apply to it: within a window every beacon counts once.

## rum_sampling_config.csv

- One row per change: a rate applies from `effective_from_utc` until the origin's next row.
