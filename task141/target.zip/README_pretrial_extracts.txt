Dorrance County Pretrial Services: extracts for the 2027 bail policy revision
Pulled 2 October 2026 by Pretrial Services from the systems named below. Every extract runs to the end of
30 September 2026.

bail_policy_revision_2027_draft.docx
    Local bail policy for pretrial release: revision for 2027, draft for consultation of 6 October 2026
    Source: Office of the Senior Resident Superior Court Judge

local_bail_policy_2024.pdf
    Local bail policy for pretrial release, effective 1 July 2024
    Source: Office of the Senior Resident Superior Court Judge

pas_scoring_guide_v2.pdf
    Pretrial Assessment Scale, version 2: scoring guide
    Source: Dorrance County Pretrial Services

first_appearances_2021-10-01_2024-03-03.csv
    Initial appearances on new charges, 1 October 2021 to 3 March 2024, one row per appearance
    Source: Clerk of Superior Court, legacy court system

first_appearances_2024-03-04_2026-09-30.csv
    Initial appearances on new charges, 4 March 2024 to 30 September 2026, one row per appearance
    Source: Clerk of Superior Court, case management system

first_appearance_charges_2024-03-04_2026-09-30.csv
    The charges at those appearances from 4 March 2024, one row per charge, with the case each is filed in
    Source: Clerk of Superior Court, case management system

pas_screens_2021-10-01_2026-09-30.csv
    Pretrial Assessment Scale screens, 1 October 2021 to 30 September 2026, one row per screen
    Source: Pretrial Services screening system

jail_bookings_2021-10-01_2026-09-30.csv
    Detention center bookings, 1 October 2021 to 30 September 2026, one row per booking
    Source: Sheriff's Office jail management system

state_arrest_extract_2026-10-02.csv
    Arrests in North Carolina of every defendant in the first-appearance exports, 1 October 2021 to 30 September 2026
    Source: State arrest repository, extract requested by Pretrial Services, run 2 October 2026

court_case_index_2021-10-01_2026-09-30.csv
    Criminal case index: every district and superior court case filed from 1 October 2021, with its disposition
    Source: Clerk of Superior Court, case management system

court_events_2025-10-01_2026-09-30.csv
    Court events, 1 October 2025 to 30 September 2026
    Source: Clerk of Superior Court, case management system

sentry_point_invoice_lines_2025-10_2026-09.csv
    Electronic monitoring invoice lines, October 2025 to September 2026
    Source: Sentry Point Monitoring, monthly invoices to Dorrance County

halsey_county_board_bills_2025-11_2026-09.xlsx
    Halsey County inmate housing invoices, November 2025 to September 2026
    Source: Halsey County Sheriff's Office, monthly invoices to the Sheriff's Office

offense_code_crosswalk.xlsx
    Offense code crosswalk, legacy to new system
    Source: Clerk of Superior Court

magistrate_roster.xlsx
    Magistrates of Dorrance County, 2021 to 2026, and the duty shifts
    Source: Office of the Chief Magistrate

jail_code_list.csv
    Jail booking types, release types and facilities
    Source: Sheriff's Office

court_code_list.csv
    Court codes: conditions, dispositions, events
    Source: Clerk of Superior Court

cjac_jail_population_report_2025.pdf
    Criminal Justice Advisory Council, jail population report for 2025
    Source: Sheriff's Office for the Council

dorrance_county_reported_crime_2019-2025.xlsx
    Reported offenses by Dorrance County agencies, 2019 to 2025
    Source: Criminal Justice Advisory Council

Notes
- Times: the court exports and the screens are Eastern local time. The jail export is UTC (ISO 8601, ending Z).
  The state arrest extract has dates only.
- The clerk's legacy system ran to 3 March 2024 and the new case management system from 4 March 2024. The legacy
  export writes case numbers with a space (21CR 004512), booking numbers without the B and the hyphen, the
  magistrate's initials and the legacy offense codes; the new export writes the new codes on its charge rows.
  The offense code crosswalk maps one to the other. The case index lists every case in the new system's format.
- A first appearance is the defendant's initial appearance before a magistrate after an arrest on new charges.
  Appearances on orders for arrest are not in the first-appearance exports.
- Detention: a stay runs from booking to release from the Sheriff's custody; a defendant boarded out stays in
  the Sheriff's custody while boarded out. Custody is counted at midnight, each count dated with the day it
  begins; one bed-day is counted for each midnight count at which the person is held.
- Release at first appearance, as Pretrial Services reports it: leaving the detention center within 24 hours of
  the first appearance on the conditions set at it, a secured bond posted in that time included. A defendant
  still in custody 24 hours after the appearance is held after it.
- Days after a release are counted from the release date, and a period of days includes its last day: the 365
  days after a release on 1 March 2024 run to 1 March 2025, that day included.
- Days on electronic monitoring are counted for each release: every day on which the defendant wore a monitor
  under that release's conditions, for all or part of the day.
- The state arrest extract lists every arrest in North Carolina of anyone with a first appearance in either
  export, from 1 October 2021, one row for each charge of an arrest.
- Sentry Point bills each enrollment by the month, each day or part of a day the enrollment is active.
- Code lists: jail_code_list.csv and court_code_list.csv.
