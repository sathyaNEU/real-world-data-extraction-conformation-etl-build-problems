# Supply pull, 3 January 2027: data notes

Supply Analytics (Jesse Velasquez). Field notes for the files pulled on Sunday 3 January 2027; the pull log is supply_pull_2027-01-03.log.

## Dispatch

**dispatch_legacy_driver_months_2021-05_2024-07.csv**. The old dispatch platform's monthly driver export, one row per legacy driver number and month with completed trips or online time. Months are calendar months, Central time. ONLINE_HRS is online time in hours, to one decimal. The old platform's last day was Sunday 14 July 2024, so July 2024 holds 1 to 14 July.

**driver_activity_monthly_2024-07_2027-01.csv**. The dispatch warehouse's monthly driver activity, one row per driver_id and month with completed trips or online time, from Monday 15 July 2024; July 2024 holds 15 to 31 July. trips_completed counts trips the rider completed; trips_cancelled_by_driver are not in it; online_minutes is time online in the driver app. Months are calendar months, Central time. January 2027 holds 1 to 3 January, to the extract run.

**dispatch_migration_driver_crosswalk.csv**. Every legacy driver number and the driver_id it became on 15 July 2024. A driver registered twice on the old platform has both numbers mapped to one driver_id.

**driver_accounts_2027-01-03.csv**. One row per account as at the extract run.

| Field | Values |
|---|---|
| account_opened | the day the account was approved, Central time |
| signup_channel | app; referral; campaign_winter26 (the winter 2026 recruitment campaign, sign-ups from 12 January 2026); rental_partner (drivers of the 2025 rental programme) |
| vehicle | own, lease, rental |
| account_status | active (a completed trip in the last 30 days); new (approved, no trip yet); inactive; deactivated; merged (a driver's second account, merged into merged_into on closed_on) |
| last_trip_on | the day of the account's latest completed trip |
| closed_on | the day the account was deactivated or merged |

## Payments

**winter_guarantee_2025_payout_run.xlsx**. The 2025 guarantee's main run of 14 February 2025, from the old payout report.

**winter_guarantee_2026_payout_run.csv**. The 2026 guarantee's main run of 13 February 2026.

**guarantee_payout_adjustments_2025-2026.csv**. The guarantee's adjustment runs, 2025 and 2026: a late_credit line pays the payout in payout_id; a fraud_recovery or duplicate_account line recovers the payout in reverses_payout_id. program_code is the run's program.

**guarantee_payout_events_2025-2026.csv**. Each guarantee payout's events in the payments system, UTC.

**ach_returns_payout_account_2025-2026.csv**. The bank's ACH return report for the payout account, 2025 and 2026; individual_id carries the payout id.

## Onboarding

**onboarding_applications_2025-06-02_2027-01-03.csv**. The onboarding app's applications export, one row per application, times UTC. status: in_review, approved, approval_lapsed (approved, the approval lapsed 90 days after it was given without a trip), rejected, withdrawn, expired. driver_id is the account an approval opened; first_trip_at_utc is that account's first completed trip.

**background_check_orders_2025-06_2027-01.csv**. The screening vendor's order export for Larch, one row per order, times UTC. candidate_id is the vendor's person; client_reference is the application id.

## Also in the pull

driver_supply_kpis_2026-11.pdf (the November KPI report), winter_guarantee_payout_notes.docx and onboarding_pipeline_counts.docx (the payments and onboarding teams' notes), winter_guarantee_terms_2027.pdf (the 2027 terms), guarantee_account_funding_2026-12-30.eml (finance's email of 30 December), rider_demand_plan_q1_2027.xlsx (marketplace planning's Q1 plan, issued 4 December), driver_referral_bonuses_2026.csv (2026 referral bonuses).
