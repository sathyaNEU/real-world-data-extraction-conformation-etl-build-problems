# Drumlorne noise survey, autumn 2026: monitoring notes

Orla O'Hurley, monitoring technician. Written up 12 October 2026, with the folder handed to the environmental
engineer on 16 October.

## How it went

Fourteen positions, two deployments of a week each, from Monday 31 August to the collection round on
Monday 12 October. Five logging meters, lifted and set down again on the Monday mornings, one round for
the five of them, starting between half four and five and finishing before the works woke up. Every
position in the schedule was covered twice. The deployment table says which meter stood where, when it was
set running and stopped, the height it stood at and the field checks either side.

Mounting was free field on a tripod, 3.5 m off the facade where there was room for it. At NSL08 the cattle
were in the field the first week and the tripod had to go three metres west of the pegged spot; at NSL13
the garden wall was being rebuilt in the second week and the mic came down to 1.2 m to clear the scaffold.
Both are on the deployment record.

## Access

NSL03, NSL05 and NSL12 are through the farm yards and the occupiers hold the gate keys; ring ahead. The
dog at NSL09 is loose in the yard most days. NSL10 is up the lane past the quarry entrance and the lane is
not passable in the dark after rain. Nobody minded the tripod once they had seen it.

## Weather

A wet first fortnight: showers most afternoons in the first week and a wet Thursday in the second. It
blew hard from the Tuesday of the third week to the Friday, 20 to 35 km an hour at the mast most of those
days, and the last fortnight was settled and cool. The mast on the blower house roof logs the wind, the
rain gauge and the air temperature, and the anemometer was replaced on 20 September after the old one
started sticking.

## What went wrong

The card in one meter threw a read error when it was collected and the download was repeated to get it
off, so part of that day came through twice. One logger reset itself mid-week and wrote nothing until the
mid-week visit, and two meters dropped their measurement channel for half an hour each. All of it is on
the deployment record.

On the plant side the radio link from the PLC to the historian dropped several times over the survey, the
longest spell from the Friday evening of the fourth week to the Saturday afternoon. When that link goes
the interface writes nothing for a while, and sometimes it writes the last value it had again until the
link is back.

## Also in the folder

The complaints register for 2026, and the final effluent monitoring results for the same period. Neither
was collected for this survey.
