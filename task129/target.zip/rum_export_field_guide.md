# RUM beacon export: field guide

Digital operations, maintained by Gunhild Lund. Applies to `rum_mobile_views_2026.parquet` and the
registers and logs filed beside it. Last edited 4 September 2026.

## The beacon export

One row per beacon the collector received. A page view sends one beacon; `pv_id` is the page-view
key. The export holds mobile web and app-webview page views on the three titles' sites from
1 February to 31 August 2026 (Copenhagen dates). Reporting months are Copenhagen calendar months.

Sampling is by device key: when a device is sampled, every page view it makes is in the export.
`sample_weight` is the number of page views the row stands for; sum it to count views.

| Field | Meaning |
|---|---|
| beacon_id | Collector receipt number, increasing in order of receipt |
| pv_id | Page-view key |
| ts_utc | Navigation start of the page view, UTC |
| device_key | Hashed device identifier, stable for the life of the device |
| account_key | Account the device is signed in to; empty when not signed in |
| title | Masthead the page was published under at the time of the view (ST Sønderå Tidende, LA Lindå Avis, KD Kærby Dagblad) |
| template | Page template |
| url_path | Path of the page on the title's site; local-edition pages sit under /lokal/<edition>/ |
| device_model | Model string as the client reports it; resolve it against the device registry |
| os, browser | Client operating system and browser (app webviews report the app) |
| effective_connection_type | Network Information API value at navigation start |
| navigation_type | navigate, reload or back_forward |
| referrer_class | internal, search, social, direct, newsletter, push, app or other |
| ttfb_ms | Time to first byte, milliseconds |
| lcp_ms | Largest contentful paint, milliseconds; empty when the browser reported no paint |
| cls | Cumulative layout shift |
| sample_weight | Page views the row stands for |

Collector v2 came with the platform release of 3 June 2026 (see the release train log); sampling
rates are set per collector and are carried row by row in `sample_weight`.

## Registers and logs

- `device_registry_2026-09.csv`: one row per device model. `form_factor` is phone or tablet;
  `perf_band` (low, mid, high) is the model's band on the group's CPU benchmark and is the phone
  class used in performance reporting.
- `subscription_register_extract_2026-09-05.csv`: one row per subscription. A subscription is
  active from `start_date` to `end_date` inclusive; an empty `end_date` means it is running.
- `edition_register.csv`: masthead of each local edition, effective-dated; an empty `valid_to`
  is the current row.
- `release_train_log_2026.csv`: one row per platform deploy. `deployed_at` is local time with its
  offset. `platform_bundle` and `puzzles_bundle` are the content hashes of the JavaScript bundles
  the deploy shipped.
- `boelge_rollout_log.csv`: one row per Bølge wave, with the release that switched it on.
- `image_cdn_delivery_2026.csv`: fields in the vendor appendix (appendix C).

Throughout these extracts a kilobyte (kB) is 1,000 bytes.
