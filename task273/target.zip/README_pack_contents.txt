Stonereach Valley Regional Transportation Commission, Commercial Fleet Safety Programme: coverage review pack
Assembled 16 November 2026 by the Safety Programmes office.

cfsp_coverage_rule_2026.pdf
    Stonereach Valley Regional Transportation Commission: Commercial Fleet Safety Programme, coverage rule (adopted 14 October 2026).
crash_extract_2021_2025_crashes.csv
    State crash records system, regional extract for Stonereach County, crashes of 2021 to 2025: one row a crash (extract of 30 September 2026).
crash_extract_2021_2025_units.csv
    The same extract: one row a unit on each crash report (vehicles, parked vehicles, pedestrians, pedalcyclists).
crash_extract_2021_2025_persons_injury_crashes.csv
    The same extract: one row a person, for crashes with an injury recorded.
crash_extract_data_dictionary.pdf
    The extract's data dictionary, with the codes of both report forms.
road_fatality_register_2021_2025.csv
    State road fatality register: deaths within 30 days of a crash in Stonereach County, 2021 to 2025.
lrs_road_inventory_2025.xlsx
    Linear referencing system: road inventory of Stonereach County (31 December 2025), with the legacy route numbers.
travel_monitoring_report_2025.pdf
    Department of Transportation: Travel Monitoring Report 2025, Stonereach Valley region.
ccs_stations_2025.csv
    Department of Transportation: continuous count stations in the region, 2025.
ccs_hourly_volumes_2025.csv
    Department of Transportation: hourly volumes at the continuous count stations, 2025.
dot_crash_unit_costs_2025.pdf
    Department of Transportation: crash unit costs for safety analysis, 2025.
commission_operator_register_2026.xlsx
    The Commission's licensed operators, with the names officers write on crash reports, and the fleet returns of the operators that file them.
platform_vehicle_reports_2025.csv
    Quarterly reports of the ride-hail and delivery platforms to the Commission, 2021 to 2025.
dmv_registrations_stonereach_2021_2025.xlsx
    Department of Motor Vehicles: registrations in force in Stonereach County, 2021 to 2025.
noaa_daily_weather_kelderwick_2021_2025.csv
    Daily weather at Kelderwick Regional Airport, 2021 to 2025.
work_zone_log_2021_2025.csv
    Department of Transportation: work zone log, Stonereach County, 2021 to 2025.
