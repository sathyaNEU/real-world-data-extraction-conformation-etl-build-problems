# Extract for the 2027 pass-through recommendation

Pulled 16 Nov 2026 by Kristin Cline for Kendra Andrews. Platform tables, survey files and the terminal's rack file as held
on the bureau's shared drive that morning.

Files:
- price_change_log_regular_2025-01-01_2026-11-15.csv: every regular-gasoline price change the platform received from 1 Jan 2025 to 15 Nov 2026.
- terminal_rack_prices_2024-12_2026-11.csv: the terminal's published rack prices, all three products.
- station_register_2026-11-16.xlsx: the platform's station table and brand history.
- station_renumbering_2026-06-08.csv: old station numbers to the new ones issued on 8 Jun 2026.
- fuel_sales_survey_returns_2026.csv: the monthly fuel sales survey returns for 2026 to date.
- fuel_sales_survey_frame_2026-11.csv: the sales survey frame as at this month.
- price_submissions_2026-11.csv: every submission received in November 2026, all grades.
- monitored_brand_register.json: the monitored brand register.
- reporting_platform_operations_log.xlsx: platform operations log.
- weekly_price_bulletin_2026.xlsx: the weekly bulletin as published.
- price_complaints_register_2026.csv: the Commissioner's price complaints line, 2026 to date (sent over by the Commissioner's office).
- pass_through_monitoring_standard_PM-04.pdf, carbon_levy_regulation_schedule_2.pdf: the standard and the levy rates.

Things to know:
- effective_utc and received_utc are UTC. Local time is UTC-5, and UTC-4 from the second Sunday in March to the first
  Sunday in November.
- A row in the price files is one change as submitted: the price stands until the station's next change, or until
  the station closes (the register's closed date).
- Station numbers changed on 8 Jun 2026. Stations that closed before then keep their old number in the register.
- channel: API is a system-to-system submission, POS the forecourt terminal, PORTAL keyed on the web portal.
