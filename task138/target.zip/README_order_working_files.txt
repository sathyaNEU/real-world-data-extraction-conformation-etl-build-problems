Kestrel Bend Irrigation District, Water Resources
2027 order: working files, compiled 1 February 2027

File, what it is, where it came from:

KBID_Water_Order_Procedure_rev2025.pdf
    The Water Order Procedure (Resolution 2019-07, revised December 2025). Board records.
KBID_WOP_tables_2027_order.xlsx
    The procedure's Tables 1 to 5 for the 2027 order. Board records, adopted 9 December 2025.
kbid_water_requests_2027.xlsx
    Growers' 2027 water requests, every version. Request log, exported 1 February 2027.
kbid_field_register_2027-02-01.csv
    Field register: fields, turnouts, laterals, soil units. GIS, exported 1 February 2027.
station39_daily_1995-2027.csv
    Daily weather, station 39 (Kestrel Bend South), October 1995 to January 2027. State agricultural weather network download, 1 February 2027.
kbid_station_daily_2014-2027.csv
    Daily weather, Kestrel Bend yard station, April 2014 to January 2027. Yard logger export, 1 February 2027.
kbid_irrigation_orders_2023-2026.csv
    Irrigation orders, 2023 to 2026 seasons. Ordering system, exported 1 February 2027.
kbid_meter_book_2026.csv
    Riders' turnout meter reads, 2026. Meter book, closed 30 November 2026.
kbid_meter_shop_log_2026.xlsx
    Meter changes in 2026 and meters in service. Meter shop.
kbid_lateral_headings_daily_2026.csv
    Daily volume at each lateral heading, 2026 season. SCADA daily report.
kbid_tail_weir_sheets_2026.csv
    Riders' tail weir sheets, 2026 season. Water Master's office.
kbid_canal_structures.xlsx
    Tail weirs, lateral headings and main canal structures. District Engineer's inventory.
kbid_canal_operations_log_2026.docx
    Canal operations log, 2026 season. Water Master's office.
kbid_groundwater_levels_2016-2026.csv
    Spring and fall depth to groundwater at the District's monitoring wells, 2016 to 2026. Groundwater monitoring program.
kbid_crop_report_2026.csv
    2026 crop survey by field. Water Conservation, June and July 2026.
TVWA_2027_initial_allocation_notice.pdf
    The Authority's 2027 initial allocation notice. Tolan Valley Water Authority, 15 December 2026.
kbid_data_dictionary.xlsx
    Field definitions for these files. Water Resources.

Station 39 data are published by the state agricultural weather network and used as published.
