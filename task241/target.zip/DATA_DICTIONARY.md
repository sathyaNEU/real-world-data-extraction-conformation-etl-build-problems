# Data dictionary

## ibfa_float_register.csv
One row per float of the Iberian Basin Float Array.

| Column | Meaning |
|---|---|
| wmo | the float's WMO number |
| serial | manufacturer's serial number |
| model | float model, K or A |
| telecom | telemetry, Argos or Iridium |
| ctd_serial | serial number of the float's CTD |
| deployed | deployment date |
| deploy_lat, deploy_lon | deployment position, decimal degrees |
| profiles | the profiles the float is set to record |
| cycle_days, park_dbar, profile_dbar | cycle length (days), parking pressure and profile pressure (dbar) |

## ibfa_profiles_2027.csv
One row per profile file the data centre decoded for the year: the array's floats and the partner float decoded beside them.

| Column | Meaning |
|---|---|
| profile_id | the data centre's id for the decoded file |
| wmo, cycle | float and cycle number |
| direction | A ascending, D descending |
| juld | the profile's date and time, days since 1950-01-01 00:00 UTC |
| latitude, longitude | the profile's position, decimal degrees |
| position_qc | 1 a fix, 8 estimated |
| file_version | 1 the first file received for the profile, 2 a later file for the same profile |

## ibfa_profile_levels_2027.csv
One row per pressure level of a profile file.

| Column | Meaning |
|---|---|
| profile_id | the profile file |
| pres | sea pressure, dbar |
| temp | in-situ temperature, ITS-90, degrees C |
| psal | practical salinity |
| pres_qc, temp_qc, psal_qc | real-time flags: 1 good, 2 probably good, 3 probably bad, 4 bad |

## ibfa_cycle_technical_2027.csv
One row per float cycle: the cycle's timing and engineering values from the float's technical message. Times are UTC.

| Column | Meaning |
|---|---|
| wmo, cycle | float and cycle number |
| descent_start | start of the descent from the surface |
| park_start, park_end | start and end of the drift at parking pressure |
| ascent_start | start of the ascent from 2,000 dbar |
| ascent_end | end of the ascent |
| battery_v | battery voltage at the surface |
| vacuum_mbar | internal pressure |
| pump_s | buoyancy pump run time on the ascent, seconds |

## ioa_dac_receipt_log_2027.csv
The data centre's receipt log for profile files of 2027 cycles, to the morning of 7 January 2028.

| Column | Meaning |
|---|---|
| received | when the data centre's server received the file, on the server's clock (Lisbon local time) |
| wmo, cycle, direction | the profile the file carries |
| file_name | file name as received |
| file_version | 1 the first file for the profile, 2 a later one |
| n_levels | levels decoded from the file |

## ioa_ctd_archive_stations.csv and ioa_ctd_archive_levels.csv
The institute's CTD archive: one row per cast, and one row per 10 dbar level of a cast.

| Column | Meaning |
|---|---|
| cast_id | cruise and station |
| cruise, station | cruise code and station number |
| time_utc | start of the cast, UTC |
| latitude, longitude | decimal degrees |
| temp_scale | temperature scale of the cast's temperatures, IPTS-68 or ITS-90 |
| max_pres | deepest level of the cast, dbar |
| pres | pressure, dbar |
| temp | in-situ temperature in the cast's scale, degrees C |
| psal | practical salinity |

## rhd_extract_iberian_basin_stations.csv and rhd_extract_iberian_basin_levels.csv
The RHD extract for the box: one row per station, and one row per level.

| Column | Meaning |
|---|---|
| station_id | the RHD's station id |
| platform, country | ship and country of the submitting institute |
| date | date of the cast, UTC |
| time | time of the cast, decimal hours UTC |
| lat, lon | decimal degrees, to 0.01 |
| max_depth_m | deepest level, metres |
| depth_m | depth, metres |
| temperature | in-situ temperature, ITS-90, degrees C |
| salinity | practical salinity |

## ibfa_recovered_sensor_checks.csv
Floats of the programme's earlier arrays that were recovered, and what the laboratory found when it checked their sensors against a reference bath.

| Column | Meaning |
|---|---|
| wmo | the float |
| deployed, recovered | dates |
| reason | why the float was recovered |
| lab_salinity_error | salinity the float's CTD read less the bath's, practical salinity |
| lab_temperature_error | temperature the float's CTD read less the bath's, degrees C |

## ibfa_oxygen_2027.csv
Dissolved oxygen from the six model A floats carrying an optode, at every second level of the ascending profile.

| Column | Meaning |
|---|---|
| profile_id | the profile file |
| pres | pressure, dbar |
| doxy | dissolved oxygen, micromoles per kilogram |
| doxy_qc | real-time flag |
