# IBFA 2027 delayed-mode salinity release

The Instituto Oceânico do Atlântico's Ocean Data Centre: the Iberian Basin Float Array's profiles for 2027, the reference data frozen for
the year's delayed-mode check, and the records behind the release report. Drawn on 7 January 2028.

| File | What it is |
|---|---|
| ioa_dmqc_2027_release_thread.eml | the release thread, 13 December 2027 to 7 January 2028 |
| ioa_reference_data_note.docx | the reference data note |
| ibfa_float_models.pdf | the float programme's summary of the two float models |
| ibfa_float_register.csv | the float register |
| ibfa_profiles_2027.csv | the year's decoded profile files |
| ibfa_profile_levels_2027.csv | their levels |
| ibfa_cycle_technical_2027.csv | each cycle's timing and engineering values |
| ioa_dac_receipt_log_2027.csv | the data centre's receipt log |
| ioa_ctd_archive_stations.csv | the institute's CTD archive, casts |
| ioa_ctd_archive_levels.csv | the institute's CTD archive, levels |
| rhd_extract_iberian_basin_stations.csv | the RHD extract, stations |
| rhd_extract_iberian_basin_levels.csv | the RHD extract, levels |
| ibfa_recovered_sensor_checks.csv | laboratory checks of sensors from recovered floats |
| ibfa_oxygen_2027.csv | dissolved oxygen from the floats with optodes |
| DATA_DICTIONARY.md | the columns of every table |
