# Experiment platform change log, 2026

Experimentation Platform, Avisly Medier A/S. Entries in date order.

- **5 January.** The 2026 experiment calendar opens. Every experiment runs 14 days from a Monday.
- **11 February.** The collector's certificate rotation fails for about three hours; uploads are refused and retried.
  Logged in the incident register against the whole app.
- **2 March.** Data-health desk moves the weekly review to Monday mornings.
- **30 March.** Last experiments started under scorecard service 1.
- **13 April.** Scorecard service 2 in production. Install exports move from CSV to Parquet; columns are renamed
  and the arms are called control and treatment (service 1 called them A and B). Content unchanged.
- **18 May.** New consent dialog on web.
- **1 July.** SDK 9.3 rolls out on iOS and Android.
- **3 August.** SDK 9.4.1 batching regression; fixed in 9.4.2 on 6 August.
- **14 September.** Last experiments of the 2026 record start.
- **5 October.** DH-3, the data-health hold for experiment readouts, approved; in force from 4 January 2027.
- **12 October.** Registry, install exports, incident register and review log pulled for the Data-health desk.
