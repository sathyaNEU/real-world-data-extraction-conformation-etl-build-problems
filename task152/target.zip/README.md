# Hadley Ranch Solar: data pull for the 2027 forward sale

Pulled by Selena Sloan (Solar Asset Manager) on October 6, 2026 for Kristopher Lara (Energy and Commodities Manager). All times on site are Arizona time, which is Mountain Standard Time all year (UTC-7); files stamped in UTC say so.

## The plant

- Commercial operation November 20, 2015. Sixteen 2,500 kW central inverters in four blocks of four, each fed by 8,000 Kellerman KS-315P modules (400 strings of 20, 2,520 kWp per inverter, 40,320 kWp in all) on fixed tables at 25 degrees facing south.
- The plant exports at 69 kV to the Vado Seco Irrigation and Power District (VSIPD) through the Hadley Ranch substation. The district's revenue meter there is service point 0417 on account 7731-0459.
- Tresco Field Services has operated and maintained the plant since commercial operation; the current agreement started January 1, 2021.
- Module replacement works started October 5, 2026 (scope in the July 2026 paper).

## SCADA

- `hrs_scada_daily_report_2015-11-20_to_2020-03-02.csv`: the original SCADA's daily report, one row per local day, energies in kWh, inverters INV01 to INV16. The server lost August 14 to 16, 2018 in a disk failure; those days are not in the file.
- `hadley_scada_daily_2020-03-03_to_2026-09-30.csv`: the replacement SCADA's daily export from March 3, 2020, one row per device, point and day. `day_start_utc` is the start of the local day in UTC (07:00Z). Energies in MWh.
- `scada_tag_crosswalk.csv`: the original inverter numbers against the replacement SCADA's block tags. Inverter 07 (B2-INV3) was destroyed by a power stage fire on March 2, 2021; its replacement has run as B2-INV3R since April 15, 2021, on the same array.
- Points in both layouts: DC energy measured at each inverter's DC input (`E_DC`, `_DC_kWh`); AC energy at the inverter's AC output (`E_AC`, `_AC_kWh`); hours the inverter spent feeding the grid that day (`T_OP`, `_OpHrs`); plane-of-array irradiation from the met station's pyranometer (`H_POA`, kWh/m2); the back-of-module temperature at the met station averaged over the day weighted by plane-of-array irradiance (`T_MOD_IW`, `TMod_IW_C`); the daily mean air temperature; and the revenue meter's export and import registers as the SCADA reads them (`PLANT-RM` `E_EXP` and `E_IMP`, `Meter_Export_kWh` and `Meter_Import_kWh`).

## 2025 detail

- `inverter_hourly_ac_2025.csv`: each inverter's AC energy in each hour of 2025 and its lifetime AC energy register at the end of the hour (kWh), as the four block data loggers forward them. `interval_end_utc` is the end of the hour in UTC.
- `met_station_hourly_2025.csv`: the met station's hourly means for 2025; `hour_beginning_mst` is the local hour.
- `inverter_event_log_2025.csv`: the inverters' alarm and event log for 2025 (raised and cleared in UTC; `ack_by` is the Tresco control room user who acknowledged it, blank when the event cleared itself).

## Work orders

- `tresco_work_orders_hadley_ranch_2015-2026.xlsx`: Tresco's work orders for the site from handover to the pull. Types: CLN cleaning, CM corrective, PM preventive, INSP inspection, OWN owner request, VEG vegetation, PROJ project work. Created and completed times are local.

## District files (account 7731-0459)

- `vsipd_acct_7731-0459_daily_legacy_2015-2020.txt`: the district's legacy billing system, daily totals from November 20, 2015 to February 29, 2020. Fixed width: account (10), service point (6), meter (10), channel (4), interval end date and time (YYYYMMDD HHMM), kWh, read status (A actual, E estimated). A day's total is stamped with the end of its interval.
- `vsipd_acct_7731-0459_mdm_daily_2019-10-01_2025-12-31.csv`: the district's meter data system from October 1, 2019, when it went live with its history load, to December 31, 2025; one row per service point, channel, day and version.
- `vsipd_acct_7731-0459_service_points.csv`: the service points on the account.
- Channels are named from the district's side: REC is the energy the district received from the service point, DEL the energy it delivered to it.
- The district's revenue meter at service point 0417 is the meter of record (interconnection agreement, Exhibit C); these files are the district's reads of it. The SCADA's `PLANT-RM` points are the control room's own read of the same meter and stop when the SCADA does.

## Desk

- `power_forward_blotter_2015-2025.xlsx`: the desk's blotter of Hadley Ranch forward trades, quantities as traded.
- `westmark_confirmations_hadley_ranch_cy2016-cy2026.pdf`: Westmark's confirmations.
- `palo_verde_forwards_cal2027_2026-10-05.csv`: the desk's Palo Verde forward marks for 2027 on October 5, 2026.

## Resource and documents

- `clearfield_hadley_ranch_poa_hourly_2001-2025.csv`: Clearfield Solar Resource's site-adapted hourly series for the plant, 2001 to 2025 (delivered January 2026; details in the file header).
- `marden-vail_energy_risk_policy_rev4.pdf`: the treasury's energy risk policy (revision 4).
- `hadley_ranch_module_replacement_scope_2026-07.docx`: the module replacement scope and schedule (July 2026).
- `corvane_fa-2026-114_hadley_ranch_side_by_side.pdf`: Corvane's report on the side-by-side comparison in block 3.
- `module_datasheets_ks-315p_cv-450bhc.pdf`: the datasheets of the original and the new modules.
- `tresco_om_agreement_2021_schedules_2_and_4.pdf`: the O&M agreement's cleaning and availability schedules.
- `vsipd_lgia_hadley_ranch_exhibit_c_metering.pdf`: the interconnection agreement's metering exhibit.
- `vsipd_interruptions_hadley_ranch_69kv_tap_2025.pdf`: the district's 2025 interruption report for the plant's 69 kV tap.
- `tresco_repowering_program_2019-2026.pdf`: Tresco's summary of the plants it has repowered.
