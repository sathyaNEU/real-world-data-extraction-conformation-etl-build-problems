# Line exports for 2025-26: what is in each file

Exports pulled on 1 July 2026 from the MES, the stores system and the end-of-line test benches, for the 2025-26
planning work. Times are local time (Europe/Amsterdam). Platform codes in the MES: VH Volta hatch, KS Kestrel SUV,
PS Plover saloon, MC Mira city car, TV Tern van.

## mes_werkorders_2025-26.csv

One row per work order opened from 1 December 2024: `werkorder`, `geopend` (date opened), `platformcode`, `kerncode`
(the core the pack is built on), `status` on 1 July 2026 (VERZONDEN shipped, AFGEKEURD scrapped, IN BEWERKING still on
the line) and `afgesloten` (date closed).

## magazijn_mutaties_2025-26.csv

Stores movements against work orders with a booking date from 1 July 2025 to 30 June 2026. `soort` is UITGIFTE for an
issue and RETOUR for a return to stores, which carries a negative quantity. `aantal` is in the article's unit (see
artikelstam_modules.xlsx). `partij` is the supplier lot the units came from; stores keeps its stock by lot, and no lot's stock goes
below zero. `picklijst` is the pick list the units went out on; one list can serve several work orders.

## magazijn_ontvangsten_2025-26.csv

Goods received into stores from 1 July 2025 to 30 June 2026, one row per supplier lot, with the supplier's delivery
note.

## artikelstam_modules.xlsx

The module articles, current (actief) and superseded (vervallen): description, platform, stores unit, the modules in
one unit and the supplier.

## eol_testlog_2025-26.csv

Every end-of-line test run since the benches went live on 6 January 2025. `pakket_id` is the pack's serial number,
`programma` the test programme, `resultaat` PASS, FAIL or ABORT. ABORT means the bench stopped the run itself (a
bench, contact or cooling fault); an aborted run is no test of the pack, which is run again.

## mes_bms_koppelingen_2025-26.csv

Every BMS paired to a pack on a work order opened from 1 December 2024: `soort` is MONTAGE when the pack is assembled
and VERVANGING when a BMS is replaced.

## verzendingen_2025-26.csv

Packs shipped to garages from 1 July 2025 to 30 June 2026, one row per shipment.

## kernen_inname_2025-26.csv

Cores received from 1 July 2025 to 30 June 2026 and graded at dock 1 or dock 2: `herkomst` is garage (the failed pack
sent back when a garage fits one of ours) or inkoop (cores bought in), `keuring` is the core's grade on 1 July 2026, A,
B or AFGEKEURD, with the reason.

## afvoer_recycler_2025-26.xlsx

The recycler's waste transfer notes for its Wednesday collections from 2 July 2025 to 1 July 2026, one line per pack
collected, with the date on the quarantine tag.
