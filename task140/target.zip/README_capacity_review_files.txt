Alisio Viajes, Compute Operations (MAD1)
C-22 capacity review for 2027 Q1: files, compiled 14 December 2026

File, what it is, where it came from:

CS-3_cell_capacity_standard_rev2026-06.pdf
    Cell Capacity Standard CS-3, revision of June 2026. Infrastructure, approved 22 June 2026.
capacity_memo_2027Q1.docx
    Capacity memo for the C-22 review of 2027 Q1. Head of Infrastructure, 9 December 2026.
c22_hardware_plan_2027Q1_rev2026-12-11.xlsx
    C-22 hardware plan for 2027 Q1, racks and machines in service by date. Fleet & Hardware, revision of 11 December 2026.
capacity_requests_2027Q1.csv
    Firm tenants' reservation requests for 2027 Q1. Quota tool, request window 16 November to 4 December 2026.
tech_budgets_2026_Q1-2027_freeze.xlsx
    Technology compute budgets by cost centre, 2026 and January to March 2027, with the freeze record. Technology Controlling, 27 November 2026.
compute_rate_card.csv
    Compute rate card for MAD1 reserved cores, every rate by effective date. Technology Controlling.
c22_reservation_ledger_2025Q1-2026Q4.csv
    C-22 reservation ledger, 2025 Q1 to 2026 Q4, as approved at each review. Compute Operations.
c22_usage_hourly_2025-01-01_2026-12-13.csv
    C-22 monitoring export, each tenant's average cores in use by hour, 1 January 2025 to 13 December 2026. Cell monitoring, pulled 14 December 2026 06:10 UTC.
c22_cell_hourly_2025-01-01_2026-12-13.csv
    C-22 machines installed and in service by hour, same period. Cell monitoring, pulled 14 December 2026 06:10 UTC.
tenant_directory.json
    C-22 tenant directory. Compute Operations, 1 December 2026.
c22_capacity_report_2026Q3.pdf
    C-22 capacity report for 2026 Q3. Compute Operations, 6 October 2026.
mad1_operations_log_2026H2.docx
    MAD1 operations log, July to December 2026. Data-centre operations.
batch_runs_2026Q3.csv
    Batch training runs that held cores in 2026 Q3. Batch scheduler, quarter snapshot of 1 October 2026.
batch_checkpoints_2026Q3.csv
    Checkpoints written by those runs, and the checkpoints their resumptions restored. Batch scheduler, quarter snapshot of 1 October 2026.
batch_resizes_2026Q3.csv
    Resizes of elastic batch runs in 2026 Q3. Batch scheduler, quarter snapshot of 1 October 2026.
c22_machine_events_2026Q3.csv
    C-22 machine events, 1 July to 30 September 2026. MAD1 cluster manager event log.
mad1_hardware_inventory_2026-12.xlsx
    MAD1 hardware inventory for C-22, assets and their cluster ids. Fleet & Hardware, extract of 14 December 2026.
quota_changes_2026Q3.csv
    Changes to firm reservations in 2026 Q3. Quota tool.
quota_reconciler_runs_2026Q3.csv
    Quota service reconciliation runs in 2026 Q3. Quota service log.
chargeback_policy_2026.pdf
    Technology chargeback policy 2026. Technology Controlling.
data_dictionary.xlsx
    Field definitions for these files. Compute Operations.
mad1_cells_quarterly_summary_2025-2026.xlsx
    MAD1 compute cells' quarterly summary, 2025 and 2026. Compute Operations, 2 October 2026.
batch_training_demand_2027H1.pdf
    ML Platform's note on batch training demand for January to June 2027. ML Platform, 2 December 2026.

Times are UTC unless a file says otherwise. Tenant ids are those of the tenant directory.
