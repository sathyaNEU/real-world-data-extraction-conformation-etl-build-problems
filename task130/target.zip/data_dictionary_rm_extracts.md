# Risk management extracts: data dictionary

Corvane Health, Risk Management and Insurance. Field definitions for the files extracted on 2 October 2026 for the 2027 trust contribution. Maintained by Lori Williams's claims team; questions to the RMI analytics mailbox.

## rm_claims_register_extract_20261002.csv

One row per clinician named as a defendant on a claim number. The register holds every claim naming a clinician who practised at a Corvane entity, whoever insures the clinician; claims against the entities alone are kept in the general liability register. Valued at 30 September 2026; 618 rows.

- `claim_no`: Risk management claim number, CL-year-sequence, given when the claim is received.
- `incident_no`: Risk management incident number of the event the claim arises from, IR-year-sequence.
- `defendant_seq`: Order in which the clinician is named on the claim number.
- `clinician_id`: Payroll employee id for employed clinicians, residents and fellows; CTR- credentialing number for contracted and locum clinicians.
- `defendant_role`: Attending physician, Advanced practice clinician, Resident physician, Clinical fellow or Contracted physician.
- `specialty`: Specialty as entered by the claims analyst.
- `coverage_line`: The insurance programme responding for this defendant: carrier code and entity (QM-TFH, QM-AMC, SC-CMG, SC-BCH); CONTRACT where the clinician's own group insures them.
- `entity_at_incident`: Entity where the care was given.
- `incident_date`: Date of the care the claim arises from.
- `claim_made_date`: Date risk management received the claim under this claim number.
- `matter_type`: Claim (a demand or request for compensation) or Suit (a civil proceeding served).
- `allegation`: Principal allegation.
- `status`: OPEN, CLOSED or REOPENED at the valuation date. A reopened claim keeps its earlier closing date.
- `closed_date`: Date the claim number was last closed.
- `indemnity_paid, defense_paid`: Payments to date on this defendant, in dollars. Blank on CONTRACT rows.
- `indemnity_reserve, defense_reserve`: Case reserves on this defendant at the valuation date. Blank on CONTRACT rows.
- `prior_claim_no`: Where the claim number was opened from an earlier claim number for the same matter, the earlier claim number.
- `valuation_date`: Valuation date of the extract.

## clinician_fte_by_month_2016-01_2025-12.csv

Legacy payroll history for employed clinicians, residents, fellows and psychologists, January 2016 to December 2025 (the legacy payroll closed with the December 2025 pay run). One row per employee, month and cost centre; 114499 rows.

- `pay_month`: Month paid, YYYY-MM.
- `employee_id`: Payroll employee id.
- `job_code, job_title`: Job held in the month. Codes changed with the job architecture project on 1 July 2020.
- `cost_centre`: Company and department, ccc-dddd.
- `entity_code`: Entity of the cost centre.
- `fte`: Paid FTE for the month on this cost centre.
- `emp_status`: A active, L leave of absence, T terminated in the month.

## hcm_clinician_pay_lines_2026-01_2026-09.csv

Pay lines from the HCM system that replaced the legacy payroll on 1 January 2026, work months January to September 2026. One row per worker, position, work month and earning code; 15665 rows.

- `worker_id`: Employee id (carried over from the legacy payroll).
- `position_id`: HCM position.
- `work_month`: Month worked, YYYY-MM.
- `earning_code, earning_description`: REG, PTO, CALL, ADMIN or LOA.
- `hours`: Hours paid on the line.
- `fte`: FTE of the position.
- `job_profile_code, job_profile`: HCM job profile of the position; legacy job codes through the crosswalk.
- `cost_centre`: Cost centre the line is charged to.
- `home_entity`: The worker's home entity on their HCM record at the time of the extract.
- `pay_group`: PHYS, APC or GME.

## hcm_job_profile_crosswalk.csv and cost_centre_directory_2026.csv

The HCM job profile crosswalk maps each HCM job profile to the legacy job code (2020 code set) it replaced. The cost centre directory gives each cost centre's company, entity and department with the dates it is effective.

## rm_carrier_notices_2012_2026.csv

One row per precautionary notice risk management sent to a carrier about an incident that might lead to a claim; 666 rows, January 2012 to September 2026.

## Carrier loss runs

QMPL_loss_run_Corvane_val_2026-09-30.xlsx, QMPL_loss_run_Corvane_val_2026-06-30_rev1.xlsx and Stoneleigh_lossrun_CORVANE_20260930.csv are the carriers' files as received, in their own layouts and field names. Quillan Mutual insures Tolliver Falls Hospital and Alderwick Medical Center; Stoneleigh Casualty insures Corvane Medical Group and Brennick Community Hospital.

## patient_safety_events_2019-01_2026-09.csv

Patient safety event reports from the safety reporting system, January 2019 to September 2026, one row per report; 34864 rows. Harm level as assigned at the quality team's review.
