# Data dictionary

Household Resources Survey 2027 files held by Larchmere Social Research. Times are the province's local time.

## hrs27_households.csv
One row per household that gave a full interview (final outcome 110).
- `hh_id`: the household's identifier, the address identifier of its address.
- `region`: the household's health region.
- `stratum`: the stratum of the household's PSU for estimation: the health region, then `U` (urban) or `R` (rural).
- `psu`: the primary sampling unit.
- `interview_date`: the date of the interview.
- `adults`, `children`: the household's members aged 16 and over, and under 16.
- `tenure`, `arrears`: the household's answers (codebook, sheet Questions).

## hrs27_household_members.csv
One row per member on each responding household's roster: `hh_id`; `person_no` (the member's number on the household's
roster, from 1); `age`; `sex` (1 male, 2 female); `proxy` (`Y` where another member answered for the adult; blank
for children); `pension` and `care` (codebook, sheet Questions).

## hrs27_final_weights.csv
One row per adult in a responding household: `hh_id`, `person_no`, `final_weight` (the weighting note).

## hrs27_issued_sample.csv
One row per address issued for interview in 2027.
- `address_id`: the address identifier.
- `psu`: the address's PSU.
- `region_code`: the health region code held for the PSU in the master sample.
- `psu_frame`: the master-sample selection the PSU came from: `2023` (the 2023 selection) or `2026` (the 2026 top-up).
- `dwelling`: the dwelling type recorded at listing.

## hrs27_outcomes_2027-09-30.csv
The case system's outcomes as extracted on 30 September 2027: one row per issue of an address. `address_id`;
`issue_no` (1 for the first issue, 2 for a reissue); `interviewer_id`; `outcome_code` (QS-7 Table 1);
`outcome_date` (the date of the call the outcome comes from).

## hrs27_call_records.csv
The call records exported on 18 October 2027: one row per record received from interviewers' tablets and the
office.
- `record_id`: the office's number for the record, given as each record arrived.
- `address_id`, `issue_no`.
- `event_no`: the record's number among its address's records for the issue, as the tablet wrote them.
- `event_time`: when the call was made, the letter posted or the card left.
- `event_type`, `result`: codebook, sheet Call log codes.
- `interviewer_id`: the interviewer working the issue (`OFFICE` for letters).
- `received_at`: when the record reached the office.

## hrs27_interviewers.csv
The wave's interviewer list: `interviewer_id`, `home_region`, `psus_assigned`, `hours_claimed` (hours claimed on
timesheets for the wave).

## ssb_population_estimates_2027-07-01.csv
The Branch's population estimates of adults on 1 July 2027 by health region, sex and five-year age band, in thousands.

## hrs27_codebook.xlsx
The questions behind the published tables and their codes, the published tables, and the call log codes.
