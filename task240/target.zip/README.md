# Household Resources Survey 2027: wave files

Larchmere Social Research's files for the 2027 wave of the Household Resources Survey, run for the Statistics and Surveys Branch under contract, gathered by
Kristina Stephens (Lead Survey Statistician) on Friday 3 December 2027 for the wave's quality report. The tables and the quality
report are due to the Branch on 10 December.

- `ssb_qs7_statistical_quality_standard.pdf`: the Branch's statistical quality standard QS-7, edition 3.
- `hrs27_weighting_note.docx`: how the 2027 weights were made.
- `hrs27_fieldwork_closeout.docx`: the fieldwork close-out, 4 October 2027.
- `hrs27_codebook.xlsx`: the 2027 codebook.
- `hrs27_households.csv`, `hrs27_household_members.csv`, `hrs27_final_weights.csv`: the analysis files, frozen with the weights on 12 November 2027.
- `hrs27_issued_sample.csv`: the issued sample.
- `hrs27_outcomes_2027-09-30.csv`: the outcome extract of 30 September 2027.
- `hrs27_call_records.csv`: the call records exported on 18 October 2027.
- `hrs27_interviewers.csv`: the interviewer list.
- `ssb_population_estimates_2027-07-01.csv`: the Branch's population estimates for 1 July 2027.
- `DATA_DICTIONARY.md`: the files and their fields.
