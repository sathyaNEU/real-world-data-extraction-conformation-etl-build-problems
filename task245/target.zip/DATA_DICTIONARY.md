# Data dictionary

## thornmouth_council_aq_hourly_2027.csv
The council's 2027 export from the network database: one row per station, pollutant and hour.
- site_code, site_name: the council station.
- pollutant: PM10, NO2, or NOx as NO2.
- date: dd/mm/yyyy (GMT); time_end: the end of the hour (01:00 to 24:00, the hour ending 24:00 closing the day).
- value: the hourly mean in ug/m3, blank where the hour is not valid.
- unit: ug/m3.
- status: R ratified and valid; F analyser fault; X rejected at ratification; S service or calibration; P power or
  telemetry lost; O station out of service (procedure section 2.3).

## tbt_pm10_permit_monitoring_2027.xlsx
The terminal operator's 2027 PM10 workbook, one sheet per quarter of its logger's clock: a date/time column in UK clock
time (the start of the hour), then for each of its five stations a PM10 column (ug/m3) and a status column as ratified
under the procedure (OK valid; FAULT analyser fault; REJECTED rejected at ratification; SERVICE service or calibration;
POWER power or telemetry lost; OFF out of service).

## port_met_mast_hourly_2027.csv
The port's met mast (10 m mast on the east breakwater): datetime_end_gmt (the end of the hour, GMT); wind_dir_deg (the
direction the wind blows from, degrees true, blank in calm); wind_speed_ms (m/s); rain_mm; air_temperature_c (degrees C). Hours the
mast did not report are blank.

## thornmouth_aq_station_register.csv
One row per station: site_code, site_name, operator, site_type, easting and northing (Ordnance Survey national grid,
metres), pm10_analyser, no2_analyser, inlet_height_m.

## aq_network_service_log_2027.xlsx
Both technicians' records: date and time (UK clock), site, site name, type (alarm, fault visit, service, calibration,
repair, site works, logger, deposit gauge), engineer, notes.

## tbt_deposit_gauge_results_2027.xlsx
The terminal's laboratory results for its deposit gauges: gauge, site, date on and date off (dd/mm/yyyy), days
exposed, insoluble, soluble and total deposit (mg), collecting area (m2) and deposition rate (mg/m2/day) as the
laboratory reports them, laboratory reference, remarks.

## asr2027_table_a3_no2_2026.pdf
Table A.3 of last year's ASR: each council NO2 station's 2026 data capture and annual mean.

## background_maps_2027_thornmouth_extract.csv
The background map extract used for the 2026 ASR: modelled annual mean background PM10 and NO2 for 2027 on the
national grid's 1 km squares (x and y, the square's centre, metres), with the main source sectors.
