# Thornmouth air quality network: 2027 data audit

Files for the PM10 data-capture review of the network's 2027 results, gathered by the council's air quality team.

- aq_audit_2027_pm10_note_request.eml: the air quality officer's request.
- tbc_aq_network_qaqc_procedure_v4.pdf: the council's QA/QC procedure for the network (version 4).
- thornmouth_council_aq_hourly_2027.csv: the council's 2027 export from the network database (ratified hourly PM10, NO2 and NOx).
- tbt_pm10_permit_monitoring_2027.xlsx: the terminal operator's 2027 PM10 workbook.
- port_met_mast_hourly_2027.csv: the port's met mast, 2027.
- thornmouth_aq_station_register.csv: the network's station register.
- aq_network_service_log_2027.xlsx: the council's and the operator's service records for 2027.
- tbt_deposit_gauge_results_2027.xlsx: the terminal's deposit gauge results.
- tbt_dust_management_monitoring_plan_rev3.pdf: the terminal's dust management and monitoring plan, revision 3.
- asr2027_table_a3_no2_2026.pdf: last year's ASR NO2 table.
- background_maps_2027_thornmouth_extract.csv: the background map extract used for last year's ASR.
- DATA_DICTIONARY.md: the fields of each file.
