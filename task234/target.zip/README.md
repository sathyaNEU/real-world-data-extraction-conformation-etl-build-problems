# Respiratory feed escalations, MMWR week 3 of 2027

| File | What it is |
|---|---|
| elr_respiratory_results_extract_2027-01-25.csv | the platform's respiratory result messages for weeks 2 and 3, extracted Monday 25 January 08:00 |
| lab_weekly_aggregate_reports.csv | the laboratories' weekly aggregate reports since October 2022 |
| respiratory_stream_register.xlsx | the laboratories, their facility identifiers and the 29 result streams |
| elr_result_codes.csv | respiratory test codes |
| FCP-2_feed_completeness_protocol.pdf | the feed completeness protocol |
| surveillance_platform_change_log.csv | platform and ELR changes since September 2026 |
| ed_syndromic_ili_weekly.csv | emergency department ILI visits by week and age group |
| state_respiratory_positivity_by_region.csv | the state's weekly per cent positive by region |
| county_respiratory_admissions_weekly.csv | weekly respiratory hospital admissions in the county |
| DATA_DICTIONARY.md | column definitions |
