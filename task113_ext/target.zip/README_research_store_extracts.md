# Research store extracts, US small and mid cap equities

Systematic Equity, research data. Pulled for the store refresh of 9 October 2026.

| File | Source | Pulled | Rows |
|---|---|---|---|
| merriden_eod_us_equity_2018_2023.csv | Merriden, legacy platform (final history file) | 2024-01-10 | 186,430 |
| merriden_eod_us_equity_2023q4_2026q3.parquet | Merriden, current platform | 2026-10-06 | 91,128 |
| merriden_security_master_history.csv | Merriden | 2026-10-06 | 176 |
| merriden_corporate_actions_2018_2026.json | Merriden | 2026-10-06 | 2,039 |
| merriden_delisting_final_values.xlsx | Merriden | 2026-10-07 | 21 |
| ledgerpoint_quarterly_pit_2017_2026.csv | Ledgerpoint | 2026-10-08 | 9,514 |
| ledgerpoint_earnings_calendar.jsonl | Ledgerpoint | 2026-10-08 | 8,083 |
| northcote_us_smallcap_select_reconstitutions.xlsx | Northcote | 2026-07-10 | 800 |
| northcote_us_smallcap_select_levels.csv | Northcote | 2026-10-02 | 2,198 |
| short_interest_semimonthly_2018_2026.txt | Exchange short interest files | 2026-10-08 | 25,801 |
| harrowgate_sweep_rate_daily.csv | Harrowgate Trust (custodian) | 2026-10-07 | 3,202 |
| pellbrook_oms_orders_2023_2026.csv | Pellbrook OMS | 2026-10-05 | 2,223 |
| kelloway_executions_2023_2026.csv | Kelloway Securities | 2026-10-05 | 32,596 |
| merriden_eod_data_dictionary_v4.pdf | Merriden | 2024-01-08 |  |
| merriden_corporate_actions_feed_spec.pdf | Merriden | 2023-06-12 |  |
| ledgerpoint_pit_fundamentals_guide.pdf | Ledgerpoint | 2025-03-17 |  |
| northcote_us_smallcap_select_methodology.pdf | Northcote | 2025-02-14 |  |
| kelloway_commission_schedule_2025.pdf | Kelloway Securities | 2025-02-10 |  |

## Notes

- Universe: security list PBK-RU-01, every US common stock the store has followed since January 2018, delisted names included.
- Prices: the legacy history file ends 29 Dec 2023. The current platform's Parquet starts 2 Oct 2023, so Q4 2023 is in both. Keyed on security_id / SID (same number).
- Short interest is the exchanges' published file stacked as received, by symbol, with revisions as published.
- OMS times are UTC. Kelloway's executions are New York time.
- Sweep rate is the custodian's posted rate for each calendar day (weekends and holidays carry the previous business day's rate). Reference rate changed 1 Jul 2023.
- Ledgerpoint keys on lp_id; there is no Merriden id in its files. Map through ticker or CUSIP as of the date.
