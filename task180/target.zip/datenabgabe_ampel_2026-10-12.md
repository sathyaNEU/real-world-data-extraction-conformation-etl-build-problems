# Extract for the 2027 traffic-light outlook

Pulled 12 Oct 2026 by Amalie Mende (data office) for Gundula Atzler. Five plants under the Bergbehörde Süd scheme: Moorstetten (MOS),
Pfeilbrunn (PFB), Lanzenried (LZR), Wendelsried (WDR), Ottenmoos (OTM). Record 1 Jan 2023 to 30 Sep 2026 unless a
file says otherwise.

Files
- seismic_catalogue_reviewed_2023-01_2026-09.csv: reviewed catalogue, every event the analysts finalised in the region, one row per event. Times UTC, ML is the
  survey's local magnitude, depth below sea level. event_type earthquake or explosion (quarry blasts). analyst is the
  reviewer's initials, reviewed_utc when the event was finalised.
- origins_2023-01_2026-09.csv: the event database's origin table as stored, same period. Times UTC; ml is the local magnitude computed
  with each origin. Events the analysts deleted as false triggers are purged with their origins.
- injection_hourly_2023-01_2026-09.parquet: hourly means from each injection well's telemetry (scheme 6.1), stamped at the start of the hour, UTC.
  Rate in litres per second, wellhead pressure in bar.
- injection_reports_2023-2026.xlsx: the operators' monthly reports of metered volumes (scheme 6.2), as received, one sheet per year.
- plant_register.json, well_register.csv: our registers. Open-hole sections as surveyed; depths are true vertical depth below ground.
- station_inventory_2026-10-12.xml: station metadata as exported from the station database on 12 Oct, every channel epoch with its
  location code; dates UTC.
- availability_gaps_2026-01_2026-09.csv: data gaps of 60 s or more per channel from the archive's availability check, for 1 Jan to 30 Sep 2026
  local time; times UTC.
- field_visits_2026.xlsx: the field crew's visit sheet as kept.
- tls_scheme_2024.pdf, monitoring_ordinance_2026.pdf, operating_plans_2027.pdf: from the authority. tls_bulletin_2026Q3.pdf: ours, as published.
- federal_catalogue_2023-2026.csv: the federal agency's catalogue for the region (their ids and magnitudes, 2.0 and over), as downloaded.
- groundwater_levels_2025-01_2026-09.csv: shallow groundwater monitoring at the plants (water-law permits), monthly.
