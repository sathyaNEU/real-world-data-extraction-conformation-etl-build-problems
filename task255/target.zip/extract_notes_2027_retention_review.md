# Extract notes: 2027 retention review

Finance office, Fallowmere Intergovernmental Risk Pool. Files pulled for the trustees' November 2026 meeting; questions on the claims files to
Caleb Payne, on the declarations and schedules to the finance office. Filed with them as issued:
risk_financing_policy_2026.pdf, liability_coverage_memorandum_2026.pdf, actuarial_study_2026_selected_exhibits.pdf and excess_liability_indications_2027.pdf.

## liability_closed_claims_tallowmark_2014-2020.xlsx

Tallowmark's final run of the liability claims it closed, one sheet per accident year and a summary sheet, run
on 2 July 2020 at the end of its administration. Claims open on 30 June 2020 were converted to Brisbrook's
system and are in the current loss run. Member is the member code (member_roster.csv). Coverage: GL general
liability, AL automobile liability, LEL law enforcement liability, POL public officials' errors and omissions, EPL
employment practices liability. Dates are month/day/year. Amounts are dollars: Member Deductible is the member's
deductible for the occurrence; Indemnity Paid, Defense Paid and Total Paid are the pool's payments.

## liability_loss_run_brisbrook_2026-09-30.csv

Brisbrook's loss run of every liability occurrence it has handled since 1 July 2020, open and closed, at
30 September 2026. prior_claim_no is the Tallowmark number of a claim converted on 1 July 2020. coverage: GENL,
AUTO, LAWE, PUBO and EMPL are the same five parts as Tallowmark's GL, AL, LEL, POL and EPL. deductible is the
member's deductible for the occurrence; the paid_ and reserve_ columns are the pool's payments and case reserves to
date, indemnity and defense, in dollars.

## vehicle_schedule_log_2022-2026.csv

The transaction log of the pool's vehicle schedule system from its opening load (dated 1 January 2022), with
every entry keyed through 19 October 2026: one row for each add, delete or change of a unit on a member's schedule. effective_date is when
the change applies to coverage; entered_date is when it was keyed. stated_value is the value carried for physical
damage cover, blank on deletes. A vehicle is identified by its VIN, or by its serial number where it has no VIN.
On 4 March 2024 the regional fleet consortium's lists for the members in it were loaded under the consortium's asset
numbers (FMC-); the members' earlier unit numbers for the same vehicles were left on the schedule, and the renewal
revaluations still reach them. Since the load the consortium's adds, changes and deletes for those vehicles come
under its asset numbers.

## exposure_declarations_2027.xlsx

The 2027 renewal exposure declarations as exported from the declarations intake on 5 October 2026, one row for each
department line a member declared. Budget Basis says whether the member's 2027 budget was adopted or still proposed
when it declared.

## member_roster.csv

Every member since 2014: member number, legacy member code, class, the date it joined the pool and, where it has
left, the date it withdrew.

## member_deductible_history.csv

Each member's per-occurrence deductible since 2014, one row for each change, effective 1 January.

## liability_triangles_2026-09-30.csv

The actuary's development data for the liability program: the pool's paid and incurred (paid plus case reserves)
by accident year and evaluation date, with the counts of occurrences tendered and closed. Amounts are the pool's,
net of member deductibles.
