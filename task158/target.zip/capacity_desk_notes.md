# Capacity desk: notes on the 7 December pull

Casper Heijmans, fleet capacity. Pulled Monday 7 December 2026, 07:40 Amsterdam time. Times are UTC unless a file says
otherwise.

## Fleet rollup (`fleet_rollup_hourly_2026-01-01_2026-12-06.csv`)

One row per pool per hour, 1 January to 6 December 2026, from the capacity rollup (GPU busy time from the node
exporters, counters from the gateway).

- `hour_start_utc`: start of the hour.
- `pool`, `model`: the deployment and the model build it served; both builds, joined by `+`, while a rolling upgrade
  ran.
- `gpus_in_service`: GPUs on the pool's schedulable nodes when the hour closed.
- `gpu_busy_s`: GPU-seconds the pool's GPUs spent running kernels in the hour, summed over its GPUs.
- `requests`: requests completed in the hour. `sessions_new`: sessions opened in the hour.
- `prompt_tokens`, `completion_tokens`: prompt and completion tokens of the hour's completed requests.
- `ttft_p50_ms`, `ttft_p95_ms`: time to first token at the gateway.

A few hours are missing where the collector was down (chat-prod on the morning of 14 August, voice-prod one hour on
3 March).

## Docs usage (`docs_usage_by_org_daily_2026-09-01_2026-12-06.csv`)

Docs usage as billed: one row per organisation, channel and Amsterdam business day, 1 September to 6 December.
Channels: `app` (the web app), `api` (the enterprise API), `report` (the report service). Input tokens are prompt
tokens as billed.

## Maintenance exports

- `fleetctl_jobs_2026-10-26_2026-12-06.jsonl`: every step fleetctl logged for its jobs, one line per step.
- `ops_console_audit_2026-10-26_2026-12-06.csv`: actions taken in the ops console, with the console's own times.
- `fleet_nodes_2026-12-06.csv`: every node with its hall, rack and pool memberships (from, to).

Out of service: a node's GPUs are out of service from the node's cordon until its uncordon. A node cordoned again while
it is cordoned is out once. Hours fall in the month (UTC) they are spent in, and go to the pool the node belonged to at
the time.

## Stopgap cluster (Noordermeer, NX7)

The provider's burn-in and fabric exports (`nx7_burnin_results.csv`, `nx7_fabric_results.csv`) as received on 4
December, and its handover inventory (`nx7_handover_inventory_2026-12-04.csv`). Acceptance is Schedule 3 of the lease.

## Also in the folder

Q3 close-out, Q1 capacity intake, Q1 fleet plan (issue v3), report service commitments (export of 4 December), the stopgap
policy, the lease terms, the H2 incident log and the GPU spec register.
