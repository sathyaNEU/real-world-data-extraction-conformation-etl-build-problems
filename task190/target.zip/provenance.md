# Extract notes, financial crime data team

These files were pulled on 2027-07-19 for the annual report for the year ended 30 June 2027 and cover the
reporting years ended 30 June 2026 and 30 June 2027 unless `export_manifest.csv` says otherwise. They are
the bank's own records and are held under the retention rule at paragraph 9.1 of the programme handbook.
Nothing here may leave the financial crime team without the reporting officer's approval.

| extract | source system | pulled |
|---|---|---|
| counter deposit feed | teller platform, nightly ledger extract | 2027-07-19 |
| machine deposit feed | smart deposit machine estate, vendor delivery | 2027-07-19 |
| customer register and crosswalk | customer master | 2027-07-19 |
| branch register, machine register | branch operations and property | 2027-07-19 |
| till balance log, tolerance register | branch operations desk | 2027-07-19 |
| rating history, scale map | financial crime rating register | 2027-07-19 |
| machine service log | estate management system | 2027-07-19 |
| prescribed transaction extracts | reporting engine, preliminary and revised runs | 2027-07-19 |
| branch cash summary | operations desk reconciliation pack | 2027-07-19 |
| card settlement summary | merchant acquiring | 2027-07-19 |

The teller feed carries 61568 rows and the machine feed 37275. The two are joined on
`acct_customer_no` through `customer_number_crosswalk.csv`; neither feed carries a segment, which sits on
the customer register. Field definitions are in `field_dictionary.csv`.

Extracts are pulled once, after the year closes, and are not re-pulled for the report. The operations
desk builds its branch summary from its own end of day totals rather than from the ledger extract, so a
few months in that file do not tie to the feed to the cent; the desk does not chase differences under
twenty dollars.
