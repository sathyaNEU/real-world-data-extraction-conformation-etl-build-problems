# Extract notes, internal audit

These files were pulled for the internal audit of the capital programme payments population for the year
to 31 December 2026. The payment ledger was extracted on 2027-01-14 and the testing was completed on
2027-02-26. They are the authority's own records and are held under the retention rule in part 12 of the
internal audit manual.

| extract | source system | pulled |
|---|---|---|
| capital payment lines, both years | payment ledger | 2027-01-14 |
| testing schedule and its two-year extract | internal audit working papers | 2027-02-26 |
| capital programme register | capital programme board papers | 2027-01-14 |
| supplier master and crosswalk | procurement and finance systems | 2027-01-14 |
| payment run log and cut-off register | finance operations | 2027-01-14 |
| supplier risk approval history and category map | procurement | 2027-01-14 |
| grant claim and revenue expenditure summary | finance | 2027-01-14 |

The payment ledger carries 26,650 lines for the reporting year. It is joined to the supplier master on
`supplier_no_ledger` through `supplier_number_crosswalk.csv`; the programme sits on every payment line.
Field definitions are in `field_dictionary.csv`.

The capital programme register states approved budgets in thousands of euro, which is how the board
approves them; every other file states euro and cents. Extracts are pulled once, after the year closes,
and are not re-pulled.
