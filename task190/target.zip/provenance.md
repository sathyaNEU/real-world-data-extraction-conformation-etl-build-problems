# Extract notes, financial crime data team

These files were pulled on 2027-07-19 for the annual report for the year ended 30 June 2027 and cover the
reporting years ended 30 June 2026 and 30 June 2027 unless `export_manifest.csv` says otherwise. They are
the bank's own records and are held under the retention rule at paragraph 9.1 of the programme handbook.
Nothing here may leave the financial crime team without the reporting officer's approval.

The teller feed carries 56325 rows and the machine feed 38968. The two are joined on
`acct_customer_no` through `customer_number_crosswalk.csv`; neither feed carries a segment, which sits on
the customer register.

Known limits of this cut:

- The machine estate re-sent 27 rows during the year. A re-sent row carries `pull_sequence` 2 and
  repeats the reference of the row already delivered.
- 330 counter deposits have a posted date one day later than the deposit date, which is the
  overnight ledger run being missed.
- The branch at Hastings Heretaunga (AR11) closed on 27 November 2026 and its deposits are taken up at
  AR12 from that date. AR12 was renamed on the same day.
- Segment codes were reissued on 2027-04-06. The register carries the current code and the one in force
  to 5 April 2027.
- The prescribed transaction extract was re-run on 18 May 2027 after a reporting engine upgrade. The two
  extracts overlap from 6 April to 16 May 2027; the revised run supersedes the preliminary one.
- The machine estate stamps in Coordinated Universal Time and the teller system in branch local time.
