# Capture MIS extract notes

Folder prepared by MIS for the November 2026 second-pass planning cycle. Exports were taken on 26 and 27 October 2026.
Times in the capture platform, the QA tool and the second-pass workflow are IST (UTC+05:30) with no zone marker.

## first_pass_verifications_2026q3.parquet

Capture platform, first-pass verification log, shift-days 1 July to 30 September 2026. One row per screen: a document
opened on a verifier's screen. 1,259,599 rows.

| Column | Meaning |
|---|---|
| screen_id | platform screen reference |
| document_id | capture number of the document |
| stream_code | stream (see stream_register.csv) |
| form_version | form version the document was captured on |
| badge_no | badge of the verifier on the screen |
| opened_at, closed_at | screen opened and closed, IST |
| outcome | SUBMITTED, or TIMED_OUT when the screen sat idle for 15 minutes and the platform closed it |
| key_fields | key fields on the document |
| fields_keyed_over | key fields the verifier changed on the screen |

A timed-out screen submits nothing and the document goes back to the queue; the later submitted screen is the
verification of record. Badges are reused after a verifier leaves: resolve a badge to an employee through the badge
allocation sheet of workforce_register.xlsx for the date of the screen.

## first_pass_field_edits_2026q3.parquet

One row per key field a verifier keyed over on a submitted screen. 466,253 rows.

## blind_rekey_audit_2026q3.parquet

QA tool, blind re-key audit of first-pass output, shift-days 1 July to 30 September 2026, closed with every audited
document adjudicated. One row per key field of an audited document. 2,381,352 rows.

| result_code | Meaning |
|---|---|
| M | OCR value matched the image and the value after first pass matched it |
| C | OCR value differed from the image and first pass corrected it |
| R | OCR value differed from the image and the value after first pass still differs |
| V | OCR value matched the image and first pass changed it to a value that differs |

rekey_rounds is 2 when the two blind keyers agreed and 3 when a third keyer adjudicated.

## second_pass_sessions_2026_09.csv

Second-pass workflow, September 2026 (work dates 1 to 30 September), including the Hollings & Pryce pilot's second pass.
One row per document opened in a second-pass session. 127,563 rows.

| Column | Meaning |
|---|---|
| session_ref | workflow session |
| work_date | shift-day the session worked |
| sp_badge | second-pass verifier |
| basket | second-pass work basket |
| document_id | capture number of the document |
| doc_opened | document opened, IST |
| handling_sec | seconds the document was open on the workflow timer |

## Other files

- workforce_register.xlsx: employees, badge allocation with validity dates, and the Q3 queue rota (HRMS export).
- stream_register.csv: streams, form families, queues with effective dates, and the audit sample share.
- november_operating_plan.xlsx: the plan of record for November (routing, daily key fields by stream, roster), with the
  October second-pass list and budget exchange rates.
- form_specifications.xlsx: form versions with effective shift-days, key fields per document and the key field list.
- delivery_manifests_2026q3.csv: delivery transmissions to clients from 25 June to 3 October 2026, from the SFTP gateway log, one row
  per file. transmitted_at carries its offset.
- delivery_index_2026q3.parquet: the gateway's index of the same files, one row per document delivered: the file, the client's claim
  reference, the capture number (document_id) and the sheet.
- QCP-04_first_pass_quality_control.docx: the controlled procedure for first-pass quality control and second-pass designation.
- client_quality_schedules_2026.pdf: extract of the client contracts (limits, credits, client audit measurement).
- hollings_pryce_pilot_report.docx and second_pass_labour_planning_note.docx: Quality's pilot report and the MIS labour planning note.
- Client forecasts (kessington_volume_forecast_nov26.csv, us_client_forecasts_nov26.xlsx, wattlebird_coolabah_forecasts_fy27.xlsx, uk_client_forecasts_nov26.csv, hollings_pryce_forecast_nov26.json) and client audit returns
  (kessington_audit_findings_q3.csv, client_audits_us_q3.xlsx, client_audits_au_q3.xlsx, client_portal_audits_uk_q3.json) are filed as the clients sent them (Client Services inbox).
- ocr_confidence_summary_2026q3.csv: OCR engine's confidence summary by stream, field and month.
- verifier_keystroke_telemetry_2026q3.parquet: verifier keystroke telemetry by badge and login date, from the desktop agent.

## Provenance

All exports are internal records of Tamralipta Data Services or files its clients sent under contract, extracted for
operational planning. Client names and identifiers are as held in our systems; no claimant data is included.
