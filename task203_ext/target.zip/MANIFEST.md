# Benchmark and evaluation corpus, 2025 to 2026

Compiled by the Benchmark & Evaluation Group, Institute for Applied Computation on 19 October 2026 for internal reuse. Free to reuse within the group.
The experiment tracker export is the system of record for anything that has to tie.

## Files

| file | format | rows | what it holds |
|---|---|---|---|
| `runs_2026.jsonl` | JSON Lines | 26,780 | the tracker's 2026 feed, one object per run, metrics nested |
| `runs_2025_export.csv` | CSV | 8,644 | the old exporter's 2025 feed, older column layout, metrics flattened |
| `scheduler.log` | text | 27,000 | submit, start and end lines from the job scheduler |
| `annotation_disagreement_sample.jsonl` | JSON Lines | 1,400 | a double-annotated item sample, partly adjudicated |
| `sweeps/*.toml` | TOML | 4 files | the sweep definitions behind the 2026 runs |
| `metrics_dictionary.csv` | CSV | 8 | definitions for the metric keys that have been documented |
| `dataset_registry.csv` | CSV | 10 | datasets, the version strings in use, split sizes and licences |
| `hardware_inventory.csv` | CSV | 10 | hosts, accelerators and in-service dates |
| `eval_tracker_handkept.xlsx` | XLSX | 2 sheets | one person's hand-kept summary, behind the tracker |
| `ops_notes.md` | Markdown | - | the platform rota's running notes |

## What to expect before you join any of it up

Nothing here has been conformed. These are the things that have caught people out, listed so they
do not have to be rediscovered.

1. **Two layouts for the same thing.** The 2026 feed nests metrics under `metrics` and names its
   columns in full. The 2025 export flattens them into `metric_a`, `metric_b` and `loss` and
   abbreviates the column names. The two feeds do not share a schema.
2. **The 2025 export cannot carry generation or ranking metrics at all**, because three fixed
   metric columns do not fit them. Those runs are present with blank metric cells.
3. **Two clocks.** The tracker writes UTC with a trailing `Z`. The old export and the scheduler log
   write local wall-clock time with no zone marker, two hours ahead of UTC in winter.
4. **A run carries only the metrics its task type reports**, so `accuracy` is absent from
   generation runs and `rouge_l` from tabular runs. That is how the tracker stores them.
5. **Host names reach us in three spellings**: lower case from the tracker, upper case from some
   scheduler partitions, fully qualified from the inventory sync. The inventory holds the canonical
   form and they are the same machines.
6. **Dataset version strings are inconsistent**, because submitters type them: `v1.2`, `1.3.0` and
   a date-and-revision form all occur. The registry lists which strings are in use per dataset.
7. **Some runs have no metrics.** About three in a hundred ended `crashed`, `oom` or `killed`, and
   a few were still `running` at export, so the metrics object is empty and `gpu_hours` is null.
8. **Some runs appear twice.** The Q2 re-export after the tracker upgrade emitted part of the
   quarter a second time. The payloads are identical and `run_id` is the join key.
9. **The hand-kept workbook does not tie.** It stops in early November 2026, counts only runs that
   report `accuracy`, and is not the system of record.
10. **The annotation sample is only partly adjudicated**, and a few items are missing the second
    annotator's label.
11. **The CPU nodes have no accelerator**, so `gpu_hours` is zero for runs that landed there.
