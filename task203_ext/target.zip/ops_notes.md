# Evaluation platform notes

Kept by whoever is on rota. Newest first.

## 2026-10-02
Tracker schema change landed in January is now the only export path. The 2025 CSV export in this
folder is the last one the old exporter produced and its column names do not match the 2026 feed.

## 2026-09-18
gpu-node-07 and gpu-node-08 came into service in January. Timings from before that date are not
comparable with timings after it on the same partition.

## 2026-08-05
Re-ran the Q2 export after a tracker upgrade. Some runs appear twice across the two export files;
the payloads are identical and the run_id is the join key.

## 2026-06-11
Reminder that the hand-kept workbook is not the system of record and is behind. Use the tracker
export for anything that has to tie.

## 2026-04-27
Host names reach us three ways depending on which system wrote the row: lower case from the
tracker, upper case from the scheduler on some partitions, and fully qualified from the inventory
sync. They are the same machines.

## 2026-02-14
Dataset versions are written inconsistently by submitters (v1.2, 1.2.0, and a date-and-revision
form for the generation sets). The registry lists which strings are in use for each dataset.

## 2025-12-03
The old exporter flattens metrics into metric_a, metric_b and loss, which only fits the
classification and tabular runs. Generation and ranking metrics are not in the 2025 CSV at all.

## 2025-10-20
Scheduler writes wall-clock local time. The tracker writes UTC. Both are in this folder.
