# Data dictionary

## elfs_2026q4_persons.csv, elfs_2027q1_persons.csv, elfs_2027q2_persons.csv, elfs_2027q3_persons.csv, elfs_2027q4_persons.csv
The survey's quarterly person files, one per quarter: one row per person aged 15 and over interviewed. quarter;
district and ea (the survey district and enumeration area codes in force on the interview date); dwelling (the sampled
dwelling's number); hh (the household's number in the dwelling); line (the person's line in the household); visit (the
dwelling's visit, 1 to 4); int_date (the person's interview date, yyyy-mm-dd); interviewer; resp_line (the line of the
person who answered); sex (1 male, 2 female); birth_month; birth_year; age (completed years); relation (to the
household head: 1 head, 2 spouse, 3 child, 4 other relative); q_work, q_absent, q_look, q_avail, q_future (the
questionnaire items in the methodology note's annex; blank where not asked); lfs_status (1 employed, 2 unemployed, 3
outside the labour force); wt (the cross-sectional weight).

## elfs_reinterview_results_2026q4_2027q4.csv
The supervisors' reinterview results: one row per person reinterviewed within the window. reint_id; quarter (of the
original interview); district and ea (codes in force on the original interview date); dwelling; hh; line; supervisor;
orig_status (the status the original interview recorded: 1 employed, 2 unemployed, 3 outside the labour force);
reint_status (the supervisor's own reading before review, same codes); reconciled (the status agreed with the
respondent after review, same codes); outcome (same: no difference to review; reconciled: a difference reviewed).

## elfs_reinterview_fieldwork_log_2026q4_2027q4.csv
The supervisors' fieldwork log: one row per call on a selected household. log_row; supervisor; quarter (of the
original interview); district and ea (codes in force on the original interview date); dwelling; hh; attempt (the call
number); attempt_date (the call's date as the tablet recorded it, yyyy-mm-dd); visit_start (the tablet clock time at
which the household's reinterview form was opened, yyyy-mm-dd hh:mm); result (no contact, refused, completed).

## elfs_2027_annual_flows_tables.xlsx
The 2027 annual flows tables as tabulated: sheet F1 flows (Table F1, persons in each pair of statuses in two
consecutive quarters, by district) and sheet F2 rates (Table F2, job-finding and job-loss rates).

## elfs_district_gazetteer_2027.csv
The survey districts' enumeration areas as they stand from 1 April 2027: district; district_name; ea; and, for the
areas renumbered on that date, district_before, ea_before and effective.

## esbs_population_projections_2026_2028.csv
The bureau's projections of the population aged 15 and over: district, year, sex (1 male, 2 female), age_group,
persons.

## esinmi_job_centre_registers_2027.xlsx
The Ministry of Labour and Productivity's job centre registers, 2027: registered job seekers at the end of each month
by district.

## elfs_labour_market_bulletin_2027q3.pdf
The bureau's labour market bulletin for the third quarter of 2027.
