# ELFS 2027 annual flows

The Labour and Social Statistics Division's folder for the 2027 annual labour market flows release.

- elfs_2027_flows_release_request.eml: the Director's request for the release's quality note.
- elfs_methodology_note_2027.pdf: the survey's methodology note, 2027 edition.
- elfs_reinterview_protocol_v3.pdf: the supervisors' reinterview protocol, version 3.
- elfs_2026q4_persons.csv: the survey's person file for 2026Q4.
- elfs_2027q1_persons.csv: the survey's person file for 2027Q1.
- elfs_2027q2_persons.csv: the survey's person file for 2027Q2.
- elfs_2027q3_persons.csv: the survey's person file for 2027Q3.
- elfs_2027q4_persons.csv: the survey's person file for 2027Q4.
- elfs_reinterview_results_2026q4_2027q4.csv: the reinterview results.
- elfs_reinterview_fieldwork_log_2026q4_2027q4.csv: the reinterview fieldwork log.
- elfs_2027_annual_flows_tables.xlsx: the 2027 annual flows tables as tabulated.
- elfs_district_gazetteer_2027.csv: the district gazetteer.
- esbs_population_projections_2026_2028.csv: population projections, 2026 to 2028.
- esinmi_job_centre_registers_2027.xlsx: the Ministry of Labour and Productivity's job centre registers, 2027.
- elfs_labour_market_bulletin_2027q3.pdf: the labour market bulletin for the third quarter of 2027.
- DATA_DICTIONARY.md: the fields of each file.
