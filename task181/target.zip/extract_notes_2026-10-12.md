# Extract for the summer 2027 sector plan

Pulled 12 Oct 2026 by Paw Frandsen (Data and Analytics) for the Safety Office and Network and Capacity Planning. Holmvik ACC
upper sectors only. Actuals run 1 Jan 2025 to 30 Sep 2026 unless a file says otherwise.

Files
- fdps_sector_traversals_2025-01_2026-09.parquet: FDPS archive, one row per flight per sector entered, with entry and exit time and entry and exit flight
  level. ifplid is the network manager's flight plan id. Sector codes as in the sector register.
- occurrence_export_2025-01_2026-09.csv: safety database export, occurrences in the Holmvik ACC sectors dated 1 Jan 2025 to 30 Sep 2026, one row per
  occurrence number. Levels in feet as reported or measured. Sector by name.
- occurrence_scheme_codes.csv: the AAN-OCC-01 code lists.
- planning_traffic_summer2027_issue1.csv: planning traffic for summer 2027, issue 1 of 9 Oct 2026 from Network and Capacity Planning (Erik Sørensen).
  Built from the operators' summer 2027 schedules as filed and the forecast growth. One row per planned flight per
  traffic volume, keyed by their own flight key.
- sector_register.json: sectors, traffic volumes and limits.
- nm_slot_allocations_2026-05_2026-09.csv: network manager slot allocation list for the regulations on the Holmvik traffic volumes and on Holmvik
  arrivals, EOBT 1 May to 30 Sep 2026. One row per flight plan per regulation that allocated it a slot; slot_delay_min
  is the delay that regulation's slot gave the plan. ATFM delay is the network manager's: it is counted for the
  flights that operated, as the time between the take-off time the operator last requested and the take-off slot the
  network manager allocated; a flight captured by more than one regulation takes the slot of its most penalising
  regulation, and its delay is that regulation's, counted against that regulation.
- nm_regulations_2026-05_2026-09.csv: the regulations for the same period. Regulation ids are reused from month to month; reg_date tells them
  apart.
- sector_configuration_log_2026-05_2026-09.csv: supervisors' configuration log, 30 Apr to 30 Sep 2026.
- sector_configurations_current.csv: configuration table as exported from the ops system on 9 Oct 2026.
- HACC_OM_part3_ch4_sector_configuration.pdf, HACC_unit_safety_plan_2026-2028.pdf, HACC_summer2026_safety_closeout.pdf: from the document library and the Safety Office.
- controller_roster_summer2026.xlsx, met_cb_activity_summer2026.csv: rostering system and the met office's convective summaries, as asked.

Clocks
- FDPS, occurrences, the NM files and the planning traffic are in UTC. The configuration log is in local time (CET,
  CEST in summer).
