# Water Services data dictionary: online ammonia monitoring and laboratory results

Kept by Water Quality Compliance. Revised 3 November 2027.

## nh3_online_readings (historian export)

| Column | Meaning |
|---|---|
| site_code | Plant code (ASH Ashcombe, BRN Brannock, CAL Calderwood, DUN Dunmere, ELS Elstow, FEN Fenwick, GAR Garrick, HOL Holmedale) |
| analyser_tag | The plant's ammonia analyser, as in the online analyser register |
| reading_end_utc | End of the ten-minute port slot the reading belongs to, UTC |
| sample_point | Control system sample point code (register, Sample points sheet); `<plant>-CHK` is the analyser's check port |
| nh3_n_mgl | Ammoniacal nitrogen, mg/L as N, three decimals; blank when there is no reading |
| qc | G good; F no reading for the slot; V verification check reading through the check port |

A failed poll that the historian later fills from the plant's outstation keeps its F row, and the reading it was
filled with follows under the same time with qc G. A slot with no row at all is one the historian's own server
failed to store; the plants ran normally.

## lims_ammonia (laboratory export)

| Column | Meaning |
|---|---|
| sample_no | Laboratory sample number |
| lims_point | Laboratory sample point code (register, Sample points sheet) |
| location | Sample point as the laboratory describes it |
| collected | Date and time the sampler took the sample, New Zealand time, as written on the bottle |
| received | Date and time the laboratory's reception logged the sample, New Zealand time |
| analysed | Date and time of the ammonia analysis, from the laboratory's analyser run record |
| released | Date and time the laboratory released the result to Water Services, New Zealand time |
| determinand | Ammoniacal-N |
| result | mg/L as N; `<0.030` is below the limit of detection |
| units, lod | Units and limit of detection |
