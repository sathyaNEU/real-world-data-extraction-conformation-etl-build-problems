Trelvane Mobility Data: TMC travel-time export
Customer: Beargrass Medical Center, Transportation Planning (order 2026-0418)
Delivered 5 October 2026

CONTENTS

  One CSV per calendar month, October 2025 to September 2026:
  trelvane_tmc_export_2025-10.csv to trelvane_tmc_export_2026-09.csv
  TMC_Identification.csv, the segments in each network release used in the export

  Coverage: I-65 between Exit 121 and Exit 136 and the I-264 interchange, both directions, KY-480 at
  Exit 121; every day; epochs from 05:30 to 09:25.

FIELDS

  tmc_code              segment code
  measurement_tstamp    start of the five-minute epoch, local time (Eastern)
  speed_all             average speed, all vehicles, mph
  travel_time_all       average travel time over the segment, all vehicles, seconds
  speed_passenger       average speed, passenger vehicles, mph
  travel_time_passenger average travel time over the segment, passenger vehicles, seconds
  speed_freight         average speed, freight trucks, mph
  travel_time_freight   average travel time over the segment, freight trucks, seconds
  reference_speed       the segment's reference speed (85th percentile off-peak), mph
  data_density          A: 5 or more probe vehicles in the epoch; B: 2 to 4; C: fewer than 2, the
                        value filled from the segment's history for that epoch

  Travel times are averages over the class's probe vehicles in the epoch. Speeds are length over
  travel time. An epoch with no probe vehicles and no usable history for the segment is left out
  of the export.

NETWORK RELEASES

  TMC_Identification.csv lists every segment of each network release used in the export, with its
  length in miles. The release in force on a date is the latest whose effective date is on or
  before it; release 2025.2 was in force to 31 March 2026 and release 2026.1 from 1 April 2026.

LICENCE

  For the customer's internal planning use. Not for redistribution.
