# Traffic Data Program: data dictionary

Regional Municipality of Halbrook, Transportation Services, Traffic Data Program. Updated 6 January 2028.

## trafficvault_hourly_counts_2027.csv

Hourly export from TrafficVault for 1 January to 31 December 2027, one row per station, direction and hour. Comma separated.

| field | content |
|---|---|
| station | station number in force for the hour (see the register's code history) |
| direction | NB, SB, EB or WB |
| local_start | start of the hour, local time |
| utc_offset | the hour's offset from UTC (-05:00 standard time, -04:00 daylight time) |
| vehicles | vehicles counted in the hour, all lanes of the direction |
| occupancy | per cent of the hour the loops were occupied, averaged over the lanes (two decimals from the TCX-4 controllers, one from the TCX-2) |

A TCX-2 controller has no standby supply: when its supply is interrupted it stops, discards the hour it is in and reports no event of its own, so an interruption at a TCX-2 station shows only as hours absent from the export. A TCX-4 carries a battery and counts on it.

## Northline_validation_counts_2027.xlsx

The validation contractor's 2027 workbook, sheet Counts: one row per site, direction and 15-minute interval of the filmed day.

| field | content |
|---|---|
| site | the contractor's site code (the register's validation_site) |
| date | the filmed day |
| direction | NB, SB, EB or WB |
| start | start of the 15-minute interval, local time |
| video | vehicles counted on the video |
| loops | vehicles the station's loops counted in the interval |

## count_station_register.xlsx

Sheet Stations: station number, Regional Road, kilometre point, location, district, lanes each way, controller model, year in service, validation site code. Sheet Code history: stations renumbered when their controller was replaced, with the date the new number took effect.

## regional_road_network_2027.xlsx

Sheet Junctions: each junction on the Regional Roads with a count station, by road and kilometre point, the crossing road and the junction's control. Sheet Structures: bridges and culverts by road and kilometre points.

## trafficvault_station_events_2027.csv

TrafficVault's station event log for 2027: the events the stations' controllers reported and the events TrafficVault raised itself, one row per event, station by station in the order TrafficVault received them. TrafficVault polls every station every 15 minutes. Comma separated.

| field | content |
|---|---|
| station | station number in force when the event was received |
| logged_utc | time the event was logged, UTC, by the clock of whatever raised it |
| raised_by | controller or TrafficVault |
| event | MAINS_FAIL, MAINS_OK: mains power lost, restored at the controller; DOOR_OPEN, DOOR_CLOSE: the cabinet door switch, logged on every opening and closing of the cabinet; RESET: controller reset; COLD_START: controller started without a set clock; COMMS_LOST, COMMS_OK: a poll of the station failed, a poll succeeded again; CLOCK_SET: TrafficVault set the controller's clock |

## Carrick_work_orders_2027.xlsx

Carrick Signal & Systems Ltd.'s work orders at the count stations in 2027. Sheet Orders: one row per work order, with the dates it was opened and closed, its category, the stations it covers (station numbers in force when it was opened), the fault or job as reported and the resolution. Sheet Labour: one row per technician and day booked to an order, with the hours.
