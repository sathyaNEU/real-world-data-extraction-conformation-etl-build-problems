# Exports for the 2027 operator workstation review: Human Resources and occupational health

Pulled for Fleet Engineering on 1 October 2026 (Tracy Reynolds, Vehicle Procurement Manager, Fleet Engineering). Human Resources and the occupational health
providers' exports are confidential: keep them on the Fleet Engineering share. Questions on the occupational health
exports to Kelsey Sanchez, Occupational Health Coordinator.

## hr_roster_transportation_maintenance_2026-09-30.xlsx

Human Resources' roster of the employees in the Transportation and Maintenance job classes on 30 September 2026,
one row per employee. Emp No is the employee number. Job Class is the employee's classification; FT/PT whether the
position is full-time or part-time. Division is the employee's home division. Duty Status is ACTIVE, LEAVE, LIGHT
DUTY or MILITARY LEAVE.

## ostrander_encounters_tvrta_2014-01_2021-06.csv

Ostrander Occupational Health's export of every encounter it recorded for the Authority's employees in DOT-regulated jobs from 1 January 2014
until its contract ended on 30 June 2021: DOT physical examinations, recertifications after a short certificate, and
the FTA drug and alcohol tests it collected. EMP# is the Authority's employee number. DOS is the date of service,
month/day/year. HEIGHT (feet and inches, without shoes) and WEIGHT LB (light clothing) are measured at each DOT
physical. CERT is the medical certificate issued and CERT EXPIRES its expiry.

## fernhill_visits_tvrta_2021-01_2026-09.csv

Fernhill Occupational Medicine's export of every visit it holds for the Authority's employees in DOT-regulated jobs to 30 September 2026. Fernhill
took over the contract on 1 July 2021 and loaded Ostrander's records from 1 January 2021 into its system at the
changeover; legacy_ref carries the Ostrander encounter number of those records. employer_ref is TVT- and the
Authority's employee number. visit_type: DOTPE DOT physical examination, DOTRC recertification, UDS-RAND random drug
test, UDS-PREEMP pre-employment drug test, UDS-POSTACC post-accident drug test, BAT-RAND random breath alcohol test.
ht_in (without shoes) and wt_lb (light clothing) are measured at each DOT physical. cert_months is the certificate
issued and cert_expires its expiry.
