# Exports for the 2027 operator workstation review: Fleet Maintenance

Pulled for Fleet Engineering on 1 October 2026 (Tracy Reynolds, Vehicle Procurement Manager, Fleet Engineering) from the fleet maintenance system.

## fleet_roster_2026-09-30.csv

Fleet Maintenance's roster of the buses in the fleet on 30 September 2026. accepted is the date the Authority accepted
the bus. operator_area_options lists the workstation options the bus carries: PDL power-adjustable pedal set, RSR
extended-range seat riser, TEL tilt-telescope steering column, TRK deep-travel seat track, HDR raised header and visor.

## bus_disposals_2019-2026.csv

The buses disposed of since 1 January 2019, with the options each carried when it left the fleet.

## retrofit_campaigns_2019-2026.csv

Fleet campaigns completed since 1 January 2019: one row per bus, the date the work was completed.

## operator_area_work_orders_2019-01_2026-09.csv

Fleet Maintenance's operator-area work orders opened from 1 January 2019 and closed by 30 September 2026, one row per
part line. component is the operator-area component worked on; the five option components are PDL-ADJ, SEAT-RSR,
STR-TEL, SEAT-TRK and HDR-VIS. bill_to is TVRTA (the Authority's operating budget), HALVARD WARRANTY or a capital
project. part_cost is qty times unit_cost. labor_hours and labor_cost are technician hours and their cost at the year's
shop rate.

## Fleet maintenance measures

Fleet Maintenance states maintenance cost per bus-year. Maintenance cost is the parts and labor on the work orders
billed to TVRTA, counted in the month the work order closed. A bus counts one bus-month for each month in which it is
in the fleet on the first day of the month, from its acceptance until it leaves the fleet; an option's bus-months are
the months in which the bus carries the option on the first day. Bus-years are bus-months divided by twelve.

## operator_comfort_survey_2023.xlsx

Kept beside the review: the May 2023 operator comfort survey (anonymous responses).

## workers_comp_claims_transportation_2019-2026.csv

Kept beside the review: Risk Management's workers' compensation claims of operators, road supervisors and transportation
instructors since 1 January 2019.
