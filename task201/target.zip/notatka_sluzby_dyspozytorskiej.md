# Notatka ze zmiany dyspozytorskiej, wichura 11-13 listopada

Dyspozytor zmianowy: Cezary Wawszczyk, Centralna Dyspozycja Mocy BEO
Data notatki: 14 listopada 2026

Zmiana od 11 listopada 09:00 do 13 listopada 22:00. W tym czasie system odnotowal 4245 wylaczen
awaryjnych. Szczyt przyjec w Centrum Zgloszen wypadl 12 listopada miedzy 04:00 a 07:00, kolejka
IVR siegala wtedy osmiu minut, czesc klientow rozlaczala sie przed nagraniem.

Brygady. Z czterech oddzialow wyjechalo 31 brygad wlasnych i 9 z umowy pomocy wzajemnej. Dojazdy
w Grabowniku byly najdluzsze, drogi lesne w Borowej Puszczy byly nieprzejezdne do poludnia
12 listopada, dwie brygady czekaly na przejazd lesny. W Zanowcu pracowano glownie na kablach,
wiekszosc odbiorcow wrocila przelaczeniami z GPZ bez wyjazdu w teren.

Material. Zuzyto 614 bezpiecznikow mocy SN, zapas w Mokrzycach skonczyl sie 12 listopada po
poludniu, uzupelniono z magazynu w Nierzycy. Slupy: 23 zlamane, 11 pochylonych, wszystkie
zgloszone do Zarzadzania Majatkiem.

Uwagi do zamykania zdarzen. Brygady zamykaly zlecenia w terminalu po zalaczeniu, w kilkunastu
przypadkach wpis przyszedl z opoznieniem i zostal poprawiony przez dyspozytora na podstawie
raportu brygady. Trzy zdarzenia zostaly na 16 listopada otwarte, czekaja na odbudowe odcinka,
sa opisane w dziennym raporcie ruchu.

Do naprawy w module raportowym: eksport z 1 do 7 listopada wyszedl w obu ukladach kolumn,
stary i nowy modul nakladaja sie na tym tygodniu. Zglosilem do Biura Teleinformatyki.
