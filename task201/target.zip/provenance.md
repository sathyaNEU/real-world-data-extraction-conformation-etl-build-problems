# Pochodzenie danych i licencje

Pakiet zlozony 16 listopada 2026 o 06:00 przez Biuro Analiz Sieciowych BEO na potrzeby narady
ruchowej oddzialu. Wszystkie pliki sa wyciagami z systemow operatora albo dokumentami operatora.
Numery PPE i identyfikatory urzadzen podano w postaci technicznej; wyciag nie zawiera danych
osobowych odbiorcow, zgodnie z procedura udostepniania danych wewnetrznych.

| Plik | Co zawiera | Czego nie zawiera | Zrodlo | Stan na | Licencja |
|---|---|---|---|---|---|
| awarie_oms_2026-10-01_2026-11-07.csv | 1974 wylaczen, uklad kolumn do 2026-10-31 | wylaczen po 7 listopada | SD-OMS, modul raportowy 3.4 | 2026-11-16 06:00 | wewnetrzna, operator |
| awarie_oms_2026-11-01_2026-11-15.csv | 5449 wylaczen, uklad kolumn od 2026-11-01 | wylaczen przed 1 listopada | SD-OMS, modul raportowy 4.0 | 2026-11-16 06:00 | wewnetrzna, operator |
| zgloszenia_klientow_2026.csv | 55270 zgloszen o braku zasilania | zgloszen jakosciowych | Centrum Zgloszen, eksport CRM | 2026-11-16 06:00 | wewnetrzna, operator |
| telemetria_operacje_lacznikow_utc.csv | 1505 operacji lacznikow, UTC | operacji na liniach bez telemetrii linii | SCADA historian | 2026-11-16 06:00 | wewnetrzna, operator |
| rejestr_urzadzen_sn_nn.xlsx | 13860 urzadzen i liczba odbiorcow za kazdym | odbiorcow indywidualnie | model polaczeniowy GIS | 2026-10-01 | wewnetrzna, operator |
| program_telemetrii_linii.xlsx | 338 linii objetych programem | linii poza programem | Biuro Inwestycji | 2026-11-01 | wewnetrzna, operator |
| harmonogram_wylaczen_planowanych.xlsx | 440 prac planowanych w oknie, po wydaniach | prac odwolanych przed publikacja | Biuro Ruchu Sieci | 2026-11-16 | wewnetrzna, operator |
| odbiorcy_ppe.csv | 9910 punktow poboru z przypisanym urzadzeniem | odbiorcow bez umowy dystrybucyjnej | rejestr PPE | 2026-11-16 | wewnetrzna, operator |
| procedura_PR-07_plan_remediacji.pdf | zasady przypisania slotu remediacyjnego | sprawozdawczosci rocznej | Biuro Ruchu Sieci | 2026-09-01 | wewnetrzna, operator |
| sprawozdanie_niezawodnosc_2024_2025.pdf | wskazniki koncesji za 2024 i 2025 | podzialu na oddzialy i rejony | sprawozdanie zlozone organowi | 2026-03-31 | wewnetrzna, operator |
| sprawozdanie_URE_2026_wstepne_i_korekta.xlsx | dane miesieczne koncesji 2026 | podzialu na oddzialy | sprawozdawczosc biezaca | 2026-11-14 | wewnetrzna, operator |
| rejestr_zgloszen_jakosci_energii.csv | 2600 zgloszen jakosciowych | brakow zasilania | Centrum Zgloszen | 2026-11-16 06:00 | wewnetrzna, operator |
| wycinka_i_przeglady_linii_2026.csv | 2640 zlecen wycinki i przegladow | prac w toku | Zarzadzanie Majatkiem | 2026-11-16 | wewnetrzna, operator |
| notatka_sluzby_dyspozytorskiej.md | notatka ze zmiany po orkanie Halina | zestawien liczbowych sieci | Centralna Dyspozycja Mocy | 2026-11-14 | wewnetrzna, operator |
| slownik_danych.md | opis kolumn kazdego pliku | wartosci danych | Biuro Analiz Sieciowych | 2026-11-16 | wewnetrzna, operator |

Uwagi o kompletnosci. Archiwum telemetrii obejmuje tylko urzadzenia transmitujace do SCADA, to
jest wylaczniki w GPZ oraz urzadzenia liniowe na liniach objetych programem telemetrii linii.
Rejestr PPE jest wyciagiem i nie obejmuje punktow bez czynnej umowy dystrybucyjnej. Sprawozdania
do organu sporzadzane sa dla calej koncesji i nie zawieraja podzialu na oddzialy.
