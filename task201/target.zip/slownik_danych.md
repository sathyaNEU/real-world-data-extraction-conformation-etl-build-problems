# Slownik danych, pakiet sezonowy 2026/2027

Wydanie 4, 16 listopada 2026. Wlasciciel: Biuro Analiz Sieciowych BEO.
Czas lokalny Europe/Warsaw, chyba ze kolumna wskazuje inaczej.
Slownik obejmuje pliki danych pakietu. Procedur, sprawozdan i notatek sluzbowych slownik nie
opisuje.

## awarie_oms_2026-10-01_2026-11-07.csv, awarie_oms_2026-11-01_2026-11-15.csv

Eksport wylaczen z systemu dyspozytorskiego SD-OMS, jeden wiersz na wylaczenie. Pierwszy plik
w ukladzie kolumn obowiazujacym do 31 pazdziernika 2026, drugi w ukladzie po aktualizacji modulu
raportowego. Okresy obu plikow nakladaja sie na tygodniu od 1 do 7 listopada.

| Kolumna (stary uklad) | Kolumna (nowy uklad) | Zawartosc |
|---|---|---|
| zdarzenie_id | id_zdarzenia | Identyfikator wylaczenia, unikalny w skali operatora. |
| oddzial | oddzial | Kod oddzialu eksploatacji. |
| rejon | rejon | Nazwa rejonu energetycznego. |
| linia_sn | id_linii | Identyfikator linii SN, z ktorej wyszlo wylaczenie. |
| urzadzenie | id_urzadzenia | Identyfikator urzadzenia, ktore zadzialalo. Wiersze dla urzadzen przyjetych do eksploatacji przed aktualizacja z 2024 roku nosza postac bez zer wiodacych w numerze rejonu, linii i urzadzenia. |
| rodzaj | rodzaj_wylaczenia | awaryjne albo planowane. |
| ts_poczatek | poczatek_lokalny | Poczatek przerwy w zapisie dyspozytorskim. Dla linii objetej telemetria linii przyjmowany jest znacznik operacji urzadzenia liniowego z archiwum telemetrii; dla pozostalych linii przyjmowany jest czas przyjecia pierwszego zgloszenia klienta. Dla wylaczen planowanych przyjmowany jest czas lacznika z grafiku. |
| ts_zalaczenie | zalaczenie_lokalne | Czas zalaczenia wpisany przez brygade w terminalu. Puste, gdy zasilanie nie zostalo przywrocone do pobrania danych. |
| czas_trwania_min | czas_trwania_min | Roznica miedzy dwoma kolumnami powyzej, w minutach, liczona przez SD-OMS. |
| przyczyna | przyczyna | Przyczyna wpisana przez brygade. nieustalona, gdy brygada nie ustalila przyczyny. |
| epizod | epizod_pogodowy | Nazwa epizodu pogodowego nadana przez sluzbe ruchu, puste poza epizodem. |

## zgloszenia_klientow_2026.csv

Zgloszenia o braku zasilania przyjete przez Centrum Zgloszen, jeden wiersz na zgloszenie. Jedno
wylaczenie moze miec wiele zgloszen. Kolumny: zgloszenie_id, ts_przyjecia, kanal (telefon, IVR
albo aplikacja), oddzial, rejon, id_urzadzenia, nr_ppe (punkt poboru energii klienta),
id_zdarzenia (puste, gdy dyspozytor nie powiazal zgloszenia z zadnym wylaczeniem), opis.
Kolumny oddzial, rejon i id_urzadzenia wypelnia kanal przyjecia; kanal IVR nie zapisywal ich
od 9 pazdziernika do 2 listopada 2026, po zmianie drzewa zapowiedzi. Nowe drzewo weszlo 9
pazdziernika, zapis pol przywrocono poprawka z 3 listopada.

## telemetria_operacje_lacznikow_utc.csv

Archiwum operacji lacznikow i wskaznikow zwarciowych z systemu SCADA, jeden wiersz na operacje.
Obejmuje wylaczniki w GPZ oraz urzadzenia liniowe na liniach objetych telemetria linii.
Kolumna ts_utc podana w czasie UTC. jakosc_sygnalu przyjmuje OK albo OK-opozniony, gdy sygnal
dotarl po buforowaniu w koncentratorze.

## rejestr_urzadzen_sn_nn.xlsx

Arkusz urzadzenia: jeden wiersz na urzadzenie lacznikowe lub zabezpieczeniowe.
odbiorcy_za_urzadzeniem to liczba odbiorcow, ktorzy traca zasilanie przy otwarciu tego
urzadzenia, z modelu polaczeniowego, stan na 1 pazdziernika 2026. klasa_odcinka przyjmuje
SN-magistrala, SN-odgalezienie, SN/nN-stacja albo nN-obwod. telemetria_linii jest prawda dla
urzadzen na liniach objetych programem telemetrii linii. rok_zabudowy to rok przyjecia do
eksploatacji. Arkusz podsumowanie_odbiorcy podaje liczbe odbiorcow na oddzial w tysiacach.

## program_telemetrii_linii.xlsx

Linie objete programem telemetrii linii, jeden wiersz na linie. data_odbioru to data odbioru
technicznego, data_zalaczenia_telemetrii to data zalaczenia transmisji do SCADA, status przyjmuje
w eksploatacji, w rozruchu albo w przygotowaniu.

## harmonogram_wylaczen_planowanych.xlsx

Grafik wylaczen planowanych. Jeden arkusz na wydanie grafiku; arkusz wydania podaje date zlozenia
kazdego wydania i uwagi. Kolumna odcinkow podaje liczbe odcinkow sieci objetych jedna pozycja
grafiku, zakres przepisano z polecenia na prace. okno_od i okno_do to opublikowane okno wylaczenia,
w ktorym praca ma sie zmiescic; okno_od wyznacza zglaszana gotowosc brygady i wyprzedza pierwsze
lacznikowanie o kilkanascie do kilkudziesieciu minut, roznie dla kazdej pracy.

## odbiorcy_ppe.csv

Wyciag z rejestru punktow poboru energii dla sluzb ruchowych, jeden wiersz na PPE, z urzadzeniem,
za ktorym punkt jest przylaczony, oraz taryfa.

## sprawozdanie_URE_2026_wstepne_i_korekta.xlsx

Dane sprawozdawcze dla calej koncesji, minuty i przerwy na odbiorce, w podziale na poziom napiecia
i na przerwy awaryjne oraz planowane. Bez podzialu na oddzialy. Arkusz wydania podaje, ktore dane
sa wstepne, a ktore je zastepuja.

## rejestr_zgloszen_jakosci_energii.csv

Zgloszenia dotyczace parametrow jakosciowych energii, nie brakow zasilania. Jeden wiersz na
zgloszenie, z kategoria, wynikiem pomiaru i czasem reakcji w dniach.

## wycinka_i_przeglady_linii_2026.csv

Zlecenia wycinki i przegladow linii SN zamkniete w roku gospodarczym 2026, jeden wiersz na
zlecenie, z kilometrami trasy i kosztem w PLN.
