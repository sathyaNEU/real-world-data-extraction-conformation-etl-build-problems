# Sluis spotlight extract: fields

Data engineering, 28 September 2026. Times are UTC unless a file says otherwise.

## Star events

**grachtwerk_star_events_2024-12-08_to_2026-03-01.csv**: The events warehouse's star stream, schema v5 (in use to 1 March 2026). One row per event.

- `event_id`: Warehouse event number, increasing with load order.
- `event_ts_ms`: Time of the event, milliseconds since 1970-01-01 00:00:00 UTC.
- `repo_id`: Repository id (repositories file `id`).
- `actor_id`: Account id of the account that starred or unstarred (account snapshot `account_id`).
- `action`: `star` or `unstar`.
- `src`: Where the star button was pressed, v5 code; see star_surface_code_crosswalk_2026-03-02.csv.
- `client`: Client the action came from: web, ios, android, cli (the gw command-line client) or api.

**grachtwerk_star_events_2026-03-02_to_2026-09-27.csv**: The events warehouse's star stream, schema v6 (from 2 March 2026). One row per event.

- `event_id`: Event id (ULID).
- `occurred_at`: Time of the event, UTC (ISO 8601).
- `repository_id`: Repository id (repositories file `id`).
- `account_id`: Account id of the account that starred or unstarred (account snapshot `account_id`).
- `event_type`: `star.created` or `star.deleted`.
- `surface`: Where the star button was pressed: feed, newsletter, repo_page, search, explore or api.
- `client`: As in schema v5.

## Rollup

**repo_daily_external_stars_2024-11-24_to_2026-09-27.csv**: Daily warehouse rollup, one row per repository and UTC day from the day the repository was made public (its day 1) to its 100th day or 27 September 2026, whichever comes first.

- `repository_id`: Repository id.
- `day`: UTC calendar day.
- `feed .. api`: External first stars made that day from each surface.
- `external_first_stars`: External first stars made that day: an account's first star of the repository, from an account that is not a bot and not a member of the owning organisation at the time of the star.

## Accounts and organisations

**accounts_snapshot_2026-09-27.parquet**: Account snapshot at 27 September 2026 23:59 UTC, one row per account that appears in the star events, the organisation memberships or the nominations, with the accounts they were merged into.

- `account_id`: Account id.
- `login`: Login at the snapshot.
- `account_type`: user, organization or bot.
- `created_at`: When the account was created (UTC).
- `followers`: Accounts following this account at the snapshot.
- `following`: Accounts this account follows at the snapshot.
- `primary_email_sha256`: SHA-256 of the account's primary email address, lower-cased (users only).
- `merged_into`: For an account merged into another, the surviving account's id; its followers moved to the surviving account.

**organization_memberships_2026-09-27.csv**: Organisation memberships, one row per membership, at the snapshot.

- `organization`: Organisation login.
- `account_id`: Member's account id.
- `role`: owner or member.
- `joined_at / left_at`: Start and end of the membership (UTC); left_at is blank for a current member.

## Repositories

**repositories_2026-09-27.json**: Every repository shortlisted for Sluis from January 2025 to October 2026, at the snapshot.

- `id`: Repository id.
- `full_name`: owner/name at the snapshot.
- `created_at`: When the repository was created (UTC).
- `made_public_at`: When the repository was made public (UTC).
- `owner.type`: Organization or User.

**star_surface_code_crosswalk_2026-03-02.csv**: Star surface codes of schema v5 and their schema v6 names.

## Newsletter

**sluis_spotlight_lottery_2025-2026.xlsx**: The growth team's spotlight log: one row per issue with the seven shortlisted repositories, the subscribers on the Sluis list when the shortlist closed and the repository drawn (to September 2026). Sheet 2025 names repositories as owner/name; sheet 2026 by repository id.

**postwerk_campaigns_2026-04_to_2026-05.csv**: Postwerk campaign report for the Grachtwerk account, April to May 2026 (Amsterdam times, semicolon separated).

- `recipients`: Addresses the campaign was sent to.
- `delivered`: Recipients less hard and soft bounces.
- `unique_opens / unique_clicks`: Recipients who opened / clicked any link at least once.

**postwerk_link_report_2026-04_to_2026-05.csv**: Postwerk link report: one row per campaign, subscriber and link, with that subscriber's clicks on the link.

**relaymark_campaigns_2026-06_to_2026-09.json**: Relaymark campaign export, June to September 2026.

- `stats.delivered`: Recipients less hard and soft bounces.

**relaymark_link_clicks_2026-06_to_2026-09.csv**: Relaymark click log: one row per click, June to September 2026 (UTC).

**sluis_nominations_2026-10.csv**: Responses to the October 2026 Sluis nomination form (Amsterdam times).

- `account_id`: The signed-in account, when the nominator was signed in.
- `email_sha256`: SHA-256 of the email address the nominator typed, lower-cased, when not signed in.
- `repository`: The repository the nominator named, as typed. The form accepts a nomination only when what was typed resolves to a repository on Grachtwerk.

**repository_renames_2026.csv**: Repository renames on Grachtwerk in 2026, one row per rename (UTC).

## Other

**repository_traffic_2026-08-24_to_2026-09-27.csv**: Page views and unique visitors of the October 2026 shortlist's repository pages by day and referrer group (UTC days).

**trending_daily_2026-08-24_to_2026-09-27.csv**: Grachtwerk's daily trending lists for four languages: the 25 repositories with the most stars that UTC day, as the list showed them.
