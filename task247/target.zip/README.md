# Reef Heat Stress Watch: November 2027 survey list

Files gathered by the reef monitoring group of the Punta Bocanegra Reef Station (Universidad Autonoma de Punta Bocanegra) for the November 2027 post-bleaching survey.

- survey_list_request_2027-11-03.eml: the head of reef monitoring's request.
- reef_heat_stress_watch_methods_v3.pdf: the watch's methods note (version 3).
- srao_nrt_sst_user_guide_v3_2.pdf: the near-real-time analysis user guide (version 3.2).
- srao_reprocessed_sst_release_note_2027-05.pdf: the reprocessed analysis release note (May 2027).
- watch_sites_register.csv: the site register.
- srao_sst_daily_climatology_watch_pixels.csv: the daily climatology.
- srao_nrt_sst_extract_watch_pixels_2018-01-01_2027-11-02.csv: the near-real-time extract, 1 January 2018 to 2 November 2027.
- srao_reprocessed_sst_watch_pixels_2018_2026.csv: the reprocessed analysis, 1 January 2018 to 31 December 2026.
- heat_stress_bulletins_2027.xlsx: the 2027 weekly bulletins.
- post_bleaching_survey_protocol_2023.pdf: the 2023 post-bleaching survey protocol.
- post_bleaching_survey_2023_slates.csv: the 2023 post-bleaching survey.
- logger_log_2023-08_2027-04.csv: the logger log.
- logger_readings_from_2024-04-01.csv: the logger readings.
- srao_kd490_monthly_watch_pixels_2024_2027.csv: monthly light attenuation, 2024 to 2027.
- port_tide_gauge_hourly_2027.csv: the port tide gauge, 2027.
- DATA_DICTIONARY.md: the fields of each file.
