# Data dictionary

## watch_sites_register.csv
The watch's site register, one row per site: site_code; site_name; region (north, central, south); pixel_id (the
satellite pixel the watch reads for the site); latitude and longitude (decimal degrees, WGS84); survey_depth_m (the
depth of the site's transects and logger, metres); mmm_c (the site's maximum monthly mean, degrees Celsius).

## srao_sst_daily_climatology_watch_pixels.csv
The daily SST climatology of each pixel: pixel_id; month; day; clim_sst_c (degrees Celsius).

## srao_nrt_sst_extract_watch_pixels_2018-01-01_2027-11-02.csv
The station's extract of the near-real-time analysis, one row per pixel, day and issue: pixel_id; date (the UTC day the
analysis is for, yyyy-mm-dd); sst_c (degrees Celsius); obs_flag (the observation flag, coded as the row's product
version codes it, product guide section 4); product_version; issued_utc (when the issue was made).

## srao_reprocessed_sst_watch_pixels_2018_2026.csv
The reprocessed analysis, May 2027 release: pixel_id; time (the UTC day, yyyy-mm-dd); analysed_sst_k (kelvin).

## heat_stress_bulletins_2027.xlsx
The watch's weekly bulletins for 2027, one row per bulletin and site: the bulletin's number, the date it was issued
(station local date), the analysis day it reports (UTC day), the site, its SST and HotSpot (degrees Celsius), its DHW
(degree Celsius weeks) and the alert level.

## post_bleaching_survey_2023_slates.csv
The 2023 post-bleaching survey as entered from the dive slates, one row per slate line: site_code; date; transect (1
to 4); sheet (S survey, QA quality assurance repeat); observer (initials); depth_m (the transect's depth); metre (the
metre of tape the line is written on, 1 to 20); line (the line's order on the sheet); genus (code); max_diameter_cm;
condition (protocol section 4).

## logger_log_2023-08_2027-04.csv
The dive team's logger log, one row per deployment: site_code; serial; model; depth_m; deployed and retrieved (the date
and time the logger went into and came out of the water, as noted from the boat's GPS on the trip, yyyy-mm-dd hh:mm);
deployed_from and retrieved_from (the boat); notes.

## logger_readings_from_2024-04-01.csv
The station's logger database, every reading downloaded from 1 April 2024: serial; datetime_local (the logger's clock,
station local time, UTC-5); temperature_c (degrees Celsius). A logger records from its launch in the lab to its download.

## srao_kd490_monthly_watch_pixels_2024_2027.csv
Monthly diffuse attenuation of light at 490 nm from the SRAO ocean colour product: pixel_id; month (yyyy-mm);
kd490_per_m (per metre).

## port_tide_gauge_hourly_2027.csv
The port tide gauge: datetime_local (station local time); sea_level_m (metres above the gauge's mean sea level).
